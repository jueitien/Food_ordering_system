/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;

import com.mycompany.assignment.classes.CalculationTools;
import com.mycompany.assignment.classes.data_getter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.BorderFactory;
import javax.swing.JTextArea;
import javax.swing.JWindow;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Chan Zean Yeet
 */
public class runner_revenue extends javax.swing.JFrame {
    String CustomerID;
    String OrderID;
    String CustomerPaidAmount;
    String Date;
    String Time;
    String VendorID;
    String CustomerName;
    String VendorName;
    String RunnerEarning;
    
    public runner_revenue() {
        initComponents();
        RunnerFilter.addActionListener((java.awt.event.ActionEvent evt) -> {
            comboBoxSelection(); 
            ClickFunction();
        });
        
    }
    
    public final void comboBoxSelection(){
        String comboBoxValue = (String) RunnerFilter.getSelectedItem();
        System.out.println("ComboBox Selected Value: " + comboBoxValue);
        if(null != comboBoxValue)switch (comboBoxValue) {
            case "Follow by Revenue ID" -> updateTable("RevenueID");
            case "Follow by Runner ID" -> updateTable("RunnerID");
            case "Follow by Order ID" -> updateTable("OrderID");
            case "Highest Revenue" -> updateTable("HighRevenue");
            case "Lowest Revenue" -> updateTable("LowRevenue");
            default -> {
            }
        }
    }

   
    public void updateTable(String options){
        String [][] runnerdata = null;
        data_getter rg = new data_getter();
        if(null != options)switch (options) {
            case "RevenueID":
                runnerdata = rg.revenueComboBoxSort("RevenueID");
                break;
            case "RunnerID":
                runnerdata = rg.revenueComboBoxSort("RunnerID");
                break;
            case "OrderID":
                runnerdata = rg.revenueComboBoxSort("OrderID");
                break;
            case "HighRevenue":
                runnerdata = rg.revenueComboBoxSort("HighRevenue");
                break;
            case "LowRevenue":
                runnerdata = rg.revenueComboBoxSort("LowRevenue");
                break;
            default:
                break;
        }
        DefaultTableModel runnertable = (DefaultTableModel) runner_revenue_table.getModel();
        runnertable.setRowCount(0);
        for(String [] row : runnerdata){
            runnertable.addRow(row);
        }
    }
    
    public void ClickFunction(){
        runner_revenue_table.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            int row = runner_revenue_table.getSelectedRow(); // Get the selected row
            if (row != -1) { // Check if a valid row is selected
                OrderID = (String) runner_revenue_table.getValueAt(row, 2); // Get the runner ID from column 1
                System.out.println("Selected OrderId: " + OrderID); // Debugging output
                setValue();
            } else {
                System.out.println("No row selected."); // Debugging for no selection
            }
        }
    });
         
        
    }
    
    public void setValue(){
        data_getter rg = new data_getter();
        String [][]orderdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Order.txt");
        for(String [] list : orderdata){
            if(list[0].equals(OrderID)){
                this.CustomerID = list[1];
                this.VendorID = list[2];
                this.Date = list[4];
                this.Time = list[5];
                this.CustomerPaidAmount = list[6];
                break;
            }
        }
        String [][]vendordata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Vendor.txt");
        for(String [] list : vendordata){
            if(list[0].equals(VendorID)){
                this.VendorName = list[1];
                break;
            }
        }
        String [][]customerdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Customer.txt");
        for(String [] list : customerdata){
            if(list[0].equals(CustomerID)){
                this.CustomerName = list[1];
                break;
            }
        }
        String [][]rrevenuedata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunnerRevenue.txt");
        for(String [] list : rrevenuedata){
            if(list[2].equals(OrderID)){
                this.RunnerEarning = list[4];
                break;
            }
        }
        UpdateDetail();
    }
    
    public void UpdateDetail(){
        CalculationTools ct = new CalculationTools();
        CustomerIDLabel.setText(this.CustomerID);
        VendorIDLabel.setText(this.VendorID);
        PaidLabel.setText(this.CustomerPaidAmount);
        DateLabel.setText(this.Date);
        TimeLabel.setText(this.Time);
        CTPLabel.setText(this.CustomerPaidAmount);
        RRLabel.setText(this.RunnerEarning);
        Float VR = Float.parseFloat(CustomerPaidAmount) - Float.parseFloat(RunnerEarning);
        VRLabel.setText(String.valueOf(VR));
        VRLabel2.setText(String.valueOf(VR));
        String MRO = String.valueOf(ct.MROCount(CustomerPaidAmount, RunnerEarning));
        MROLabel.setText(MRO);
        ManagerRevenueLabel.setText(MRO);
    }
    
   
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        RunnerFilter = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        runner_revenue_table = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        BackBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        CustomerIDLabel = new javax.swing.JLabel();
        VendorIDLabel = new javax.swing.JLabel();
        PaidLabel = new javax.swing.JLabel();
        DateLabel = new javax.swing.JLabel();
        TimeLabel = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        VRLabel = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        MROLabel = new javax.swing.JLabel();
        CTPLabel = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        RRLabel = new javax.swing.JLabel();
        VRLabel2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        ManagerRevenueLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        RunnerFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Follow by Revenue ID", "Follow by Runner ID", "Follow By Order ID", "Highest Revenue", "Lowest Revenue", " " }));

        runner_revenue_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Revenue ID", "Runner ID", "Order ID", "Revenue Date", "Earnings"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(runner_revenue_table);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Runner Revenue Records");

        BackBtn.setText("Back");
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Manager Revenue Info");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Customer Payment");

        jLabel4.setText("Customer ID:");

        jLabel5.setText("Vandor ID:");

        jLabel6.setText("Customer Total Paid:");

        jLabel7.setText("Date:");

        jLabel8.setText("Time: ");

        CustomerIDLabel.setText("jLabel9");
        CustomerIDLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CustomerIDLabelMouseEntered(evt);
            }
        });

        VendorIDLabel.setText("jLabel10");
        VendorIDLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                VendorIDLabelMouseEntered(evt);
            }
        });

        PaidLabel.setText("jLabel11");

        DateLabel.setText("jLabel12");

        TimeLabel.setText("jLabel13");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(98, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(89, 89, 89))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CustomerIDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(VendorIDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PaidLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(DateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel3)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(CustomerIDLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(VendorIDLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(PaidLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(DateLabel))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(TimeLabel))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        jLabel9.setText("Vendor Revenue = Customer Total Paid - Runner Revenue");

        jLabel10.setText("Manager Revenue/Order = Vendor Revenue x 20/100 (manager get 20% from Vendor Revenue)");

        VRLabel.setText("VR");

        jLabel12.setText("=");

        jLabel13.setText("=");

        MROLabel.setText("MR/O");

        CTPLabel.setText("CTP");

        jLabel16.setText("-");

        RRLabel.setText("RR");

        VRLabel2.setText("VR");

        jLabel19.setText("X   (20/100)");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setText("MR/O");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("=");

        ManagerRevenueLabel.setBackground(new java.awt.Color(255, 255, 255));
        ManagerRevenueLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ManagerRevenueLabel.setForeground(new java.awt.Color(0, 204, 0));
        ManagerRevenueLabel.setText("NULL");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(139, 139, 139)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel1)
                                                    .addComponent(RunnerFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(20, 20, 20)
                                                .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE))
                                .addGap(34, 34, 34))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CTPLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(RRLabel)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addGap(13, 13, 13)
                        .addComponent(VRLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(VRLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel19)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(MROLabel)))
                .addGap(237, 237, 237)
                .addComponent(jLabel20)
                .addGap(18, 18, 18)
                .addComponent(jLabel21)
                .addGap(18, 18, 18)
                .addComponent(ManagerRevenueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(BackBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(RunnerFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(VRLabel)
                    .addComponent(jLabel12)
                    .addComponent(CTPLabel)
                    .addComponent(jLabel16)
                    .addComponent(RRLabel))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(MROLabel)
                            .addComponent(VRLabel2)
                            .addComponent(jLabel19)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(ManagerRevenueLabel))))
                .addContainerGap(63, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        runner_performance rp = new runner_performance();
        rp.setVisible(true);
        dispose();
    }//GEN-LAST:event_BackBtnActionPerformed

    private void CustomerIDLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerIDLabelMouseEntered
        // Create a tooltip-like floating window
        JWindow tooltipWindow = new JWindow();

        // Use JTextArea for multiline text
        JTextArea tooltipText = new JTextArea("Name: " + CustomerName);
        tooltipText.setLineWrap(true);
        tooltipText.setWrapStyleWord(true);
        tooltipText.setOpaque(true);
        tooltipText.setBackground(new java.awt.Color(255, 255, 204));
        tooltipText.setBorder(BorderFactory.createLineBorder(java.awt.Color.BLACK));
        tooltipText.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12));
        tooltipText.setEditable(false); // Make it non-editable

        // Add the text area to the tooltip window
        tooltipWindow.add(tooltipText);

        // Dynamically calculate the size of the tooltip based on text content
        int padding = 10; // Add padding around the text
        java.awt.FontMetrics metrics = tooltipText.getFontMetrics(tooltipText.getFont());
        int width = Math.min(metrics.stringWidth("Name: " + CustomerName) + padding, 300); // Limit width to 300px
        int height = (int) Math.ceil(metrics.stringWidth("Name: " + CustomerName) / 300.0) * metrics.getHeight() + padding;

        tooltipText.setSize(width, height);
        tooltipWindow.setSize(width + padding, height + padding); // Set window size

        // Position the tooltip near the mouse cursor
        java.awt.Point location = CustomerIDLabel.getLocationOnScreen();
        tooltipWindow.setLocation(location.x, location.y - height - 5); // Position above the label
        tooltipWindow.setVisible(true);

        // Hide the tooltip when the mouse exits
        CustomerIDLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tooltipWindow.dispose();
            }
        });
    }//GEN-LAST:event_CustomerIDLabelMouseEntered

    private void VendorIDLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VendorIDLabelMouseEntered
        // Create a tooltip-like floating window
        JWindow tooltipWindow = new JWindow();

        // Use JTextArea for multiline text
        JTextArea tooltipText = new JTextArea("Name: " + VendorName);
        tooltipText.setLineWrap(true);
        tooltipText.setWrapStyleWord(true);
        tooltipText.setOpaque(true);
        tooltipText.setBackground(new java.awt.Color(255, 255, 204));
        tooltipText.setBorder(BorderFactory.createLineBorder(java.awt.Color.BLACK));
        tooltipText.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12));
        tooltipText.setEditable(false); // Make it non-editable

        // Add the text area to the tooltip window
        tooltipWindow.add(tooltipText);

        // Dynamically calculate the size of the tooltip based on text content
        int padding = 10; // Add padding around the text
        java.awt.FontMetrics metrics = tooltipText.getFontMetrics(tooltipText.getFont());
        int width = Math.min(metrics.stringWidth("Name: " + VendorName) + padding, 300); // Limit width to 300px
        int height = (int) Math.ceil(metrics.stringWidth("Name: " + VendorName) / 300.0) * metrics.getHeight() + padding;

        tooltipText.setSize(width, height);
        tooltipWindow.setSize(width + padding, height + padding); // Set window size

        // Position the tooltip near the mouse cursor
        java.awt.Point location = VendorIDLabel.getLocationOnScreen();
        tooltipWindow.setLocation(location.x, location.y - height - 5); // Position above the label
        tooltipWindow.setVisible(true);

        // Hide the tooltip when the mouse exits
        VendorIDLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tooltipWindow.dispose();
            }
        });
    }//GEN-LAST:event_VendorIDLabelMouseEntered

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(runner_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(runner_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(runner_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(runner_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new runner_revenue().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackBtn;
    private javax.swing.JLabel CTPLabel;
    private javax.swing.JLabel CustomerIDLabel;
    private javax.swing.JLabel DateLabel;
    private javax.swing.JLabel MROLabel;
    private javax.swing.JLabel ManagerRevenueLabel;
    private javax.swing.JLabel PaidLabel;
    private javax.swing.JLabel RRLabel;
    private javax.swing.JComboBox<String> RunnerFilter;
    private javax.swing.JLabel TimeLabel;
    private javax.swing.JLabel VRLabel;
    private javax.swing.JLabel VRLabel2;
    private javax.swing.JLabel VendorIDLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable runner_revenue_table;
    // End of variables declaration//GEN-END:variables
}

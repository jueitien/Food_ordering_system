/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;

import com.mycompany.assignment.classes.CalculationTools;
import com.mycompany.assignment.classes.data_getter;
import com.mycompany.assignment.classes.manager_setter;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author Chan Zean Yeet
 */
public class vendor_revenue extends javax.swing.JFrame {
    private manager_setter ms = manager_setter.getInstance();
    String managerId = ms.getManagerId();
    String VendorId;

    public vendor_revenue() {
        initComponents();
        VendorComboBoxUpdate();
        VendorComboBox.addActionListener((java.awt.event.ActionEvent evt) -> {
            String comboBoxValue = (String) VendorComboBox.getSelectedItem();
            VendorId = comboBoxValue;
        });
        time_combobox.addActionListener((java.awt.event.ActionEvent evt) -> {
            TimeSelection(); 
        });
    }
    
    public void VendorComboBoxUpdate(){
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Vendor.txt";
        data_getter dg = new data_getter();
        ArrayList<String> vendorList = dg.getList(filepath, managerId, 3, 0);
        for(String vendor : vendorList){
            VendorComboBox.addItem(vendor);
        }
    }
    
    
    public void TimeSelection() {
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Order.txt";
        data_getter dg = new data_getter();
        CalculationTools CT = new CalculationTools();

        // Current date in yyyy-MM-dd format
        String todaydate = LocalDate.now().toString();
        today_date_label.setText(todaydate); 

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 

        String comboBoxValue = (String) time_combobox.getSelectedItem();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        float totalEarn = 0;

        if (comboBoxValue.equals("Today")) {
            System.out.println(todaydate);
            ArrayList<String> EarnList = dg.getListWithCondition(filepath, VendorId, todaydate, 2, 4, 6);
            for (String earn : EarnList) {
                totalEarn += Float.parseFloat(earn); // Convert and sum
            }
            dataset.addValue(totalEarn, "Revenue", todaydate);
            profitLabel.setText(String.valueOf(totalEarn));
            createChart(dataset, comboBoxValue);
            System.out.println("Dataset Row Count: " + dataset.getRowCount());

        } else if (comboBoxValue.equals("Last 30 Days")) {
            String startdate = CT.DateCalculation(todaydate, 30, "minus"); // Now returns yyyy-MM-dd
            System.out.println(startdate);

            ArrayList<String> EarnList = dg.getListWithCondition(filepath, VendorId, startdate, 2, 4, 6);
            System.out.println(EarnList);
            ArrayList<String> DateList = dg.getListWithCondition(filepath, VendorId, startdate, 2, 4, 4);
            System.out.println(DateList);

            if (EarnList.size() == DateList.size()) {
                for (int i = 0; i < EarnList.size(); i++) {
                    try {
                        float eachEarn = Float.parseFloat(EarnList.get(i));
                        totalEarn += eachEarn;
                        dataset.addValue(eachEarn, "Revenue", DateList.get(i)); 
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number format: " + EarnList.get(i));
                    }
                }
            } else {
                System.out.println("Mismatch in EarnList and DateList sizes.");
            }

            profitLabel.setText(String.valueOf(totalEarn));
            createChart(dataset, comboBoxValue);
            System.out.println("Dataset Row Count: " + dataset.getRowCount());
        } else if (comboBoxValue.equals("Last 360 Days")) {
            String startdate = CT.DateCalculation(todaydate, 360, "minus"); // Now returns yyyy-MM-dd
            System.out.println(startdate);

            ArrayList<String> EarnList = dg.getListWithCondition(filepath, VendorId, startdate, 2, 4, 6);
            System.out.println(EarnList);
            ArrayList<String> DateList = dg.getListWithCondition(filepath, VendorId, startdate, 2, 4, 4);
            System.out.println(DateList);

            if (EarnList.size() == DateList.size()) {
                for (int i = 0; i < EarnList.size(); i++) {
                    try {
                        float eachEarn = Float.parseFloat(EarnList.get(i));
                        totalEarn += eachEarn;
                        dataset.addValue(eachEarn, "Revenue", DateList.get(i)); 
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number format: " + EarnList.get(i));
                    }
                }
            } else {
                System.out.println("Mismatch in EarnList and DateList sizes.");
            }

            profitLabel.setText(String.valueOf(totalEarn));
            createChart(dataset, comboBoxValue);
            System.out.println("Dataset Row Count: " + dataset.getRowCount());
        }
    }
    
    public void createChart(DefaultCategoryDataset dataset, String title) {
        JFreeChart chart = ChartFactory.createLineChart(
                "Revenue Over Time", // Chart title
                "Date", // X-Axis Label
                "Revenue (RM)", // Y-Axis Label
                dataset
        );

        // Create a new ChartPanel with the generated chart
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(GraphPanel.getWidth(), GraphPanel.getHeight()));

        // Remove previous chart and add the new one
        GraphPanel.removeAll();
        GraphPanel.setLayout(new java.awt.BorderLayout());
        GraphPanel.add(chartPanel, java.awt.BorderLayout.CENTER);
        GraphPanel.validate();
        GraphPanel.repaint();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        time_combobox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        chart_panel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        profitLabel = new javax.swing.JLabel();
        GraphPanel = new javax.swing.JPanel();
        VendorComboBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        today_date_label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        time_combobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Today", "Last 30 Days", "Last 360 Days" }));

        jLabel1.setText("Vendor Revenue");

        chart_panel.setBackground(new java.awt.Color(255, 255, 255));
        chart_panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setText("Total P&L : ");

        profitLabel.setText("jLabel3");

        javax.swing.GroupLayout GraphPanelLayout = new javax.swing.GroupLayout(GraphPanel);
        GraphPanel.setLayout(GraphPanelLayout);
        GraphPanelLayout.setHorizontalGroup(
            GraphPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 562, Short.MAX_VALUE)
        );
        GraphPanelLayout.setVerticalGroup(
            GraphPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 258, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout chart_panelLayout = new javax.swing.GroupLayout(chart_panel);
        chart_panel.setLayout(chart_panelLayout);
        chart_panelLayout.setHorizontalGroup(
            chart_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chart_panelLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(chart_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, chart_panelLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(profitLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, chart_panelLayout.createSequentialGroup()
                        .addComponent(GraphPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))))
        );
        chart_panelLayout.setVerticalGroup(
            chart_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(chart_panelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(chart_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(profitLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(GraphPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        VendorComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VendorComboBoxActionPerformed(evt);
            }
        });

        jLabel3.setText("Today Date:");

        today_date_label.setText("jLabel4");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(481, 481, 481)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(chart_panel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(VendorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(time_combobox, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(today_date_label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(0, 62, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(time_combobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(VendorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(today_date_label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chart_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        vendor_main vm = new vendor_main();
        vm.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void VendorComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VendorComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VendorComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(vendor_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(vendor_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(vendor_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(vendor_revenue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vendor_revenue().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel GraphPanel;
    private javax.swing.JComboBox<String> VendorComboBox;
    private javax.swing.JPanel chart_panel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel profitLabel;
    private javax.swing.JComboBox<String> time_combobox;
    private javax.swing.JLabel today_date_label;
    // End of variables declaration//GEN-END:variables
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;

import com.mycompany.assignment.classes.CalculationTools;
import com.mycompany.assignment.classes.TextFileModifyTools;
import com.mycompany.assignment.classes.data_getter;
import com.mycompany.assignment.classes.runner_setter;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Chan Zean Yeet
 */
public class runner_individual extends javax.swing.JFrame {
    private runner_setter rs = runner_setter.getInstance();
    data_getter rg = new data_getter();
    TextFileModifyTools tft = new TextFileModifyTools();
    CalculationTools ct = new CalculationTools();
    
    String RunnerID;
    String RunnerName;
    String RunnerTotalEarnings;
    String RunnerTotalOrderDelivered;
    String RunnerPoints;
    String RunnerPSP;
    String RunnerAchievement;
    
    public runner_individual() {
        initComponents();
        setValue();
    }
    
    public void setValue(){
        RunnerID = rs.getRunnerID();
        String [][] runnerdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunner.txt");
        for(String list[]:runnerdata){
            if(list[0].equals(RunnerID)){
                RunnerName = list[1];
                RunnerPoints = list[3];
                break;
            }
        }
        RunnerTotalEarnings = String.valueOf(ct.TotalCal("Earning", RunnerID));
        RunnerTotalOrderDelivered = String.valueOf(ct.TotalCal("Order", RunnerID));
        int highstars = ct.StarCounter(RunnerID, "5") + ct.StarCounter(RunnerID, "4");
        RunnerPSP = String.valueOf(ct.PSPercentageCount(Float.parseFloat(RunnerTotalOrderDelivered), highstars));
        float runnerPSP = Float.parseFloat(RunnerPSP);
        if (runnerPSP > 80) {
            RunnerAchievement = "Excellent";
        } else if (runnerPSP > 50) {
            RunnerAchievement = "Good";
        } else if (runnerPSP > 30) {
            RunnerAchievement = "Bad";
        } else if (runnerPSP > 0) {
            RunnerAchievement = "Horrible";
        } else {
            RunnerAchievement = "Blacklisted";
        }
        setLabel();
    }
    
    public void setLabel(){
        runner_id.setText(RunnerID);
        runner_name.setText(RunnerName);
        runner_points.setText(RunnerPoints);
        float points = Float.parseFloat(RunnerPoints);
        if (points > 70) {
            runner_points.setForeground(new Color(0, 128, 0)); // Set text color to green
        } else if (points > 40) {
            runner_points.setForeground(new Color(204, 85, 0)); // Set text color to orange
        } else {
            runner_points.setForeground(Color.RED); // Set text color to red
        }
        runner_ppercentage.setText(RunnerPSP+"%");
        runner_total_earning.setText(RunnerTotalEarnings);
        runner_total_delivered.setText(RunnerTotalOrderDelivered);
        AchievementLabel.setText(RunnerAchievement);
    }
    
    public final void AnalyzeSelection(){
        String comboBoxValue = (String) SearchComboBoxValue.getSelectedItem();
        String userinput = SearchInput.getText();
        System.out.println("ComboBox Selected Value: " + comboBoxValue);
        if(null != comboBoxValue)switch (comboBoxValue) {
            case "Review ID" -> updateTable("Review ID",userinput);
            case "Customer ID" -> updateTable("Customer ID",userinput);
            case "Star" -> updateTable("Stars Given",userinput);
            case "Comments" -> updateTable("Comments",userinput);
            case "Date" -> updateTable("Date",userinput);
            default -> {
            }
        }
    }
    public void updateTable(String options,String value){
        String FilePath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunnerReview.txt";
        String [][] runnerdata = null;
        data_getter rg = new data_getter();
        if(null != options)switch (options) {
            case "Review ID":
                runnerdata = rg.SearchTool(FilePath, 0, value);
                break;
            case "Customer ID":
                runnerdata = rg.SearchTool(FilePath, 2, value);
                break;
            case "Stars Given":
                runnerdata = rg.SearchTool(FilePath, 3, value);
                break;
            case "Comments":
                runnerdata = rg.SearchTool(FilePath, 4, value);
                break;
            case "Date":
                runnerdata = rg.SearchTool(FilePath, 5, value);
                break;
            default:
                break;
        }
        DefaultTableModel runnertable = (DefaultTableModel) customer_comments_table.getModel();
        runnertable.setRowCount(0);
        int excludeColumnIndex = 1; // Replace with the index of the column to exclude (zero-based)

        for (String[] row : runnerdata) {
            // Create a new row array excluding the specific column
            String[] newRow = new String[row.length - 1];
            int newIndex = 0;
            for (int i = 0; i < row.length; i++) {
                if (i != excludeColumnIndex) { // Skip the excluded column
                    newRow[newIndex++] = row[i];
                }
            }
            runnertable.addRow(newRow);
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        runner_id = new javax.swing.JLabel();
        runner_name = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        runner_points = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        customer_comments_table = new javax.swing.JTable();
        runner_total_earning = new javax.swing.JLabel();
        runner_ppercentage = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        runner_total_delivered = new javax.swing.JLabel();
        SearchComboBoxValue = new javax.swing.JComboBox<>();
        SearchInput = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        SearchBtn = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        AchievementLabel = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        AmountInput = new javax.swing.JTextField();
        ConfirmBtn = new javax.swing.JButton();
        AddMinusComboBoxValue = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("ID:");

        jLabel2.setText("Name:");

        runner_id.setText("jLabel3");

        runner_name.setText("jLabel4");

        jLabel5.setText("Merits Points:");

        runner_points.setText("jLabel6");

        jLabel7.setText("Total Earnings:");

        jLabel8.setText("Performance Percentage:");

        customer_comments_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Review ID", "Customer ID", "Stars", "Comments", "Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(customer_comments_table);

        runner_total_earning.setText("jLabel9");

        runner_ppercentage.setText("jLabel3");

        jLabel6.setText("Total Order Delivered:");

        runner_total_delivered.setText("jLabel9");

        SearchComboBoxValue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Review ID", "Customer ID", "Star", "Comments", "Date" }));

        SearchInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchInputActionPerformed(evt);
            }
        });

        jLabel11.setText("Search Comments");

        SearchBtn.setText("Search");
        SearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBtnActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Runner Personal Information");

        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        AchievementLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        AchievementLabel.setText("jLabel9");

        jLabel9.setText("Grade:");

        jLabel4.setText("Update Merits Points");

        ConfirmBtn.setText("Confirm");
        ConfirmBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmBtnActionPerformed(evt);
            }
        });

        AddMinusComboBoxValue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Add", "Minus" }));
        AddMinusComboBoxValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddMinusComboBoxValueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(AchievementLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(AddMinusComboBoxValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(AmountInput, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(17, 17, 17)))))
                .addContainerGap(47, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ConfirmBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(AchievementLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddMinusComboBoxValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AmountInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ConfirmBtn)
                .addGap(37, 37, 37))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 819, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addComponent(SearchComboBoxValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(SearchInput, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(SearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(107, 107, 107)
                                        .addComponent(runner_total_earning, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1))
                                        .addGap(70, 70, 70)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(runner_id, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(runner_name, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(74, 74, 74)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel6))
                                        .addGap(55, 55, 55)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(runner_points, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(runner_ppercentage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(runner_total_delivered, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel12))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(jButton3))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(runner_id)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5)
                            .addComponent(runner_points))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(runner_ppercentage)
                            .addComponent(jLabel2)
                            .addComponent(runner_name))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(runner_total_earning)
                            .addComponent(jLabel6)
                            .addComponent(runner_total_delivered))
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SearchBtn)
                            .addComponent(SearchComboBoxValue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SearchInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddMinusComboBoxValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddMinusComboBoxValueActionPerformed
        
    }//GEN-LAST:event_AddMinusComboBoxValueActionPerformed

    private void ConfirmBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmBtnActionPerformed
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunner.txt";
        float finalpoint = 0;
        String comboBoxValue = (String) AddMinusComboBoxValue.getSelectedItem();
        String userInputText = AmountInput.getText().trim(); // Get and trim user input

        // Validate user input
        if (userInputText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Input cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        float userinput;
        try {
            userinput = Float.parseFloat(userInputText); // Try parsing user input
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Perform the add or minus operation
        if (comboBoxValue.equals("Add")) {
            finalpoint = Float.parseFloat(RunnerPoints) + userinput;
        } else if (comboBoxValue.equals("Minus")) {
            finalpoint = Float.parseFloat(RunnerPoints) - userinput;
        }
        
        JOptionPane.showMessageDialog(this, "Merit points modified successfully !");

        // Update the file
        tft.UpdateTxtFile(filepath, 3, RunnerID, String.valueOf(finalpoint));
        this.dispose(); // Close the current instance
        new runner_individual().setVisible(true); // Open a new instanc
    }//GEN-LAST:event_ConfirmBtnActionPerformed

    private void SearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBtnActionPerformed
        AnalyzeSelection();
    }//GEN-LAST:event_SearchBtnActionPerformed

    private void SearchInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchInputActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        runner_performance rp = new runner_performance();
        rp.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(runner_individual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(runner_individual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(runner_individual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(runner_individual.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new runner_individual().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AchievementLabel;
    private javax.swing.JComboBox<String> AddMinusComboBoxValue;
    private javax.swing.JTextField AmountInput;
    private javax.swing.JButton ConfirmBtn;
    private javax.swing.JButton SearchBtn;
    private javax.swing.JComboBox<String> SearchComboBoxValue;
    private javax.swing.JTextField SearchInput;
    private javax.swing.JTable customer_comments_table;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel runner_id;
    private javax.swing.JLabel runner_name;
    private javax.swing.JLabel runner_points;
    private javax.swing.JLabel runner_ppercentage;
    private javax.swing.JLabel runner_total_delivered;
    private javax.swing.JLabel runner_total_earning;
    // End of variables declaration//GEN-END:variables
}

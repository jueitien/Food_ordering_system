/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;

import com.mycompany.assignment.classes.TextFileModifyTools;
import com.mycompany.assignment.classes.data_getter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Chan Zean Yeet
 */
public class runner_order_delivered extends javax.swing.JFrame {
    data_getter rg = new data_getter();
    TextFileModifyTools tft = new TextFileModifyTools();
    
    String orderId;
    String vendorId;
    String date;
    String time;
    String order_placement;
    String order_status;
    String total;
    String customerId;
    String reason_refund;
    public runner_order_delivered() {
        initComponents();
        ClickFunction();
        
    }
    
    public final void AnalyzeSelection(){
        String comboBoxValue = (String) SearchByOptions.getSelectedItem();
        String userinput = value.getText();
        System.out.println("ComboBox Selected Value: " + comboBoxValue);
        if(null != comboBoxValue)switch (comboBoxValue) {
            case "Runner ID" -> updateTable("Runner ID",userinput);
            case "Customer ID" -> updateTable("Customer ID",userinput);
            case "Order ID" -> updateTable("Order ID",userinput);
            case "Task ID" -> updateTable("Task ID",userinput);
            case "Status" -> updateTable("Status",userinput);
            case "Date" -> updateTable("Date",userinput);
            case "Time Start" -> updateTable("Time Start",userinput);
            case "Time End" -> updateTable("Time End",userinput);
            default -> {
            }
        }
    }
    public void updateTable(String options,String value){
        String FilePath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunnerTask.txt";
        String [][] runnerdata = null;
        if(null != options)switch (options) {
            case "Runner ID":
                runnerdata = rg.SearchTool(FilePath, 3, value);
                break;
            case "Customer ID":
                runnerdata = rg.SearchTool(FilePath, 1, value);
                break;
            case "Order ID":
                runnerdata = rg.SearchTool(FilePath, 2, value);
                break;
            case "Task ID":
                runnerdata = rg.SearchTool(FilePath, 0, value);
                break;
            case "Status":
                runnerdata = rg.SearchTool(FilePath, 4, value);
                break;
            case "Date":
                runnerdata = rg.SearchTool(FilePath, 5, value);
                break;
            case "Time Start":
                runnerdata = rg.SearchTool(FilePath, 6, value);
                break;
            case "Time End":
                runnerdata = rg.SearchTool(FilePath, 7, value);
                break;
            default:
                break;
        }
        DefaultTableModel runnertable = (DefaultTableModel) OrdersDeliveredTable.getModel();
        runnertable.setRowCount(0);
        for(String [] row : runnerdata){
            runnertable.addRow(row);
        }
    }
    
    public void ClickFunction(){
        OrdersDeliveredTable.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            int row = OrdersDeliveredTable.getSelectedRow(); 
            if (row != -1) { 
                orderId =  (String) OrdersDeliveredTable.getValueAt(row, 2);   
                customerId = (String) OrdersDeliveredTable.getValueAt(row, 1); 
                SetLabel();
            } else {
                System.out.println("No row selected."); // Debugging for no selection
            }
        }
    });  
    }
    
    public void SetLabel(){
        String [][] orderdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Order.txt");
        for(String [] list : orderdata){
            if(list[0].equals(orderId)){
                this.vendorId = list[2];
                this.date = list[4];
                this.time = list[5];
                this.total = list[6];
                this.order_placement = list[7];
                this.order_status = list[10];
            }
        }
        UpdateLabel();
    }
    
    public void UpdateLabel(){
        if(!"Cancelled".equals(order_status)){
            RefundPanel.setVisible(false);
        }else{
            RefundPanel.setVisible(true);
        }
        OrderID.setText(orderId);
        VendorID.setText(vendorId);
        Date.setText(date);
        Time.setText(time);
        Total.setText(total);
        OrderPlacement.setText(order_placement);
        OrderStatus.setText(order_status);
        OrderID2.setText(orderId);
        CustomerID.setText(customerId);
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        OrdersDeliveredTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        SearchByOptions = new javax.swing.JComboBox<>();
        value = new javax.swing.JTextField();
        SearchBtn = new javax.swing.JButton();
        BackBtn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        OrderID = new javax.swing.JLabel();
        VendorID = new javax.swing.JLabel();
        Date = new javax.swing.JLabel();
        Time = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        OrderPlacement = new javax.swing.JLabel();
        OrderStatus = new javax.swing.JLabel();
        Total = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        RefundPanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        OrderID2 = new javax.swing.JLabel();
        CustomerID = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        refundAmount = new javax.swing.JLabel();
        RefundRequestBtn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        ReasonRefund = new javax.swing.JTextArea();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Runner Orders Delivered Record");

        OrdersDeliveredTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Task ID", "Customer ID", "Order ID", "Runner ID", "Status", "Date", "Time Start", "Time End"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(OrdersDeliveredTable);

        SearchByOptions.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Runner ID", "Customer ID", "Order ID", "Task ID", "Status", "Date", "Time Start", "Time End" }));

        value.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valueActionPerformed(evt);
            }
        });

        SearchBtn.setText("Search");
        SearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBtnActionPerformed(evt);
            }
        });

        BackBtn.setText("Back");
        BackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackBtnActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Order Information");

        jLabel8.setText("Order ID:");

        jLabel9.setText("Vendor ID:");

        jLabel10.setText("Date:");

        jLabel11.setText("Time:");

        OrderID.setText("jLabel12");

        VendorID.setText("jLabel13");

        Date.setText("jLabel14");

        Time.setText("jLabel15");

        jLabel18.setText("Order Status:");

        jLabel19.setText("Total:");

        jLabel20.setText("Order Placement:");

        OrderPlacement.setText("jLabel16");

        OrderStatus.setText("jLabel17");

        Total.setText("jLabel21");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(Date, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE)
                    .addComponent(VendorID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(OrderID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Time, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addComponent(jLabel18)
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(OrderStatus, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                    .addComponent(OrderPlacement, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Total, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(29, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(158, 158, 158))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(OrderID))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(VendorID))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(Date)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(OrderPlacement))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(OrderStatus))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(Total))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(Time))
                .addContainerGap(102, Short.MAX_VALUE))
        );

        RefundPanel.setBackground(new java.awt.Color(255, 255, 255));
        RefundPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Refund Cancelled Order");

        jLabel5.setText("Refund OrderID : ");

        OrderID2.setText("jLabel6");

        CustomerID.setText("jLabel12");

        jLabel13.setText("Refund to Customer :");

        jLabel14.setText("Refund Amount :");

        refundAmount.setText("RM 10");

        RefundRequestBtn.setBackground(new java.awt.Color(204, 255, 204));
        RefundRequestBtn.setText("Send Request to Admin");
        RefundRequestBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefundRequestBtnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Reason");

        ReasonRefund.setColumns(20);
        ReasonRefund.setRows(5);
        jScrollPane2.setViewportView(ReasonRefund);

        javax.swing.GroupLayout RefundPanelLayout = new javax.swing.GroupLayout(RefundPanel);
        RefundPanel.setLayout(RefundPanelLayout);
        RefundPanelLayout.setHorizontalGroup(
            RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RefundPanelLayout.createSequentialGroup()
                .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RefundPanelLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel4)
                        .addGap(116, 116, 116)
                        .addComponent(jLabel6))
                    .addGroup(RefundPanelLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(refundAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(OrderID2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(RefundPanelLayout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(RefundRequestBtn)))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        RefundPanelLayout.setVerticalGroup(
            RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RefundPanelLayout.createSequentialGroup()
                .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RefundPanelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel4)
                        .addGap(27, 27, 27))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RefundPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(RefundPanelLayout.createSequentialGroup()
                        .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(OrderID2))
                        .addGap(18, 18, 18)
                        .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CustomerID)
                            .addComponent(jLabel13))
                        .addGap(18, 18, 18)
                        .addGroup(RefundPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(refundAmount)))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(RefundRequestBtn)
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RefundPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(RefundPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(20, 20, 20)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(SearchByOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(55, 55, 55)
                                            .addComponent(value, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(142, 142, 142)))
                                    .addComponent(SearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 909, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(BackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(403, 403, 403)
                        .addComponent(jLabel1)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(BackBtn)
                .addGap(4, 4, 4)
                .addComponent(jLabel1)
                .addGap(14, 14, 14)
                .addComponent(jLabel2)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SearchByOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(value, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SearchBtn))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void valueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valueActionPerformed

    private void SearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBtnActionPerformed
        AnalyzeSelection();
    }//GEN-LAST:event_SearchBtnActionPerformed

    private void BackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackBtnActionPerformed
        runner_performance rp = new runner_performance();
        rp.setVisible(true);
        dispose();
    }//GEN-LAST:event_BackBtnActionPerformed

    private void RefundRequestBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefundRequestBtnActionPerformed
        reason_refund = ReasonRefund.getText();
        if (reason_refund == null || reason_refund.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in the reason text area.");
        }else{
            String OrderFilePath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Order.txt";
            tft.UpdateTxtFile(OrderFilePath, 9, orderId, "Refunded");

            String RefundFilePath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Refund.txt";
            ArrayList<String> list = new ArrayList<>(Arrays.asList(tft.IdIncrement(RefundFilePath),customerId,total,date,time,reason_refund));
            tft.AddDataRow(RefundFilePath,  list);
            JOptionPane.showMessageDialog(null, "Send Request to Admin successfully!");
            this.dispose();
            new runner_order_delivered().setVisible(true);
        }
            
        
    }//GEN-LAST:event_RefundRequestBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(runner_order_delivered.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(runner_order_delivered.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(runner_order_delivered.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(runner_order_delivered.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new runner_order_delivered().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackBtn;
    private javax.swing.JLabel CustomerID;
    private javax.swing.JLabel Date;
    private javax.swing.JLabel OrderID;
    private javax.swing.JLabel OrderID2;
    private javax.swing.JLabel OrderPlacement;
    private javax.swing.JLabel OrderStatus;
    private javax.swing.JTable OrdersDeliveredTable;
    private javax.swing.JTextArea ReasonRefund;
    private javax.swing.JPanel RefundPanel;
    private javax.swing.JButton RefundRequestBtn;
    private javax.swing.JButton SearchBtn;
    private javax.swing.JComboBox<String> SearchByOptions;
    private javax.swing.JLabel Time;
    private javax.swing.JLabel Total;
    private javax.swing.JLabel VendorID;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel refundAmount;
    private javax.swing.JTextField value;
    // End of variables declaration//GEN-END:variables
}

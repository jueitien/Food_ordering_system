/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;

import com.mycompany.assignment.classes.CalculationTools;
import com.mycompany.assignment.classes.TextFileModifyTools;
import com.mycompany.assignment.classes.data_getter;
import com.mycompany.assignment.classes.manager_setter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class vendor_selection extends javax.swing.JFrame {
    private manager_setter ms = manager_setter.getInstance();
    String managerId = ms.getManagerId();
    private DefaultTableModel tableModel;
    data_getter dg = new data_getter();
    CalculationTools ct = new CalculationTools();
    public vendor_selection() {
        initComponents();
        addTable();
        setLabel();
    }

    private void addTable() {
        // Define column names
        String[] columnNames = {"Vendor ID", "Name", "Phone Num.", "Manager ID", "Select"};

        // Create a table model with the correct column types
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                // Make the "Select" column Boolean for checkboxes
                return (columnIndex == 4) ? Boolean.class : String.class;
            }
        };

        // Add sample data
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Vendor.txt";
        String [][] DataList = dg.getRunnerData(filepath);

        for (Object[] row : DataList) {
            if(row[3].equals("null")){
                // Create a new array with one additional element
                Object[] newRow = new Object[row.length + 1];

                // Copy the original elements into the new array
                System.arraycopy(row, 0, newRow, 0, row.length);

                // Add 'false' as the last element
                newRow[row.length] = false;

                // Add the new row to the table model
                tableModel.addRow(newRow);
            
            
            }
                
            
        }

        // Create the table
        JTable table = new JTable(tableModel);

        // Set the table into the JScrollPane
        vendors_table_panel.setViewportView(table);
    }
    
    public void setLabel(){
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Vendor.txt";
        TotalVendorLabel.setText(String.valueOf(ct.RowCount(filepath, managerId, 3)));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        vendors_table_panel = new javax.swing.JScrollPane();
        SelectVendorBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        TotalVendorLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Vendors without manager");

        SelectVendorBtn.setText("Select");
        SelectVendorBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectVendorBtnActionPerformed(evt);
            }
        });

        jLabel2.setText("Total Vendor Count:");

        TotalVendorLabel.setText("0");

        jLabel3.setText("/ 5");

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(135, 135, 135)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TotalVendorLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(vendors_table_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 691, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(345, 345, 345)
                        .addComponent(SelectVendorBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(TotalVendorLabel)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addComponent(jButton1))
                .addGap(18, 18, 18)
                .addComponent(vendors_table_panel, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SelectVendorBtn)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SelectVendorBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectVendorBtnActionPerformed
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\Vendor.txt";
        TextFileModifyTools tft = new TextFileModifyTools();
        
        List<String> selectedVendorIds = new ArrayList<>();

        // Loop through table rows
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Boolean isSelected = (Boolean) tableModel.getValueAt(i, 4); // Checkbox column
            if (isSelected != null && isSelected) {
                String VendorId = (String) tableModel.getValueAt(i, 0); // Value from column 0
                selectedVendorIds.add(VendorId);
            }
        }
        if (selectedVendorIds.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No items selected for removal.");
            return;
            }
        if(ct.RowCount(filepath, managerId, 3) + selectedVendorIds.size()>5){
            JOptionPane.showMessageDialog(this, "Maximum 5 vendors each manager");
            return;
        }
        int response = JOptionPane.showConfirmDialog(
            null, 
            "Do you want to proceed?", 
            "Confirmation", 
            JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE
        );
        if (response == JOptionPane.YES_OPTION) {
            for (String VendorId : selectedVendorIds) {
                tft.UpdateTxtFile(filepath, 3, VendorId, managerId);
            }
            JOptionPane.showMessageDialog(this, "Vendor.txt updated successfully");
            this.dispose();
            new vendor_selection().setVisible(true);
        }
        
    }//GEN-LAST:event_SelectVendorBtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        vendor_main vm = new vendor_main();
        vm.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(vendor_selection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(vendor_selection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(vendor_selection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(vendor_selection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vendor_selection().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SelectVendorBtn;
    private javax.swing.JLabel TotalVendorLabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane vendors_table_panel;
    // End of variables declaration//GEN-END:variables
}

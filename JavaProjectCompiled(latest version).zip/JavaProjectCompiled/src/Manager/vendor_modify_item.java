/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;

import com.mycompany.assignment.classes.CalculationTools;
import com.mycompany.assignment.classes.TextFileModifyTools;
import com.mycompany.assignment.classes.data_getter;
import com.mycompany.assignment.classes.vendor_setter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class vendor_modify_item extends javax.swing.JFrame {
    private DefaultTableModel tableModel;
    private vendor_setter vs = vendor_setter.getInstance();
    Boolean is_removing;
    String VendorId = vs.getVendorID();
    data_getter dg = new data_getter();
    public vendor_modify_item() {
        initComponents();
        comboBox.addActionListener((java.awt.event.ActionEvent evt) -> {
            addTable();
        });
        
    }
    
    private void addTable() {
        // Define column names
        String[] columnNames = {"Item ID", "Vendor ID", "Type", "Name", "Price", "Status", "Select"};

        // Create a table model with the correct column types
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                // Make the "Select" column Boolean for checkboxes
                return (columnIndex == 6) ? Boolean.class : String.class;
            }
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6; // Only allow editing for the "Select" checkbox column
            }
        };

        // Add sample data
        String [][] DataList;
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\VendorItemMenu.txt";
        String comboBoxValue = (String) comboBox.getSelectedItem();
        is_removing = comboBoxValue.equals("Available Item");
        DataList = dg.getRunnerDataWithCondition(filepath, 5, "true");
        if(comboBoxValue.equals("Deleted Item")){
            DataList = dg.getRunnerDataWithCondition(filepath, 5, "false");
            removeBtn.setText("Restock");
        }else{
            removeBtn.setText("Remove");
        }
        
        
        for (Object[] row : DataList) {
            if(row[1].equals(VendorId)){
                // Create a new array with one additional element
                Object[] newRow = new Object[row.length + 1];

                // Copy the original elements into the new array
                System.arraycopy(row, 0, newRow, 0, row.length);

                // Add 'false' as the last element
                newRow[row.length] = false;

                // Add the new row to the table model
                tableModel.addRow(newRow);
            
            
            }
                
            
        }
        System.out.println(VendorId);

        // Create the table
        JTable table = new JTable(tableModel);

        // Set the table into the JScrollPane
        tableScrollPane.setViewportView(table);
    }


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tableScrollPane = new javax.swing.JScrollPane();
        jLabel1 = new javax.swing.JLabel();
        removeBtn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        comboBox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Select the vendor item you want to remove or restock");

        removeBtn.setText("Remove");
        removeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeBtnActionPerformed(evt);
            }
        });

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        comboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Available Item", "Deleted Item" }));
        comboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58))
            .addGroup(layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(216, 216, 216)
                        .addComponent(removeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(tableScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 511, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jButton1)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tableScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(removeBtn)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void removeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeBtnActionPerformed
        String filepath = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\VendorItemMenu.txt";
        data_getter dg = new data_getter();
        TextFileModifyTools tft = new TextFileModifyTools();
        
        
        List<String> selectedItemIds = new ArrayList<>();

        // Loop through table rows
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Boolean isSelected = (Boolean) tableModel.getValueAt(i, 6); // Checkbox column
            if (isSelected != null && isSelected) {
                String itemId = (String) tableModel.getValueAt(i, 0); // Value from column 0
                selectedItemIds.add(itemId);
            }
        }
        if (selectedItemIds.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No items selected");
            return;
            }
        ArrayList<String> list =  dg.getList(filepath, VendorId, 1, 5);
        int Truecount = 0;
        for (String value : list) {
            if (value.equalsIgnoreCase("true")) { 
                Truecount++;
            }
        }
        System.out.println(is_removing);
        if(is_removing){
            if( Truecount - selectedItemIds.size()== 0){
            JOptionPane.showMessageDialog(this, "Cannot Remove the last item");
            return;
        }
        }
        int response = JOptionPane.showConfirmDialog(
            null, 
            "Do you want to proceed?", 
            "Confirmation", 
            JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE
        );
        if (response == JOptionPane.YES_OPTION) {
            for (String itemId : selectedItemIds) {
                if(dg.getValueById(filepath, itemId, 5).equals("true")){
                    tft.UpdateTxtFile(filepath, 5, itemId, "false");
                }else if(dg.getValueById(filepath, itemId, 5).equals("false")){
                    tft.UpdateTxtFile(filepath, 5, itemId, "true");
                }
            }
            JOptionPane.showMessageDialog(this, "Item Status Modified Successfully");
            this.dispose();
            new vendor_modify_item().setVisible(true);
        }
        
    }//GEN-LAST:event_removeBtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        vendor_main vm = new vendor_main();
        vm.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void comboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(vendor_modify_item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(vendor_modify_item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(vendor_modify_item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(vendor_modify_item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vendor_modify_item().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboBox;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton removeBtn;
    private javax.swing.JScrollPane tableScrollPane;
    // End of variables declaration//GEN-END:variables
}

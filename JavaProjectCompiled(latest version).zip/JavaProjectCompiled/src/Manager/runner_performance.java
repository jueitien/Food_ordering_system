/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.assignment.pages;
import com.mycompany.assignment.classes.CalculationTools;
import com.mycompany.assignment.classes.runner_setter;
import com.mycompany.assignment.classes.data_getter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class runner_performance extends javax.swing.JFrame {
    private runner_setter rs = runner_setter.getInstance();
    CalculationTools ct = new CalculationTools();
    
    String RunnerID;
    Boolean IsSelected = false;
    
    public runner_performance() {
        initComponents();
        updateTable();
        updateTotalStatus();
        ClickFunction();
    }
    
    public void ClickFunction(){
        runner_table.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            int row = runner_table.getSelectedRow(); // Get the selected row
            if (row != -1) { // Check if a valid row is selected
                RunnerID = (String) runner_table.getValueAt(row, 0); // Get the runner ID from column 1
                System.out.println("Selected RunnerId: " + RunnerID); // Debugging output
                IsSelected = true;
                rs.setRunnerID(RunnerID);
                UpdateStarTable();
            } else {
                System.out.println("No row selected."); // Debugging for no selection
            }
        }
    });  
    }
    
    public void UpdateStarTable(){
        StarTable.setValueAt(ct.StarCounter(RunnerID, "5"), 0, 1);
        StarTable.setValueAt(ct.StarCounter(RunnerID, "4"), 1, 1);
        StarTable.setValueAt(ct.StarCounter(RunnerID, "3"), 2, 1);
        StarTable.setValueAt(ct.StarCounter(RunnerID, "2"), 3, 1);
        StarTable.setValueAt(ct.StarCounter(RunnerID, "1"), 4, 1);
        StarTable.setValueAt(ct.StarCounter(RunnerID, "0"), 5, 1);
        int HighStars = ct.StarCounter(RunnerID, "5")+ct.StarCounter(RunnerID, "4");
        Float runnerPSP = ct.PSPercentageCount(ct.TotalCal("Order", RunnerID),HighStars);
        RunnerPSP.setText(String.valueOf(runnerPSP)+"%");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        runner_table = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        FeedbacksBtn = new javax.swing.JButton();
        OrderDeliveredBtn = new javax.swing.JButton();
        TotalEarningsBtn = new javax.swing.JButton();
        TotalEarningsLabel = new javax.swing.JLabel();
        TotalOrderDeliveredLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        StarTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        RunnerPSP = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Delivery runner");

        runner_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Password", "Merit points", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(runner_table);

        jLabel2.setText("Please select the Runner for detail");

        FeedbacksBtn.setText("Customer Feedbacks");
        FeedbacksBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeedbacksBtnActionPerformed(evt);
            }
        });

        OrderDeliveredBtn.setText("Order Delivered");
        OrderDeliveredBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrderDeliveredBtnActionPerformed(evt);
            }
        });

        TotalEarningsBtn.setText("Runner Revenue Records");
        TotalEarningsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalEarningsBtnActionPerformed(evt);
            }
        });

        TotalEarningsLabel.setText("jLabel3");

        TotalOrderDeliveredLabel.setText("jLabel4");

        jLabel3.setText("Total Earnings:");

        jLabel4.setText("Total Order Delivered:");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton2.setBackground(new java.awt.Color(204, 255, 204));
        jButton2.setText("View Runner Personal Detail");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        StarTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Five Stars", null},
                {"Four Stars", null},
                {"Three Stars", null},
                {"Two Stars", null},
                {"One Star", null},
                {"Complaints", null}
            },
            new String [] {
                "Star Type", "Amount"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(StarTable);

        jLabel7.setText("Runner PSP :");

        RunnerPSP.setText("jLabel8");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(33, 33, 33)
                        .addComponent(RunnerPSP, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(RunnerPSP))
                .addGap(31, 31, 31)
                .addComponent(jButton2)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jButton1.setText("Home");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(OrderDeliveredBtn)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(18, 18, 18)
                                        .addComponent(TotalEarningsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(TotalEarningsBtn))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(FeedbacksBtn)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(TotalOrderDeliveredLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel1)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TotalEarningsLabel)
                            .addComponent(jLabel3)
                            .addComponent(TotalOrderDeliveredLabel)
                            .addComponent(jLabel4))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TotalEarningsBtn)
                            .addComponent(FeedbacksBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(OrderDeliveredBtn)))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void FeedbacksBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeedbacksBtnActionPerformed
        runner_feedbacks rf = new runner_feedbacks();
        rf.setVisible(true);
        dispose();
    }//GEN-LAST:event_FeedbacksBtnActionPerformed

    private void OrderDeliveredBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrderDeliveredBtnActionPerformed
        runner_order_delivered rod = new runner_order_delivered();
        rod.setVisible(true);
        dispose();
    }//GEN-LAST:event_OrderDeliveredBtnActionPerformed

    private void TotalEarningsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalEarningsBtnActionPerformed
        runner_revenue rr = new runner_revenue();
        rr.setVisible(true);
        dispose();
    }//GEN-LAST:event_TotalEarningsBtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        manager_main mm = new manager_main();
        mm.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if(IsSelected){
            runner_individual ri = new runner_individual();
            ri.setVisible(true);
            dispose();
        }else{
            JOptionPane.showMessageDialog(this, "Please Select any row from the table.");
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(runner_performance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(runner_performance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(runner_performance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(runner_performance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new runner_performance().setVisible(true);
            }
        });
    }
    
    public final void updateTable(){
        data_getter rg = new data_getter();
        String [][] runnerdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunner.txt");
        DefaultTableModel runnertable = (DefaultTableModel) runner_table.getModel();
        runnertable.setRowCount(0);
        for(String [] row : runnerdata){
            runnertable.addRow(row);
        }
    }
    
    public void updateTotalStatus(){
        CalculationTools rc = new CalculationTools();
        Float TotalEarnings = rc.TotalCal("Earning","All");
        Float TotalDelivered = rc.TotalCal("Order","All");
        TotalEarningsLabel.setText(String.valueOf(TotalEarnings));
        TotalOrderDeliveredLabel.setText(String.valueOf(TotalDelivered));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton FeedbacksBtn;
    private javax.swing.JButton OrderDeliveredBtn;
    private javax.swing.JLabel RunnerPSP;
    private javax.swing.JTable StarTable;
    private javax.swing.JButton TotalEarningsBtn;
    private javax.swing.JLabel TotalEarningsLabel;
    private javax.swing.JLabel TotalOrderDeliveredLabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable runner_table;
    // End of variables declaration//GEN-END:variables
}

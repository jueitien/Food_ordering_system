/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RunnerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author JYQ00
 */
public class Runner {
    private String runnerId;
    private String username;
    private String password;
    private int meritPoint;
    private int status;

    // Constructor with parameters
    public Runner(String runnerId, String username, String password, int meritPoint, int status) {
        this.runnerId = runnerId;
        this.username = username;
        this.password = password;
        this.meritPoint = meritPoint;
        this.status = status;
    }

    // Default constructor
    public Runner() {
        this.runnerId = "U000";
        this.username = "test";
        this.password = "test123";
        this.meritPoint = 0;
        this.status = 0;
    }

    // Getter
    public String getId() {
        return runnerId;
    }
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    public int getMeritPoint() {
        return meritPoint;
    }
    public int getStatus() {
        return status;
    }
          
    // Setter
    public void setUsername(String username) {
        this.username = username;
    }
    public void setMeritPoint(int meritPoint) {
        this.meritPoint = meritPoint;
    }
    public void setStatus(int status) {
        this.status = status;
    }
    
    // Online Function
    public void setStatusOnline(String runnerId, int status) {
        List<String> updatedLines = new ArrayList<>();
        String runnerfile = "src/data/deliveryrunner.txt";
        
        // Retrieve data 
        try (BufferedReader reader = new BufferedReader(new FileReader(runnerfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String id = taskDetails[0].trim();
                
                if (id.equals(runnerId)) {
                    String updatedLine = runnerId + "|" +
                                         username + "|" +  
                                         password + "|" +  
                                         meritPoint + "|" + 
                                         "1";     
                    updatedLines.add(updatedLine);
                    this.setStatus(1);                    
                } else {
                    updatedLines.add(line); 
                }
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // update data
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(runnerfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Offline Function
    public void setStatusOffline(String runnerId, int status) {
        List<String> updatedLines = new ArrayList<>();
        String runnerfile = "src/data/deliveryrunner.txt";
        
        // Retrieve data
        try (BufferedReader reader = new BufferedReader(new FileReader(runnerfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String id = taskDetails[0].trim();
                
                if (id.equals(runnerId)) {
                    String updatedLine = runnerId + "|" +
                                         username + "|" +  
                                         password + "|" +  
                                         meritPoint + "|" + 
                                         "0";     
                    updatedLines.add(updatedLine);
                    this.setStatus(0);
                } else {
                    updatedLines.add(line); 
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // update data
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(runnerfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }   

    public void setStatusBusy(String runnerId, int status) {
        List<String> updatedLines = new ArrayList<>();
        String runnerfile = "src/data/deliveryrunner.txt";
        
        // Retrieve data 
        try (BufferedReader reader = new BufferedReader(new FileReader(runnerfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String id = taskDetails[0].trim();
                
                if (id.equals(runnerId)) {
                    String updatedLine = runnerId + "|" +
                                         username + "|" +  
                                         password + "|" +  
                                         meritPoint + "|" + 
                                         "2";     
                    updatedLines.add(updatedLine);
                    this.setStatus(1);                    
                } else {
                    updatedLines.add(line); 
                }
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // update data
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(runnerfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Retrieve available runner
    public List<String> getAvailableRunner() {
        String filename = "src/data/deliveryrunner.txt";
        List<String> availableRunner = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim(); 
                if (line.isEmpty()) {
                    continue; 
                }
                String[] taskDetails = line.split("\\|");
                String stat = taskDetails[4];
                int merit = Integer.parseInt(taskDetails[3]);
                if (taskDetails.length == 5) {
                    if (stat.equals("1") && merit > 0 ) {
                        availableRunner.add(taskDetails[0]); //add runner that fullfill the requirement into list
                    }
                } else {
                    System.err.println("error");
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading task data: " + e.getMessage());
        }
        System.out.println("Available runners: " + availableRunner);
        return availableRunner;
        
    }
    
    public List<String> getUnavailableRunner() {
        String filename = "src/data/deliveryrunner.txt";
        List<String> unAvailableRunner = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim(); 
                if (line.isEmpty()) {
                    continue; 
                }
                String[] taskDetails = line.split("\\|");
                String stat = taskDetails[4];
                int merit = Integer.parseInt(taskDetails[3]);
                if (taskDetails.length == 5) {
                    if (stat.equals("0") || stat.equals("2") || merit < 1 ) {
                        unAvailableRunner.add(taskDetails[0]); //add runner that fullfill the requirement into list
                    }
                } else {
                    System.err.println("error");
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading task data: " + e.getMessage());
        }
        System.out.println("Uavailable runners: " + unAvailableRunner);
        return unAvailableRunner;
        
    }
    
}

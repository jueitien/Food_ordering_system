/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RunnerClass;
import RunnerClass.Runner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author JYQ00
 */
public class Task {
    private String taskId;
    private String customerId;
    private String orderId;
    private String runnerId;
    private String status;
    private String createDate;
    private String createTime;
    private String updateTime;
    
    // Constructor with parameters
    public Task(String taskId, String customerId, String orderId, String runnerId, String status, String createDate, String createTime, String updateTime) {
        this.taskId = taskId;
        this.customerId = customerId;
        this.orderId = orderId;
        this.runnerId = runnerId;
        this.status = status;
        this.createDate = createDate;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }
    
    // Default constructor
    public Task() {
        this.runnerId = "NULL";
        this.taskId = "NULL";
        this.customerId = "NULL";
        this.status = "unassigned";
        this.createDate = "NULL";
        this.createTime = "NULL";
        this.updateTime = "NULL";
        this.orderId = "NULL";
    }
    
    
    // Getters
    public String getTaskId() {
        return taskId;
    }
    public String getrunnerId() {
        return runnerId;
    }
    public String getCustomerId() {
        return customerId;
    }
    public String getStatus() {
        return status;
    }
    public String getOrderId() {
        return orderId;
    }
    
    // Setters
    public void setRunnerId(String runnerId) {
        this.runnerId = runnerId;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }
    
    // Retrieve Task
    public List<String[]> getAvailableTask(String runnerId) {
        List<String[]> taskData = new ArrayList<>();
        String filename = "src/data/deliveryrunnertask.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String[] runnerIds = taskDetails[3].split(",");
                
                boolean currentRunner = false;
                // identify runner pool
                for (String getRunner : runnerIds) {
                    getRunner = getRunner.trim();
                    if (getRunner.equals(runnerId)) {
                        currentRunner = true;
                        break;
                    }                    
                }
                // skip user
                if (currentRunner) {
                    continue;
                } 
                if(taskDetails[4].equals("unassigned") || taskDetails[4].equals("rejected")){
                    String[] Details = {
                        taskDetails[0], 
                        taskDetails[2], 
                        taskDetails[3], 
                        taskDetails[4], 
                        taskDetails[5], 
                        taskDetails[6]
                    };
                    taskData.add(Details);
                }                
            }
        } catch (IOException e) {
            System.err.println("Error reading task data: " + e.getMessage());
        }
        return taskData;
    }
    
    // Retrieve Historical Appected Task
    public List<String[]> getHistoricalTask() {
        List<String[]> historicalTaskData = new ArrayList<>();
        String filename = "src/data/deliveryrunnertask.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                if(taskDetails[4].equals("delivered")){
                    String[] Details = {
                    taskDetails[0], 
                    taskDetails[1], 
                    taskDetails[2], 
                    taskDetails[3], 
                    taskDetails[4],
                    taskDetails[5],
                    taskDetails[6], 
                    taskDetails[7]       
                    };
                    historicalTaskData.add(Details);
                }

            }
        } catch (IOException e) {
            System.err.println("Error reading historical task data: " + e.getMessage());
        }
        return historicalTaskData;
    }
    
    //Retrieve Accepted Task Update
    public List<String[]> getUpdatedTask(String runnerId,String taskId){
        List<String[]> updatedTaskData = new ArrayList<>();
        String filename = "src/data/deliveryrunnertask.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                if(taskDetails[3].equals(runnerId)){
                    System.out.println("runner id: " + runnerId);
                    System.out.println("task id: " + taskId);
                    if(taskDetails[4].equals("accepted") || taskDetails[4].equals("pickedup")){
                        String[] Details = {
                        taskDetails[2], 
                        taskDetails[4], 
                        taskDetails[5], 
                        taskDetails[6], 
                        taskDetails[7] 
                    };
                    updatedTaskData.add(Details);
                    }
                }                               
            }
        } catch (IOException e) {
            System.err.println("Error reading task data: " + e.getMessage());
        }
        return updatedTaskData;
    }   
     
    public void acceptedTask(String taskId, String runnerId){
        Date date = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedTime = timeFormat.format(date);
        String formattedDate = dateFormat.format(date);
        
        List<String> updatedLines = new ArrayList<>();
        List<String> orderupdatedLines = new ArrayList<>();
        String taskfile = "src/data/deliveryrunnertask.txt";
        String notificationfile = "src/data/notification.txt";
        String orderfile = "src/data/order.txt";
        String newNotificationId = null;
        String receiver = null;
        String order = null;
        System.out.println("Runner id who accepted it: " + runnerId);
        
        // task read
        try (BufferedReader reader = new BufferedReader(new FileReader(taskfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String id = taskDetails[0].trim();
                
                if (id.equals(taskId)) {
                    String updatedLine = taskId + "|" +
                                         taskDetails[1] + "|" +  
                                         taskDetails[2] + "|" +  
                                         runnerId + "|" +  
                                         "accepted" + "|" +  
                                         taskDetails[5] + "|" +  
                                         taskDetails[6] + "|" + 
                                         formattedTime;     
                    updatedLines.add(updatedLine);
                    this.taskId = taskId;
                    this.customerId = taskDetails[1];
                    receiver = taskDetails[1];
                    this.orderId= taskDetails[2];
                    order = taskDetails[2];
                    this.runnerId = runnerId;
                    this.status = "accepted";
                    this.createDate = taskDetails[5];
                    this.createTime = taskDetails[6];
                    this.updateTime = formattedTime;
                } else {
                    updatedLines.add(line); 
                }
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // notification read
        try (BufferedReader reader = new BufferedReader(new FileReader(notificationfile))) {
            String line;
            String lastLine = null;

            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            if (lastLine != null) {
                String[] lastNotificationDetails = lastLine.split("\\|");
                String lastNotificationId = lastNotificationDetails[0];

                int numericPart = Integer.parseInt(lastNotificationId.substring(1));
                newNotificationId = "N" + String.format("%04d", numericPart + 1);
            } else {
                newNotificationId = "N0000";
            }
        } catch (IOException e) {
            System.err.println("Error reading notification file: " + e.getMessage());
        }
        
        // order read
        try (BufferedReader reader = new BufferedReader(new FileReader(orderfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String orderid = taskDetails[0];
                String customerid = taskDetails[1];
                if (orderid.equals(order) && customerid.equals(receiver)) {
                    System.out.println("task updated in order");
                        String updatedLine =    taskDetails[0] + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                taskDetails[3] + "|" +  
                                                taskDetails[4] + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                taskDetails[7] + "|" + 
                                                taskDetails[8] + "|" + 
                                                "True" + "|" + 
                                                taskDetails[10]; 
                                                orderupdatedLines.add(updatedLine);
                } else {
                    orderupdatedLines.add(line); 
                }           
            }
        } catch (IOException e) {
            System.err.println("Error reading order data: " + e.getMessage());
        }
        
        // write task
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(taskfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // write order
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(orderfile))) {
            for (String updatedLine : orderupdatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        //write notification
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(notificationfile, true))) {
                String notification = newNotificationId + "|" + runnerId +"|individual|"+ receiver +"|Order_Accepted|" + formattedDate;
                writer.write(notification);
                writer.newLine();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing notification file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void rejectedTask(String taskId, String runnerIdReject, String runnerId){
        Date date = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        String formattedTime = timeFormat.format(date);
        List<String> updatedLines = new ArrayList<>();
        String taskfile = "src/data/deliveryrunnertask.txt";
        System.out.println("Runner id who reject it: " + runnerId);
        
        // task read 
        try (BufferedReader reader = new BufferedReader(new FileReader(taskfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String taskid = taskDetails[0].trim();
                String runnerid = taskDetails[3].trim();
                if (taskid.equals(taskId)) {
                    if(runnerid.equals("NULL")){
                        String updatedLine =    taskId + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                runnerId + "|" +  
                                                "rejected" + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                formattedTime;     
                        updatedLines.add(updatedLine);
                        this.taskId = taskId;
                        this.customerId = taskDetails[1];
                        this.orderId = taskDetails[2];
                        this.runnerId = runnerId;
                        this.status = "rejected";
                        this.createDate = taskDetails[5];
                        this.createTime = taskDetails[6];
                        this.updateTime = formattedTime;
                    } else{
                        String updatedLine =    taskId + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                runnerIdReject + "," + runnerId + "|" +  
                                                taskDetails[4] + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                formattedTime;     
                        updatedLines.add(updatedLine);
                        this.taskId = taskId;
                        this.customerId = taskDetails[1];
                        this.orderId = taskDetails[2];
                        this.runnerId = runnerId;
                        this.status = "rejected";
                        this.createDate = taskDetails[5];
                        this.createTime = taskDetails[6];
                        this.updateTime = formattedTime;
                    }
                } else {
                    updatedLines.add(line); 
                }
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // task write
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(taskfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminateTask(String taskId, String runnerId){
        Date date = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedTime = timeFormat.format(date);
        String formattedDate = dateFormat.format(date);
        
        Runner runner = new Runner();
        List<String> availableRunner = new ArrayList<>(runner.getAvailableRunner());
        List<String> updatedLines = new ArrayList<>();
        List<String> orderupdatedLines = new ArrayList<>();
        String taskfile = "src/data/deliveryrunnertask.txt";
        String notificationfile = "src/data/notification.txt";
        String orderfile = "src/data/order.txt";
        String newNotificationId = null;
        String receiver = null;
        String order = null;
        
        // notification read
        try (BufferedReader reader = new BufferedReader(new FileReader(notificationfile))) {
            String line;
            String lastLine = null;

            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            if (lastLine != null) {
                String[] lastNotificationDetails = lastLine.split("\\|");
                String lastNotificationId = lastNotificationDetails[0];

                int numericPart = Integer.parseInt(lastNotificationId.substring(1));
                newNotificationId = "N" + String.format("%04d", numericPart + 1);
            } else {
                newNotificationId = "N0000";
            }
        } catch (IOException e) {
            System.err.println("Error reading notification file: " + e.getMessage());
        }

        
        // task read
        try (BufferedReader reader = new BufferedReader(new FileReader(taskfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String[] rejectedrunners = taskDetails[3].split(",");
                List<String> rejectedRunnerList = new ArrayList<>(Arrays.asList(rejectedrunners));
                
                String rejectingRunner = runnerId;
                
                 availableRunner.remove(rejectingRunner);
                
                if (rejectedRunnerList.containsAll(availableRunner)  && taskId.equals(taskDetails[0]))  {
                    System.out.println(taskDetails[3]);
                    System.out.println(availableRunner);
                    System.out.println("task eliminate");
                    JOptionPane.showMessageDialog(null, "Task has been eliminated");
                        String updatedLine =    taskDetails[0] + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                taskDetails[3] + "|" +  
                                                "eliminated" + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                formattedTime; 
                                                updatedLines.add(updatedLine);
                                                
                    receiver = taskDetails[1];
                    order = taskDetails[2];
                } else {
                    updatedLines.add(line); 
                }           
            }
        } catch (IOException e) {
            System.err.println("Error reading task data: " + e.getMessage());
        }
        
        // order read
        try (BufferedReader reader = new BufferedReader(new FileReader(orderfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String orderid = taskDetails[0];
                String customerid = taskDetails[1];
                if (orderid.equals(order) && customerid.equals(receiver)) {
                    System.out.println("order cancelled");
                        String updatedLine =    taskDetails[0] + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                taskDetails[3] + "|" +  
                                                taskDetails[4] + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                taskDetails[7] + "|" + 
                                                taskDetails[8] + "|" + 
                                                "Null" + "|" + 
                                                taskDetails[10]; 
                                                orderupdatedLines.add(updatedLine);
                } else {
                    orderupdatedLines.add(line); 
                }           
            }
        } catch (IOException e) {
            System.err.println("Error reading order data: " + e.getMessage());
        }
        
        // write task
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(taskfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // write order
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(orderfile))) {
            for (String updatedLine : orderupdatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        //write notification
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(notificationfile, true))) {
                String notification = newNotificationId + "|NULL|individual|"+ receiver +"|Order_Cancel|" + formattedDate;
                writer.write(notification);
                writer.newLine();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing notification file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }
    
    
    
}




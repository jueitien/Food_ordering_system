/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RunnerClass;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author JYQ00
 */
public abstract class Revenue {
    protected String runnerId;

    
    public Revenue(String runnerId){
        this.runnerId = runnerId;
    }
    
    public String getID(){
        return runnerId;
    }
    
    public abstract List<String[]> getRevenue();
   
    public abstract Map<String, Double> getRevenueChart();
    
    public Double getTotalRevenue(String runnerId){
        double totalRevenue = 0;
        String filename = "src/data/deliveryrunnerrevenue.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            double userRevenue = 0;
            while((line = reader.readLine()) != null){
            String[] RevenueDetails = line.split("\\|");
            if(RevenueDetails[1].equals(runnerId)){
                 userRevenue = userRevenue + Double.parseDouble(RevenueDetails[4]);
                 
            }
            }
            totalRevenue = userRevenue;
        } catch (IOException e) {
            System.err.println("Error reading revenue data: " + e.getMessage());
        }
        return totalRevenue;
    }

}

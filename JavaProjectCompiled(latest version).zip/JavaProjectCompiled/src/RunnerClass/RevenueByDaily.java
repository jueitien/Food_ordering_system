/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RunnerClass;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author JYQ00
 */
public class RevenueByDaily extends Revenue{
    public RevenueByDaily(String runnerId) { super(runnerId); }

    @Override
    public List<String[]> getRevenue() {
        List<String[]> revenueData = new ArrayList<>();
        String filename = "src/data/deliveryrunnerrevenue.txt";
        System.out.println("runner id is " + getID());
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] revenueDetails = line.split("\\|"); 
                if(revenueDetails[1].equals(runnerId)){
                    String[] Details = {    
                    revenueDetails[3],     
                    revenueDetails[4]    
                    };
                    revenueData.add(Details);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading revenue data: " + e.getMessage());
        }
        Collections.reverse(revenueData);
        return revenueData;
    }
    
        @Override
    public Map<String, Double> getRevenueChart() {
        Map<String, Double> aggregatedRevenue = new HashMap<>();
        String revenueFile = "src/data/deliveryrunnerrevenue.txt";
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd-MM-yyyy");

        try (BufferedReader reader = new BufferedReader(new FileReader(revenueFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] revenueDetails = line.split("\\|");
                if (!runnerId.equals(revenueDetails[1])) continue;

                Date revenueDate = inputDateFormat.parse(revenueDetails[3]);
                double revenueAmount = Double.parseDouble(revenueDetails[4]);

                String key = getKeyForDaily(revenueDate); 
                aggregatedRevenue.put(key, aggregatedRevenue.getOrDefault(key, 0.0) + revenueAmount);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return aggregatedRevenue;
    }

    private String getKeyForDaily(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        return format.format(date); 
    }
}

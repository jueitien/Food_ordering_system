/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RunnerClass;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author JYQ00
 */
public class RevenueByMonth extends Revenue {
    public RevenueByMonth(String runnerId) { super(runnerId); }

    @Override
    public List<String[]> getRevenue() {
        List<String[]> revenueData = new ArrayList<>();
        String filename = "src/data/deliveryrunnerrevenue.txt";
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd-MM-yyyy");

        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            Map<String, Double> monthlyRevenue = new HashMap<>();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] revenueDetails = line.split("\\|");
                if (!runnerId.equals(revenueDetails[1])) continue;

                Date revenueDate = inputDateFormat.parse(revenueDetails[3]);
                double revenueAmount = Double.parseDouble(revenueDetails[4]);

                String monthKey = getKeyForMonth(revenueDate);
                monthlyRevenue.put(monthKey, monthlyRevenue.getOrDefault(monthKey, 0.0) + revenueAmount);
            }
            for (Map.Entry<String, Double> entry : monthlyRevenue.entrySet()) {
                revenueData.add(new String[]{entry.getKey(), String.format("%.2f", entry.getValue())});
            }

            revenueData.sort((o1, o2) -> o2[0].compareTo(o1[0])); // o1[0] = date,  

        } catch (Exception e) {
            System.err.println("Error reading revenue data: " + e.getMessage());
        }

        return revenueData;
    }
    
    @Override
    public Map<String, Double> getRevenueChart() {
        Map<String, Double> aggregatedRevenue = new HashMap<>();
        String revenueFile = "src/data/deliveryrunnerrevenue.txt";
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd-MM-yyyy");

        try (BufferedReader reader = new BufferedReader(new FileReader(revenueFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] revenueDetails = line.split("\\|");
                if (!runnerId.equals(revenueDetails[1])) continue;

                Date revenueDate = inputDateFormat.parse(revenueDetails[3]);
                double revenueAmount = Double.parseDouble(revenueDetails[4]);

                String key = getKeyForMonth(revenueDate); 
                aggregatedRevenue.put(key, aggregatedRevenue.getOrDefault(key, 0.0) + revenueAmount);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return aggregatedRevenue;
    }

    private String getKeyForMonth(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
        return format.format(date);
    }
}

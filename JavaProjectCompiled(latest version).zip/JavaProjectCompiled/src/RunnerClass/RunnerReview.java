/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RunnerClass;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author JYQ00
 */
public class RunnerReview{
    private String runnerId;

    // Constructor
    public RunnerReview(String reviewId, String runnerId, String customerId, double rating, String comment, String date) {
        this.runnerId = runnerId;
    }

    // Default Constructor
    public RunnerReview() {
        super();
    }

    // Getter and Setter for runnerId
    public String getRunnerId() {
        return runnerId;
    }

    public void setRunnerId(String runnerId) {
        this.runnerId = runnerId;
    }
    
    public double getRating(String runnerId){
        double overallReview = 0;
        String reviewfile = "src/data/deliveryrunnerreview.txt";
        try(BufferedReader reader = new BufferedReader(new FileReader(reviewfile))){
            String line;
            double total = 0;
            int count = 0;
            while((line = reader.readLine()) !=null){
                String [] reviewDetails = line.split("\\|");
                String id = reviewDetails[1];
                if(id.equals(runnerId)){
                    total += Double.parseDouble(reviewDetails[4]);
                    count++;
                }
            }
            overallReview = total/count;
        } catch (IOException e){
            System.err.println("Error reading review data: " + e.getMessage());
        }
        return overallReview;
    }
    
    public List<String[]> getReview(String runnerId){
        List<String[]> reviewData = new ArrayList<>();
        String reviewfile = "src/data/deliveryrunnerreview.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(reviewfile))){
            String line;
            while((line = reader.readLine()) !=null){
                String[] reviewDetails = line.split("\\|");
                String runnerid = reviewDetails[1];
                if(runnerid.equals(runnerId)){
                        String[] Details = {
                        reviewDetails[3], 
                        reviewDetails[2], 
                        reviewDetails[4],    
                        reviewDetails[5]     
                        };
                    reviewData.add(Details);
                    this.runnerId = runnerId;
                }
            }
        } catch (IOException e){
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return reviewData;
    }
    
    public List<String[]> getReviewsByRating(String runnerId,String selectedRating){
        List<String[]> reviewData = new ArrayList<>();
        String reviewfile = "src/data/deliveryrunnerreview.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader(reviewfile))){
            String line;
            while((line = reader.readLine()) !=null){
                String[] reviewDetails = line.split("\\|");
                String reviewRating = reviewDetails[4];
                
                if(runnerId.equals(reviewDetails[1])){
                    if(selectedRating.equals("ALL") || reviewRating.equals(selectedRating)){
                        String[] Details = {
                        reviewDetails[3], 
                        reviewDetails[2], 
                        reviewDetails[4],    
                        reviewDetails[5]     
                        };
                        reviewData.add(Details);
                    }
                }
            }
            
        } catch (IOException e){
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return reviewData;
    }
    
    
}
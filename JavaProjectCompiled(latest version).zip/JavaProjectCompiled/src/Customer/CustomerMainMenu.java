/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Customer;

import CustomerClass.CustomPanelFood;
import CustomerClass.CustomPanelVendor;
import CustomerClass.Customer;
import CustomerClass.BoardCleaner;
import CustomerClass.ComplaintBox;
import CustomerClass.CustomPanelHistory;
import CustomerClass.CustomPanelNotification;
import CustomerClass.CustomPanelOrder;
import CustomerClass.CustomPanelReview;
import CustomerClass.CustomPanelStarRating;
import CustomerClass.CustomPanelTransaction;
import CustomerClass.CustomerReview;
import CustomerClass.DeliveryRunnerReview;
import CustomerClass.DeliveryRunnerTask;
import CustomerClass.Notification;
import CustomerClass.Order;
import CustomerClass.ItemOrder;
import CustomerClass.OrderStatusUpdater;
import CustomerClass.TransactionLog;
import CustomerClass.Vendor;
import CustomerClass.VendorItemMenu;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author user
 */
public class CustomerMainMenu extends javax.swing.JFrame {

    /**
     * Creates new form CustomerMainMenu
     */
    CardLayout cardLayout;
    BoardCleaner cleaner = new BoardCleaner();
    //initialize hasmap for cart count
    private final Map<String, Integer> inCartCount = new HashMap<>();
    private String customerID, vendorID, lastVendorID, newVendorID, currentCard = "", username, vendorName, vendorIDTemp, orderIDTemp;
    public String orderID;
    public int customerStarRating, riderStarRating;
    private double totalAmount = 0.0, creditAmount;
    public boolean proceedAdding;
    private Order orderTemp;

    //testing
    private int status = 0;

    //status icon
    private static final String PENDINGICON = "src/iconJava/pendingIcon.png";
    private static final String PREPARINGICON = "src/iconJava/preparingIcon.png";
    private static final String PREPAREDICON = "src/iconJava/preparedIcon.png";
    private static final String DELIVERINGICON = "src/iconJava/deliveringIcon.png";
    private static final String COMPLETEDICON = "src/iconJava/confirmICon.png";
    private static final String CANCELLEDICON = "src/iconJava/cancelledIcon.png";
    private static final String CHICKENICON = "src/iconJava/chickenIcon.png";
    private static final String PROFILEICON = "src/iconJava/profileIcon.png";

//    private static final String FILLEDSTARICON = "src/iconJava/filledStarIcon.png";
    public CustomerMainMenu() {
        initComponents();
        //on start up initialization for the main menu
        initializeMainMenu();
//        starPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
//        leaveStarPanel2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
//        leaveStarPanel3.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
    }

    //set who will be using the system
    public void setUser(Customer customer) {
        this.customerID = customer.getCustomerID();
        this.creditAmount = customer.getCredit();
        this.username = customer.getUsername();
        usernameButton.setText(username);
        creditButton.setText(String.format("%.2f", creditAmount));
    }

    void initializeMainMenu() {
        //need to manually initialize each card for some reason
        cardLayout = (CardLayout) (mainPanel.getLayout());
        mainPanel.add(menuCard, "menuCard");
        mainPanel.add(orderStatusCard, "orderStatusCard");
        mainPanel.add(profileCard, "profileCard");
        mainPanel.add(walletCard, "walletCard");
        mainPanel.add(historyCard, "historyCard");
        mainPanel.add(foodCard, "foodCard");
        mainPanel.add(reviewCard, "reviewCard");
        mainPanel.add(historyDetailCard, "historyDetailCard");
        mainPanel.add(leaveReviewCard1, "leaveReviewCard1");
        mainPanel.add(leaveReviewCard2, "leaveReviewCard2");
        mainPanel.add(complaintCard, "complaintCard");

        //read all relevant data for main menu
        VendorItemMenu.readVendorItemMenuData();
        Vendor.readVendorData();
        Order.readOrderData();
        Notification.readNotificationData();
        TransactionLog.readTransactionLogData();
        Customer.readCustomerData();
        CustomerReview.readCustomerReviewData();
        //add board to cleaner
        cleaner.addPanelBoard("vendorBoard", panelBoard);
        cleaner.addPanelBoard("foodBoard", panelBoardFood);
        cleaner.addPanelBoard("orderBoard", panelBoardOrder);
        cleaner.addPanelBoard("notificationBoard", panelBoardNotification);
        cleaner.addPanelBoard("transactionBoard", panelBoardTransaction);
        cleaner.addPanelBoard("reviewBoard", panelBoardReview);
        cleaner.addPanelBoard("historyBoard", panelBoardHistory);
        cleaner.addPanelBoard("historyDetailBoard", panelBoardHistoryDetail);
        cleaner.addPanelBoard("starRatingBoard", starPanel);
        cleaner.addPanelBoard("starRatingBoard1", starPanel1);
        cleaner.addPanelBoard("starRatingBoard2", starPanel2);
        //show the vendor card as default
        String targetCard = "menuCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayVendor();
        }
        updateOrderStatus(0);
        setDate();
        setTime();
    }

    void setDate() {

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedDate = currentDate.format(formatter);
        dateLabel.setText(formattedDate);
    }

    void setTime() {
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        String formattedTime = currentTime.format(formatter);
        timeLabel.setText(formattedTime);
        Timer timer = new Timer(1000, (ActionEvent e) -> {
            LocalTime updatedTime = LocalTime.now();
            String updatedformattedTime = updatedTime.format(formatter);
            timeLabel.setText(updatedformattedTime);
        });
        timer.start();
    }

    public void displayVendor() {
        ArrayList<Vendor> vendors = Vendor.getAllVendor();

        for (Vendor vendor : vendors) {
            String vendorName1 = vendor.getUsername();
            String vendorIDDisplay = vendor.getVendorID();
            //pass vendor name and this constructor instance to preserve the customer details
            CustomPanelVendor customPanel = new CustomPanelVendor(vendorName1, vendorIDDisplay, this);
            panelBoard.add(customPanel);
        }
    }

    //main function displays the item menu of the selected vendor
    //checks if there are any items in cart, if empty, set status to 0, else enable the place order button
    //clear all board then shows the foodCard
    //filter items based on clicked vendor id using vendor name
    //filter items based on item status
    //update the cartcount to the previous cart count
    //set vendorNameLabel to the selected vendor name
    public void displayVendorItemMenu(String vendorID) {
        cleaner.cleanAllBoard();
        cardLayout.show(mainPanel, "foodCard");
        this.vendorName = null;
        ArrayList<VendorItemMenu> vendorItemMenus = VendorItemMenu.getAllVendorItemMenu();
        for (VendorItemMenu vendorItemMenu : vendorItemMenus) {
            if (vendorItemMenu.getVendorID().equals(vendorID)) {
                String vendorItemMenuStatus = vendorItemMenu.getItemStatus();
                if (vendorItemMenuStatus.equalsIgnoreCase("true")) {
                    Vendor vendor = Vendor.getVendorByVendorID(vendorID);
                    this.vendorName = vendor.getUsername();
                    this.vendorIDTemp = vendor.getVendorID();
                    String vendorItemMenuID = vendorItemMenu.getItemID();
                    String vendorItemMenuName = vendorItemMenu.getItemName().replace("_", " ");
                    String vendorItemMenuDesc = vendorItemMenu.getItemDesc().replace("_", " ");
                    Double vendorItemMenuPrice = vendorItemMenu.getItemPrice();
                    CustomPanelFood customPanelFood = new CustomPanelFood(vendorItemMenuName, vendorID, this, vendorItemMenuDesc, vendorItemMenuPrice, vendorItemMenuID);
                    int pastCartCount = getCartCount(vendorItemMenuID);
                    customPanelFood.setCartCount(pastCartCount);
                    panelBoardFood.add(customPanelFood);
                    vendorNameLabel.setText(vendorName);
                }
            }
        }
    }

    public void displayOrderMenu() {
//        System.out.println("displaycalled");
        if (inCartCount.isEmpty()) {
            updateOrderStatus(0);
        } else {
            placeOrderButton.setEnabled(true);
            orderPlacementCB.setEnabled(true);
        }

        for (Map.Entry<String, Integer> entry : inCartCount.entrySet()) {
            String itemMenuID = entry.getKey();
            int itemCount = entry.getValue();

            VendorItemMenu vendorItemMenu = VendorItemMenu.getVendorItemMenuByID(itemMenuID);

            this.vendorID = vendorItemMenu.getVendorID();

            CustomPanelOrder customPanelOrder = new CustomPanelOrder(vendorItemMenu, this, itemCount, false);
            customPanelOrder.setCartCount(itemCount);
            panelBoardOrder.add(customPanelOrder);
        }
        totalAmount = 0;
        enterTotalAmount();
        updateStatus();

    }

    public void updateStatus() {
        Order.readOrderData();
        if (this.orderID != null) {
            Order order = Order.getOrderByOrderID(this.orderID);
            if (order != null) {
                Object[] statusCurrent = order.updateOrderCurrent();
                int statusNumber = (int) statusCurrent[0];
                boolean riderDecline = (boolean) statusCurrent[1];
                updateOrderStatus(statusNumber);
                updateOrderRider(riderDecline);
            }
        }
    }

    public void updateCartCount(String itemID, int count) {
        inCartCount.put(itemID, count);
    }

    public int getCartCount(String itemID) {
        return inCartCount.getOrDefault(itemID, 0);
    }

    public void updateTotalAmount(double itemPrice, int itemCount, boolean addUp) {
        if (addUp) {
            totalAmount += itemPrice;
        } else {
            totalAmount -= itemPrice;
            if (totalAmount < 0) {
                totalAmount = 0.0;
            }
        }
        if (totalAmount == 0.0) {
            placeOrderButton.setEnabled(false);
            orderPlacementCB.setEnabled(false);
        }
        inCartTotal.setText(String.format("%.2f", totalAmount));
    }

    public void enterTotalAmount() {
        if (!inCartCount.isEmpty()) {
            for (Map.Entry<String, Integer> entry : inCartCount.entrySet()) {
                String itemMenuID = entry.getKey();
                int itemCount = entry.getValue();

                VendorItemMenu vendorItemMenu = VendorItemMenu.getVendorItemMenuByID(itemMenuID);

                if (vendorItemMenu != null) {
                    Double vendorItemMenuPrice = vendorItemMenu.getItemPrice();

                    totalAmount += vendorItemMenuPrice * itemCount;
                }
            }
        } else {
            totalAmount = 0.0;
            placeOrderButton.setEnabled(false);
            orderPlacementCB.setEnabled(false);
        }
        inCartTotal.setText(String.format("%.2f", totalAmount));
    }

    //main function set everything in place after customer confirm their order
    //calculate credit left after deduction then format it into 2 decibels string
    //create new order id then set current global order id to the newly created one, also call the set order function
    //create new transaction id then set call the set transaction function
    //create new notification id then set call the set notification function
    //set current date and time then format it 
    //call the set order item function (different from set order)
    //start the status update task
    //call the deduct credit function from customer class
    //set wallet credit amount to the new amount
    //notify user about order place and credit deducted
    public void placeOrder() {
        double creditAmountLeft = creditAmount - totalAmount;
        String formattedCreditAfter = String.format("%.2f", creditAmountLeft);

        Order order = new Order();
        String newOrderID = order.newID();
        this.orderID = newOrderID;

        TransactionLog transaction = new TransactionLog();
        String newTransactionID = transaction.newID();

        Notification notification = new Notification();
        String newNotificationID = notification.newID();

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedDate = currentDate.format(dateFormatter);

        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        String formattedTime = currentTime.format(timeFormatter);

        setOrder(order, newOrderID, newTransactionID, formattedDate, formattedTime);

        setTransaction(transaction, newTransactionID, formattedDate, formattedTime, formattedCreditAfter);

        setNotification(notification, newOrderID, newNotificationID, formattedDate);

        setOrderItem(newOrderID);

        //start update status task every 5 minutes
        OrderStatusUpdater updater = new OrderStatusUpdater();
        updater.startSUTask(this);

        //deduct credit from customer wallet
        Customer customer = new Customer();
        customer.creditUpdateFile(customerID, formattedCreditAfter);
        creditButton.setText(formattedCreditAfter);
        JOptionPane.showMessageDialog(null, "Your order had been placed!\n" + totalAmount + " had been dedcuted from your wallet.", "Notification", JOptionPane.INFORMATION_MESSAGE);
    }

    private void setOrder(Order order, String newOrderID, String newTransactionID, String formattedDate, String formattedTime) {
        order.setOrderID(newOrderID);
        order.setCustomerID(this.customerID);
        order.setVendorID(this.vendorID);
        order.setTransactionID(newTransactionID);
        order.setOrderDate(formattedDate);
        order.setOrderTime(formattedTime);
        order.setOrderTotal(Double.parseDouble(inCartTotal.getText()));
        order.setOrderPlacement(orderPlacementCB.getSelectedItem().toString());
        order.setVendorAccepted("null");
        order.setRunnerAccepted("null");
        order.setOrderStatus("Pending");

        order.writeNewOrder(order);
    }

    private void setTransaction(TransactionLog transaction, String newTransactionID, String formattedDate, String formattedTime, String formattedCreditAfter) {
        transaction.setTransactionID(newTransactionID);
        transaction.setCustomerID(customerID);
        transaction.setCreditBefore(Double.parseDouble(creditButton.getText()));
        transaction.setCreditAfter(Double.parseDouble(formattedCreditAfter));
        transaction.setIsRefund("false");
        transaction.setTransactionDate(formattedDate);
        transaction.setTransactionTime(formattedTime);

        transaction.writeNewLog(transaction);
//        System.out.println(transaction);
    }

    private void setNotification(Notification notification, String newOrderID, String newNotificationID, String formattedDate) {
        String messageSend = "Order ID " + newOrderID + " is placed.";
        notification.setNotificationID(newNotificationID);
        notification.setSenderID(this.customerID);
        notification.setNotificationType("individual");
        notification.setRecipientID(this.vendorID);
        notification.setNotificationText(messageSend.replace(" ", "_"));
        notification.setNotificationDate(formattedDate);

        notification.writeNewNotification(notification);
//        System.out.println(notification);
    }

    private void setOrderItem(String newOrderID) {

        for (Map.Entry<String, Integer> entry : inCartCount.entrySet()) {

            ItemOrder orderItem = new ItemOrder();

            String itemMenuID = entry.getKey();
            int itemCount = entry.getValue();

            VendorItemMenu vendorItemMenu = VendorItemMenu.getVendorItemMenuByID(itemMenuID);

            if (vendorItemMenu != null) {

                Double vendorItemMenuPrice = vendorItemMenu.getItemPrice();
                double itemTotalPrice = vendorItemMenuPrice * itemCount;
                String formattedItemTotalPrice = String.format("%.2f", itemTotalPrice);

                orderItem.setOrderItemID(orderItem.newID());
                orderItem.setOrderID(newOrderID);
                orderItem.setItemID(itemMenuID);
                orderItem.setItemQuantity(itemCount);
                orderItem.setItemTotal(Double.parseDouble(formattedItemTotalPrice));

                orderItem.writeNewOrderItem(orderItem);
//                System.out.println(orderItem);
            }

        }

    }

    //main function update order status visually based on given status
    //sets icon image for each status
    //sets status text for each status
    //complete icon sets place order button to complete order button
    public void updateOrderStatus(int status) {
        String iconPath, statusText;

        switch (status) {
            case 1 -> {
                iconPath = PENDINGICON;
                statusText = "We're waiting for the vendor to accept your order. Hang tight!";
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
            }
            case 2 -> {
                iconPath = PREPARINGICON;
                statusText = "The vendor is busy preparing your delicious order. Please wait!";
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
            }
            case 3 -> {
                iconPath = PREPAREDICON;
                statusText = "Good news! Your order is ready for pickup or delivery.";
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
            }
            case 4 -> {
                iconPath = DELIVERINGICON;
                statusText = "Your order is on its way! The delivery runner will arrive soon.";
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
            }
            case 5 -> {
                iconPath = COMPLETEDICON;
                statusText = "Enjoy your meal! Thank you for ordering with us.";
                placeOrderButton.setEnabled(true);
                placeOrderButton.setText("Start New Order");
                //stops the status update task
                OrderStatusUpdater updater = new OrderStatusUpdater();
                updater.stopSUTask();
            }
            case 6 -> {
                iconPath = CANCELLEDICON;
                statusText = "We're sorry to inform you that your order has been cancelled.";
                JOptionPane.showMessageDialog(null, "Your order had been rejected! Why not try something else from our menu?", "Notification", JOptionPane.INFORMATION_MESSAGE);
                placeOrderButton.setEnabled(true);
                placeOrderButton.setText("Start New Order");
                //stops the status update task
                OrderStatusUpdater updater = new OrderStatusUpdater();
                updater.stopSUTask();
            }
            default -> {
                iconPath = CHICKENICON;
                statusText = "Your cart is empty! Why not explore our menu and order something delicious?";
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
            }
        }

        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            orderStatusLabel.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            orderStatusLabel.setText("Icon Missing");
        }
        orderStatusText.setText(statusText);
    }

    public void updateOrderRider(boolean riderDecline) {
        if (riderDecline) {
            String[] options = {"Dine-In", "Takeaway"};
            String choosenOption = "Dine-in";
            int riderDeclineNotify = JOptionPane.showOptionDialog(
                    null,
                    "There seem to be no delivery runner around to accept your current order.\nPlease choose to either dine-in or take away your order.", "We're Sorry!",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );
            switch (riderDeclineNotify) {
                case 0 ->
                    JOptionPane.showMessageDialog(null, "Your order placment had been updated to " + choosenOption, "Take Note!", JOptionPane.INFORMATION_MESSAGE);
                case 1 -> {
                    choosenOption = "Take-away";
                    JOptionPane.showMessageDialog(null, "Your order placment had been updated to " + choosenOption, "Take Note!", JOptionPane.INFORMATION_MESSAGE);
                }
                default ->
                    JOptionPane.showMessageDialog(null, "Your order placment had been updated to " + choosenOption + " by default!", "Take Note!", JOptionPane.INFORMATION_MESSAGE);
            }
            Order order = new Order();
            String currentOrderID = this.orderID;
            order.setOrderPlacement(choosenOption);
            order.orderPlacementUpdateFile(currentOrderID, choosenOption);
        }
    }

    //main function removes count 0 items from hashmap
    //resets the display order menu
    public void removeCountZeroItem() {
        for (Iterator<Map.Entry<String, Integer>> iterator = inCartCount.entrySet().iterator(); iterator.hasNext();) {
            Map.Entry<String, Integer> entry = iterator.next();
            if (entry.getValue() == 0) {
                iterator.remove();
            }
        }
        cleaner.cleanAllBoard();
        displayOrderMenu();
    }

    //main function checks placement type combo box status
    //adds 10 credit when placement type is deliver
    //resets combo box if resetCB is true
    public void PlacementTypeStatusCB(boolean resetCB) {
        if (resetCB) {
            orderPlacementCB.setSelectedIndex(0);
        }

        String selectedItem = (String) orderPlacementCB.getSelectedItem();
        totalAmount = 0;
        if ("Delivery".equalsIgnoreCase(selectedItem)) {
            totalAmount += 10;
        }
        enterTotalAmount();
    }

    public void setLastVendorID(String addedlastVendorID) {
        if (inCartCount.isEmpty()) {
            this.lastVendorID = addedlastVendorID;
        }
    }

    public void checkVendorID(String itemMenuID) {
        proceedAdding = true;

        VendorItemMenu vendorItemMenu = VendorItemMenu.getVendorItemMenuByID(itemMenuID);
        newVendorID = vendorItemMenu != null ? vendorItemMenu.getVendorID() : null;

        if (lastVendorID != null && newVendorID != null && !lastVendorID.equals(newVendorID)) {
            int choice = JOptionPane.showConfirmDialog(null,
                    "Your cart contains items from a different vendor. Do you want to clear the cart and add this item?",
                    "Notification",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (choice == JOptionPane.YES_OPTION) {
                inCartCount.clear();
                lastVendorID = newVendorID;
            } else {
                proceedAdding = false;
            }
        }
    }

    public boolean getProceedAdding() {
        return proceedAdding;
    }

    public void displayProfileMenu() {
        setProfileIcon();
        usernameLabel.setText(username);
        creditLabel.setText(String.format("%.2f", creditAmount));
        findNotification(this.customerID);
    }

    public void setProfileIcon() {
        String iconPath = PROFILEICON;
        //catch error for icon placement
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(110, 100, Image.SCALE_SMOOTH);
            profileLabel.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            profileLabel.setText("Icon Missing");
        }
    }

    public void findNotification(String customerID) {
//        Notification notification = new Notification();
////        System.out.println(this.customerID);
//        notification.readTransactionLogData();
        ArrayList<Notification> allNotification = Notification.getNotificationByCustomerID(customerID, false);

        if (!allNotification.isEmpty()) {
            for (Notification notification1 : allNotification) {
                CustomPanelNotification customPanelNotfication = new CustomPanelNotification(notification1);
                panelBoardNotification.add(customPanelNotfication);
//                System.out.println("notification " + customPanelNotfication);
            }
        }
    }

    public void clearAllNotification() {
        System.out.println("clearAllNotification called");
        ArrayList<Notification> notifications = Notification.getNotificationByCustomerID(customerID, true);
//        System.out.println(notifications);
        if (!notifications.isEmpty()) {
            System.out.println("notification not empty");
            for (Notification notification1 : notifications) {
                Notification notification = new Notification();
                notification.deleteNotification(notification1);
                for (Component component : panelBoardNotification.getComponents()) {
                    CustomPanelNotification panel = (CustomPanelNotification) component;
                    if (panel.matchesNotification(notification1)) {
                        panelBoardNotification.remove(panel);
                        System.out.println("panel removed");
                    }
                }
            }
            panelBoardNotification.revalidate();
            panelBoardNotification.repaint();
            System.out.println("notification cleared all");
        }
    }

    public void displayReviewMenu() {
        vendorNameLabel1.setText(vendorName);
//        ArrayList<CustomerReview> allCustomerReview = CustomerReview.getAllCustomerReview();
//        System.out.println("review " + allCustomerReview);

        ArrayList<CustomerReview> allReview = CustomerReview.getReviewByVendorID(this.vendorIDTemp);

        if (!allReview.isEmpty()) {
            for (CustomerReview customerReview : allReview) {
                CustomPanelReview customPanelReview = new CustomPanelReview(customerReview);
                panelBoardReview.add(customPanelReview);
                System.out.println("review " + customPanelReview);
            }
        }
    }

    public void displayWalletMenu() {

        TransactionLog.readTransactionLogData();
        ArrayList<TransactionLog> transactions = TransactionLog.getTransactionLogByCustomerID(customerID);

        if (!transactions.isEmpty()) {
            for (TransactionLog transaction1 : transactions) {
                CustomPanelTransaction customPanelTransaction = new CustomPanelTransaction(transaction1);
                panelBoardTransaction.add(customPanelTransaction);
//                System.out.println("transaction " + customPanelTransaction);
            }
        }
    }

    public void displayHistoryMenu() {
//        System.out.println(">>> displayOrderMenu() CALLED");
//        new Exception().printStackTrace();

//        panelBoardHistory.removeAll();
//        panelBoardHistory.revalidate();
//        panelBoardHistory.repaint();
        ItemOrder.readOrderItemData();
        DeliveryRunnerTask.readRiderTaskData();
        CustomerReview.readCustomerReviewData();
        DeliveryRunnerReview.readRiderReviewData();
        ComplaintBox.readComplaintBoxData();
        ArrayList<Order> allOrder = Order.getOrderByCustomerID(this.customerID);

        if (!allOrder.isEmpty()) {
            for (Order order : allOrder) {
                CustomPanelHistory customPanelHistory = new CustomPanelHistory(order, this);
                panelBoardHistory.add(customPanelHistory);
//                System.out.println("history " + customPanelHistory);
            }
        }
//        System.out.println("Final history panel count: " + panelBoardHistory.getComponentCount());
    }

    public void displayHistoryDetailMenu(Order order) {
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
        }

        this.orderTemp = order;

        HDVendorNameLabel.setText(Vendor.getVendorUsernameByVendorID(order.getVendorID()));
        this.orderIDTemp = order.getOrderID();
        System.out.println(this.orderIDTemp);
        checkReviewComplaint();

        HDTimeLabel.setText("Time: " + order.getOrderTime());
        HDDateLabel.setText("Date: " + order.getOrderDate());
        totalItemAmountLabel.setText("Total item amount: " + ItemOrder.totalCustomerOrderItem(order.getOrderID()) + "");
        totalCostLabel.setText("Total cost: " + order.getOrderTotal() + "");
        lastStatusLabel.setText("Last status: " + order.getOrderStatus());
        orderTypeLabel.setText("Order placement type: " + order.getOrderPlacement());

        ArrayList<ItemOrder> allOrderItems = ItemOrder.getOrderItemByOrderID(order.getOrderID());

        for (ItemOrder orderItem1 : allOrderItems) {
            VendorItemMenu vendorItemMenu = VendorItemMenu.getVendorItemMenuByID(orderItem1.getItemID());
            CustomPanelOrder customPanelOrder = new CustomPanelOrder(vendorItemMenu, this, orderItem1.getItemQuantity(), true);
            panelBoardHistoryDetail.add(customPanelOrder);
        }

    }

    public void checkReviewComplaint() {
        CustomerReview.readCustomerReviewData();
        ComplaintBox.readComplaintBoxData();
        this.orderIDTemp = this.orderTemp.getOrderID();

        if (CustomerReview.checkReviewByCustomerID(this.orderIDTemp, this.customerID)) {
            leaveReviewButton.setText("Already Review");
            leaveReviewButton.setEnabled(false);
        } else {
            leaveReviewButton.setText("Leave Review");
            leaveReviewButton.setEnabled(true);
        }

        if (ComplaintBox.checkComplaintByCustomerID(this.orderIDTemp, this.customerID)) {
            complaintButton.setEnabled(false);
        } else {
            complaintButton.setEnabled(true);
        }
    }

    public void setStarIcon1() {
        starPanel.removeAll();
        starPanel.revalidate();
        starPanel.repaint();

        starPanel1.removeAll();
        starPanel1.revalidate();
        starPanel1.repaint();

        starPanel2.removeAll();
        starPanel2.revalidate();
        starPanel2.repaint();

        starPanel.setLayout(new FlowLayout());
        starPanel1.setLayout(new FlowLayout());
        starPanel2.setLayout(new FlowLayout());
        CustomPanelStarRating customPanelStarRating = new CustomPanelStarRating(this, false);
        CustomPanelStarRating customPanelStarRating1 = new CustomPanelStarRating(this, true);
        CustomPanelStarRating customPanelStarRating2 = new CustomPanelStarRating(this, false);
        starPanel.add(customPanelStarRating);
        starPanel1.add(customPanelStarRating1);
        starPanel2.add(customPanelStarRating2);

        starPanel.revalidate();
        starPanel.repaint();
        starPanel1.revalidate();
        starPanel1.repaint();
        starPanel2.revalidate();
        starPanel2.repaint();
    }

    public void displayLeaveReviewTemp() {
        reviewVendorNameLabel1.setText("Reviewing: " + Vendor.getVendorUsernameByVendorID(Order.getVendorIDByOrderID(this.orderIDTemp)));
        reviewVendorNameLabel2.setText("Reviewing: " + Vendor.getVendorUsernameByVendorID(Order.getVendorIDByOrderID(this.orderIDTemp)));
    }

    public void setCustomerStarRating(int reviewCustomerStarRating) {
        this.customerStarRating = reviewCustomerStarRating;
    }

    public void setRiderStarRating(int reviewRiderStarRating) {
        this.riderStarRating = reviewRiderStarRating;
    }

    public void postReview() {
        CustomerReview customerReview = new CustomerReview();
        String newCustomerReviewID = customerReview.newID();

        Order order = Order.getOrderByOrderID(this.orderIDTemp);

        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedDate = currentDate.format(dateFormatter);

        if (null == currentCard) {
            System.out.println("unknown error");
        } else {
            switch (currentCard) {
                case "leaveReviewCard1" -> {
                    String vendorReview = reviewVendorTextArea1.getText().replace(" ", "_");
                    DeliveryRunnerReview deliveryRunnerReview = new DeliveryRunnerReview();
                    String newRiderReviewID = deliveryRunnerReview.newID();
                    DeliveryRunnerTask deliveryRunnerTask = DeliveryRunnerTask.getRiderTaskByOrderID(order.getOrderID());
                    setCustomerReview(customerReview, order, newCustomerReviewID, vendorReview, formattedDate);
                    setRiderReview(deliveryRunnerReview, deliveryRunnerTask, newRiderReviewID, formattedDate);
                    System.out.println("customer & rider");
                }
                case "leaveReviewCard2" -> {
                    String vendorReview = reviewVendorTextArea2.getText().replace(" ", "_");
                    setCustomerReview(customerReview, order, newCustomerReviewID, vendorReview, formattedDate);
                    System.out.println("customer");
                }
                default ->
                    System.out.println("unknown error");
            }
        }

    }

    private void setCustomerReview(CustomerReview customerReview, Order order, String newCustomerReviewID, String vendorReview, String formattedDate) {
        customerReview.setReviewID(newCustomerReviewID);
        customerReview.setVendorID(Vendor.getVendorUsernameByVendorID(order.getVendorID()));
        customerReview.setOrderID(order.getOrderID());
        customerReview.setCustomerID(this.customerID);
        customerReview.setStarRating(this.customerStarRating);
        customerReview.setCustomerReview(vendorReview);
        customerReview.setReviewDate(formattedDate);

        customerReview.writeNewCustomerReview(customerReview);
    }

    private void setRiderReview(DeliveryRunnerReview deliveryRunnerReview, DeliveryRunnerTask deliveryRunnerTask, String newRiderReviewID, String formattedDate) {
        deliveryRunnerReview.setRiderReviewID(newRiderReviewID);
        deliveryRunnerReview.setRiderID(deliveryRunnerTask.getRiderID());
        deliveryRunnerReview.setCustomerID(this.customerID);
        deliveryRunnerReview.setRiderRating(this.riderStarRating);
        deliveryRunnerReview.setRiderReview(reviewRiderTextArea.getText().replace(" ", "_"));
        deliveryRunnerReview.setReviewDate(formattedDate);

        deliveryRunnerReview.writeNewRiderReview(deliveryRunnerReview);
        System.out.println("Rider Review added");
    }

    public void displayComplaintTemp() {
        reviewVendorNameLabel1.setText("Complaining: " + Vendor.getVendorUsernameByVendorID(Order.getVendorIDByOrderID(this.orderIDTemp)));
    }

    public void postComplaint() {
        ComplaintBox complaintBox = new ComplaintBox();
        String newComplaintBoxID = complaintBox.newID();

        setComplaintBox(complaintBox, newComplaintBoxID);
    }

    private void setComplaintBox(ComplaintBox complaintBox, String newComplaintBoxID) {
        complaintBox.setComplaintID(newComplaintBoxID);
        complaintBox.setCustomerID(this.customerID);
        complaintBox.setOrderID(this.orderIDTemp);
        complaintBox.setManagerID(Vendor.getManagerIDByVendorID(Order.getVendorIDByOrderID(this.orderIDTemp)));
        complaintBox.setComplaint(complaintVendorTextArea.getText().replace(" ", "_"));

        complaintBox.writeNewCustomerReview(complaintBox);
    }

    public void reorderItem() {

        ArrayList<ItemOrder> allOrderItems = ItemOrder.getOrderItemByOrderID(this.orderTemp.getOrderID());

        for (ItemOrder orderItem1 : allOrderItems) {
            inCartCount.put(orderItem1.getItemID(), orderItem1.getItemQuantity());
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton9 = new javax.swing.JButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        SidePanel = new javax.swing.JPanel();
        usernameButton = new javax.swing.JButton();
        creditButton = new javax.swing.JButton();
        orderStatusButton = new javax.swing.JButton();
        historyButton = new javax.swing.JButton();
        menuButton = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        dateLabel = new javax.swing.JLabel();
        timeLabel = new javax.swing.JLabel();
        mainPanel = new javax.swing.JPanel();
        menuCard = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelBoard = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        foodCard = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        panelBoardFood = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel16 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        menuBackButton = new javax.swing.JButton();
        reviewLabel = new javax.swing.JLabel();
        vendorNameLabel = new javax.swing.JLabel();
        reviewCard = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        panelBoardReview = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        foodMenuBackButton = new javax.swing.JButton();
        reviewLabelPressed = new javax.swing.JLabel();
        vendorNameLabel1 = new javax.swing.JLabel();
        profileCard = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        profileLabel = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        usernameLabel = new javax.swing.JLabel();
        creditLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        panelBoardNotification = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        clearAllLabel = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        walletCard = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        panelBoardTransaction = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        orderStatusCard = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        orderStatusLabel = new javax.swing.JLabel();
        orderStatusText = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        panelBoardOrder = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        orderPlacementCB = new javax.swing.JComboBox<>();
        inCartTotal = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        placeOrderButton = new javax.swing.JButton();
        totalLabel = new javax.swing.JLabel();
        historyCard = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        panelBoardHistory = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        historyDetailCard = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        panelBoardHistoryDetail = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        HDDateLabel = new javax.swing.JLabel();
        HDVendorNameLabel = new javax.swing.JLabel();
        HDTimeLabel = new javax.swing.JLabel();
        historyDetailbackButton = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        totalCostLabel = new javax.swing.JLabel();
        orderTypeLabel = new javax.swing.JLabel();
        totalItemAmountLabel = new javax.swing.JLabel();
        lastStatusLabel = new javax.swing.JLabel();
        complaintButton = new javax.swing.JButton();
        leaveReviewButton = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel31 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        leaveReviewCard1 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        reviewVendorNameLabel1 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        reviewVendorTextArea1 = new javax.swing.JTextArea();
        jScrollPane13 = new javax.swing.JScrollPane();
        reviewRiderTextArea = new javax.swing.JTextArea();
        jPanel43 = new javax.swing.JPanel();
        reviewCancelButton1 = new javax.swing.JButton();
        reviewPostButton1 = new javax.swing.JButton();
        starPanel = new javax.swing.JPanel();
        starPanel1 = new javax.swing.JPanel();
        leaveReviewCard2 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        reviewVendorNameLabel2 = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        starPanel2 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        reviewVendorTextArea2 = new javax.swing.JTextArea();
        jPanel49 = new javax.swing.JPanel();
        reviewCancelButton2 = new javax.swing.JButton();
        reviewPostButton2 = new javax.swing.JButton();
        complaintCard = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel38 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        complaintVendorTextArea = new javax.swing.JTextArea();
        jPanel39 = new javax.swing.JPanel();
        complaintCancelButton = new javax.swing.JButton();
        postComplaintButton = new javax.swing.JButton();

        jButton9.setText("jButton9");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SidePanel.setBackground(java.awt.Color.white);
        SidePanel.setPreferredSize(new java.awt.Dimension(180, 100));

        usernameButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/profileIcon.png"))); // NOI18N
        usernameButton.setText("username");
        usernameButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usernameButton.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        usernameButton.setPreferredSize(new java.awt.Dimension(75, 20));
        usernameButton.setVerifyInputWhenFocusTarget(false);
        usernameButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameButtonActionPerformed(evt);
            }
        });

        creditButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/walletIcon_30.png"))); // NOI18N
        creditButton.setText("0.00");
        creditButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        creditButton.setPreferredSize(new java.awt.Dimension(75, 20));
        creditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                creditButtonActionPerformed(evt);
            }
        });

        orderStatusButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/chickenICon (1).png"))); // NOI18N
        orderStatusButton.setText("Order");
        orderStatusButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        orderStatusButton.setPreferredSize(new java.awt.Dimension(75, 20));
        orderStatusButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderStatusButtonActionPerformed(evt);
            }
        });

        historyButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/historyIcon (1).png"))); // NOI18N
        historyButton.setText("History");
        historyButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        historyButton.setPreferredSize(new java.awt.Dimension(75, 20));
        historyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                historyButtonActionPerformed(evt);
            }
        });

        menuButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/menuIcon (1).png"))); // NOI18N
        menuButton.setText("Menu");
        menuButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        menuButton.setPreferredSize(new java.awt.Dimension(75, 20));
        menuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuButtonActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255,255,255,100));

        dateLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        dateLabel.setText("Date");

        timeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        timeLabel.setText("Time");
        timeLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(dateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateLabel)
                    .addComponent(timeLabel))
                .addContainerGap())
        );

        javax.swing.GroupLayout SidePanelLayout = new javax.swing.GroupLayout(SidePanel);
        SidePanel.setLayout(SidePanelLayout);
        SidePanelLayout.setHorizontalGroup(
            SidePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SidePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(creditButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(usernameButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(orderStatusButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(historyButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(menuButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        SidePanelLayout.setVerticalGroup(
            SidePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SidePanelLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(usernameButton, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(creditButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(orderStatusButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(menuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(historyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jSplitPane1.setLeftComponent(SidePanel);

        mainPanel.setPreferredSize(new java.awt.Dimension(800, 650));
        mainPanel.setLayout(new java.awt.CardLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        panelBoard.setBorder(javax.swing.BorderFactory.createEmptyBorder(50, 50, 50, 50));
        panelBoard.setLayout(new java.awt.GridLayout(0, 2, 30, 30));

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel14.setMaximumSize(new java.awt.Dimension(300, 300));
        jPanel14.setPreferredSize(new java.awt.Dimension(300, 300));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/restaurantIcon (1).png"))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Western1");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelBoard.add(jPanel14);

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel13.setMaximumSize(new java.awt.Dimension(300, 300));
        jPanel13.setPreferredSize(new java.awt.Dimension(300, 300));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/restaurantIcon (1).png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Western1");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelBoard.add(jPanel13);

        jPanel11.setBackground(new java.awt.Color(153, 255, 204));
        jPanel11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel11.setMaximumSize(new java.awt.Dimension(300, 300));
        jPanel11.setPreferredSize(new java.awt.Dimension(300, 300));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 320, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 294, Short.MAX_VALUE)
        );

        panelBoard.add(jPanel11);

        jScrollPane1.setViewportView(panelBoard);

        javax.swing.GroupLayout menuCardLayout = new javax.swing.GroupLayout(menuCard);
        menuCard.setLayout(menuCardLayout);
        menuCardLayout.setHorizontalGroup(
            menuCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuCardLayout.createSequentialGroup()
                .addGroup(menuCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 794, Short.MAX_VALUE)
                    .addGroup(menuCardLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        menuCardLayout.setVerticalGroup(
            menuCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(menuCard, "card2");

        jPanel7.setBackground(new java.awt.Color(255, 102, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        panelBoardFood.setBorder(javax.swing.BorderFactory.createEmptyBorder(50, 50, 50, 50));
        panelBoardFood.setLayout(new java.awt.GridLayout(0, 1, 50, 50));

        jPanel15.setBackground(new java.awt.Color(51, 255, 255));
        jPanel15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel15.setMaximumSize(new java.awt.Dimension(300, 300));
        jPanel15.setPreferredSize(new java.awt.Dimension(300, 200));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Western1");

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/foodIcon (3).png"))); // NOI18N

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Food");
        jLabel7.setToolTipText("");
        jLabel7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Price");

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("Mangoes are tropical fruits with a sweet, juicy flesh and a vibrant golden-yellow color. Known for their smooth, firm texture and a hint of tartness, mangoes are rich in vitamins A, C, and E, offering both a refreshing and nutritious treat. The fruit’s flesh surrounds a large, flat pit, and its flavor can range from subtly sweet to intensely tropical, depending on the variety. Often enjoyed fresh, mangoes are also used in smoothies, salads, salsas, and desserts, making them a versatile ingredient in cuisines around the world. Their natural sweetness and refreshing taste make them a beloved snack.");
        jScrollPane3.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 476, Short.MAX_VALUE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 476, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(250, 250, 250)
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelBoardFood.add(jPanel15);

        jPanel16.setBackground(new java.awt.Color(255, 255, 255));
        jPanel16.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel16.setMaximumSize(new java.awt.Dimension(300, 300));
        jPanel16.setPreferredSize(new java.awt.Dimension(300, 200));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/restaurantIcon (1).png"))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Western1");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 658, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelBoardFood.add(jPanel16);

        jPanel12.setBackground(new java.awt.Color(153, 255, 204));
        jPanel12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel12.setMaximumSize(new java.awt.Dimension(300, 300));
        jPanel12.setPreferredSize(new java.awt.Dimension(300, 200));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 670, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 194, Short.MAX_VALUE)
        );

        panelBoardFood.add(jPanel12);

        jScrollPane2.setViewportView(panelBoardFood);

        menuBackButton.setText("back");
        menuBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuBackButtonActionPerformed(evt);
            }
        });

        reviewLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reviewLabel.setText("Review");
        reviewLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reviewLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                reviewLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                reviewLabelMouseExited(evt);
            }
        });

        vendorNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        vendorNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        vendorNameLabel.setText("Vendor Name");
        vendorNameLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        vendorNameLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vendorNameLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                vendorNameLabelMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(menuBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(vendorNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reviewLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(reviewLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(menuBackButton)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(vendorNameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout foodCardLayout = new javax.swing.GroupLayout(foodCard);
        foodCard.setLayout(foodCardLayout);
        foodCardLayout.setHorizontalGroup(
            foodCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(foodCardLayout.createSequentialGroup()
                .addGroup(foodCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(foodCardLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(foodCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        foodCardLayout.setVerticalGroup(
            foodCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(foodCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(foodCard, "card2");

        jPanel22.setBackground(new java.awt.Color(153, 0, 204));

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        panelBoardReview.setBorder(javax.swing.BorderFactory.createEmptyBorder(50, 50, 50, 50));
        panelBoardReview.setLayout(new java.awt.GridLayout(0, 1, 10, 10));
        jScrollPane7.setViewportView(panelBoardReview);

        foodMenuBackButton.setText("back");
        foodMenuBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                foodMenuBackButtonActionPerformed(evt);
            }
        });

        reviewLabelPressed.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reviewLabelPressed.setText("Review");
        reviewLabelPressed.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 0, 0), 3));
        reviewLabelPressed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reviewLabelPressedMouseClicked(evt);
            }
        });

        vendorNameLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        vendorNameLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        vendorNameLabel1.setText("Vendor Name");
        vendorNameLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addComponent(foodMenuBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(vendorNameLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(reviewLabelPressed, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(reviewLabelPressed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(foodMenuBackButton)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(vendorNameLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout reviewCardLayout = new javax.swing.GroupLayout(reviewCard);
        reviewCard.setLayout(reviewCardLayout);
        reviewCardLayout.setHorizontalGroup(
            reviewCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reviewCardLayout.createSequentialGroup()
                .addGroup(reviewCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(reviewCardLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(reviewCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane7)
                            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        reviewCardLayout.setVerticalGroup(
            reviewCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(reviewCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(reviewCard, "card2");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 50, 0, 50));

        jPanel17.setBorder(javax.swing.BorderFactory.createEmptyBorder(20, 20, 20, 20));

        profileLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profileLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(profileLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        usernameLabel.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        usernameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usernameLabel.setText("nameLabel");

        creditLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        creditLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        creditLabel.setText("0.00");
        creditLabel.setPreferredSize(new java.awt.Dimension(21, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/walletIcon_30.png"))); // NOI18N

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 123, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(usernameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(creditLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(usernameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(creditLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        panelBoardNotification.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBoardNotification.setMinimumSize(new java.awt.Dimension(0, 0));
        panelBoardNotification.setLayout(new java.awt.GridLayout(0, 1, 10, 10));
        jScrollPane5.setViewportView(panelBoardNotification);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconJava/notificationIcon (1).png"))); // NOI18N
        jLabel14.setText("Notification");
        jLabel14.setVerifyInputWhenFocusTarget(false);
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel14MouseExited(evt);
            }
        });

        clearAllLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        clearAllLabel.setText("Clear all");
        clearAllLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearAllLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                clearAllLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                clearAllLabelMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                clearAllLabelMousePressed(evt);
            }
        });

        jPanel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel21MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel21MouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 81, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(clearAllLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(clearAllLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel19Layout.createSequentialGroup()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout profileCardLayout = new javax.swing.GroupLayout(profileCard);
        profileCard.setLayout(profileCardLayout);
        profileCardLayout.setHorizontalGroup(
            profileCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profileCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(profileCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        profileCardLayout.setVerticalGroup(
            profileCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(profileCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 412, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(profileCard, "card3");

        jPanel4.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 788, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        panelBoardTransaction.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBoardTransaction.setLayout(new java.awt.GridLayout(0, 1, 10, 10));
        jScrollPane6.setViewportView(panelBoardTransaction);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Transaction Log");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout walletCardLayout = new javax.swing.GroupLayout(walletCard);
        walletCard.setLayout(walletCardLayout);
        walletCardLayout.setHorizontalGroup(
            walletCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(walletCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(walletCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        walletCardLayout.setVerticalGroup(
            walletCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(walletCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(walletCard, "card3");

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        orderStatusLabel.setBackground(new java.awt.Color(204, 255, 255));
        orderStatusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        orderStatusText.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        orderStatusText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        orderStatusText.setText("OrderStatusText");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(orderStatusLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(orderStatusText, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(orderStatusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(orderStatusText, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panelBoardOrder.setLayout(new java.awt.GridLayout(0, 1, 20, 20));
        jScrollPane4.setViewportView(panelBoardOrder);

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        orderPlacementCB.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        orderPlacementCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Placement?", "Delivery", "Take Away", "Dine In" }));
        orderPlacementCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderPlacementCBActionPerformed(evt);
            }
        });

        inCartTotal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        inCartTotal.setText("0.00");

        placeOrderButton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        placeOrderButton.setText("Place Order");
        placeOrderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                placeOrderButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(placeOrderButton, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addComponent(placeOrderButton)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        totalLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        totalLabel.setText("Total: ");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(orderPlacementCB, 0, 175, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(totalLabel)
                .addGap(4, 4, 4)
                .addComponent(inCartTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(orderPlacementCB, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(inCartTotal, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(totalLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout orderStatusCardLayout = new javax.swing.GroupLayout(orderStatusCard);
        orderStatusCard.setLayout(orderStatusCardLayout);
        orderStatusCardLayout.setHorizontalGroup(
            orderStatusCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(orderStatusCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(orderStatusCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        orderStatusCardLayout.setVerticalGroup(
            orderStatusCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(orderStatusCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 420, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        mainPanel.add(orderStatusCard, "card3");

        jPanel24.setBackground(new java.awt.Color(255, 255, 204));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 788, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        panelBoardHistory.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBoardHistory.setLayout(new java.awt.GridLayout(0, 1, 10, 10));
        jScrollPane8.setViewportView(panelBoardHistory);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("History Log");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout historyCardLayout = new javax.swing.GroupLayout(historyCard);
        historyCard.setLayout(historyCardLayout);
        historyCardLayout.setHorizontalGroup(
            historyCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(historyCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(historyCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel24, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        historyCardLayout.setVerticalGroup(
            historyCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(historyCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(historyCard, "card3");

        jPanel26.setBackground(new java.awt.Color(204, 204, 0));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        panelBoardHistoryDetail.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelBoardHistoryDetail.setLayout(new java.awt.GridLayout(0, 1, 10, 10));
        jScrollPane9.setViewportView(panelBoardHistoryDetail);

        HDDateLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        HDDateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        HDDateLabel.setText("Date");

        HDVendorNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        HDVendorNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        HDVendorNameLabel.setText("Vendor Name");

        HDTimeLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        HDTimeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        HDTimeLabel.setText("Time");

        historyDetailbackButton.setText("Back");
        historyDetailbackButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                historyDetailbackButtonMouseClicked(evt);
            }
        });
        historyDetailbackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                historyDetailbackButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 144, Short.MAX_VALUE)
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(historyDetailbackButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HDVendorNameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HDTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HDDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(HDDateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(HDTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                        .addComponent(HDVendorNameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(historyDetailbackButton)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        totalCostLabel.setText("Total Cost:");

        orderTypeLabel.setText("Order Type:");

        totalItemAmountLabel.setText("Total Item Amount:");

        lastStatusLabel.setText("Last Status:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(totalCostLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(totalItemAmountLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lastStatusLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(orderTypeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lastStatusLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                    .addComponent(totalItemAmountLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(orderTypeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                    .addComponent(totalCostLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        complaintButton.setText("Complaint");
        complaintButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                complaintButtonActionPerformed(evt);
            }
        });

        leaveReviewButton.setText("Leave Review");
        leaveReviewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leaveReviewButtonActionPerformed(evt);
            }
        });

        jButton4.setText("Reorder");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 118, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout historyDetailCardLayout = new javax.swing.GroupLayout(historyDetailCard);
        historyDetailCard.setLayout(historyDetailCardLayout);
        historyDetailCardLayout.setHorizontalGroup(
            historyDetailCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(historyDetailCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(historyDetailCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(historyDetailCardLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(historyDetailCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(historyDetailCardLayout.createSequentialGroup()
                                .addComponent(complaintButton, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(leaveReviewButton, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane9))))
                .addContainerGap())
        );
        historyDetailCardLayout.setVerticalGroup(
            historyDetailCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(historyDetailCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(historyDetailCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(historyDetailCardLayout.createSequentialGroup()
                        .addComponent(leaveReviewButton, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, historyDetailCardLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(historyDetailCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(complaintButton, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        mainPanel.add(historyDetailCard, "card3");

        jPanel34.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        reviewVendorNameLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        reviewVendorNameLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reviewVendorNameLabel1.setText("Reviewing: Vendor Name");

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(reviewVendorNameLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(reviewVendorNameLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("Delivery");
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel25MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel25MouseExited(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Vendor");
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel26MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel26MouseExited(evt);
            }
        });

        reviewVendorTextArea1.setColumns(20);
        reviewVendorTextArea1.setRows(5);
        jScrollPane10.setViewportView(reviewVendorTextArea1);

        reviewRiderTextArea.setColumns(20);
        reviewRiderTextArea.setRows(5);
        jScrollPane13.setViewportView(reviewRiderTextArea);

        reviewCancelButton1.setText("Cancel");
        reviewCancelButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reviewCancelButton1ActionPerformed(evt);
            }
        });

        reviewPostButton1.setText("Post");
        reviewPostButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reviewPostButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel43Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(reviewPostButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(207, 207, 207)
                .addComponent(reviewCancelButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel43Layout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(reviewPostButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reviewCancelButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        starPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                starPanelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                starPanelMouseExited(evt);
            }
        });

        javax.swing.GroupLayout starPanelLayout = new javax.swing.GroupLayout(starPanel);
        starPanel.setLayout(starPanelLayout);
        starPanelLayout.setHorizontalGroup(
            starPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        starPanelLayout.setVerticalGroup(
            starPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        starPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                starPanel1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                starPanel1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout starPanel1Layout = new javax.swing.GroupLayout(starPanel1);
        starPanel1.setLayout(starPanel1Layout);
        starPanel1Layout.setHorizontalGroup(
            starPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        starPanel1Layout.setVerticalGroup(
            starPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel40Layout.createSequentialGroup()
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel43, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel40Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane10)
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel40Layout.createSequentialGroup()
                                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(starPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel40Layout.createSequentialGroup()
                                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(starPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                    .addComponent(starPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(starPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout leaveReviewCard1Layout = new javax.swing.GroupLayout(leaveReviewCard1);
        leaveReviewCard1.setLayout(leaveReviewCard1Layout);
        leaveReviewCard1Layout.setHorizontalGroup(
            leaveReviewCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leaveReviewCard1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(leaveReviewCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel35, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        leaveReviewCard1Layout.setVerticalGroup(
            leaveReviewCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leaveReviewCard1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainPanel.add(leaveReviewCard1, "card3");

        jPanel44.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 788, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        reviewVendorNameLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        reviewVendorNameLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reviewVendorNameLabel2.setText("Reviewing: Vendor Name");

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(reviewVendorNameLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(reviewVendorNameLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("Vendor");
        jLabel29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel29MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jLabel29MouseExited(evt);
            }
        });

        starPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                starPanel2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                starPanel2MouseExited(evt);
            }
        });

        javax.swing.GroupLayout starPanel2Layout = new javax.swing.GroupLayout(starPanel2);
        starPanel2.setLayout(starPanel2Layout);
        starPanel2Layout.setHorizontalGroup(
            starPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        starPanel2Layout.setVerticalGroup(
            starPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        reviewVendorTextArea2.setColumns(20);
        reviewVendorTextArea2.setRows(5);
        jScrollPane14.setViewportView(reviewVendorTextArea2);

        reviewCancelButton2.setText("Cancel");
        reviewCancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reviewCancelButton2ActionPerformed(evt);
            }
        });

        reviewPostButton2.setText("Post");
        reviewPostButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reviewPostButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel49Layout = new javax.swing.GroupLayout(jPanel49);
        jPanel49.setLayout(jPanel49Layout);
        jPanel49Layout.setHorizontalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel49Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(reviewPostButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(210, 210, 210)
                .addComponent(reviewCancelButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel49Layout.setVerticalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel49Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(reviewPostButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                    .addGroup(jPanel49Layout.createSequentialGroup()
                        .addGap(0, 22, Short.MAX_VALUE)
                        .addComponent(reviewCancelButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel46Layout.createSequentialGroup()
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel49, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel46Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(starPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel46Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(starPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(239, 239, 239)
                .addComponent(jPanel49, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout leaveReviewCard2Layout = new javax.swing.GroupLayout(leaveReviewCard2);
        leaveReviewCard2.setLayout(leaveReviewCard2Layout);
        leaveReviewCard2Layout.setHorizontalGroup(
            leaveReviewCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, leaveReviewCard2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(leaveReviewCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel45, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        leaveReviewCard2Layout.setVerticalGroup(
            leaveReviewCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leaveReviewCard2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(leaveReviewCard2, "card3");

        jPanel36.setBackground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 788, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 45, Short.MAX_VALUE)
        );

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("Complaining: Vendor Name");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                .addContainerGap())
        );

        complaintVendorTextArea.setColumns(20);
        complaintVendorTextArea.setRows(5);
        jScrollPane12.setViewportView(complaintVendorTextArea);

        complaintCancelButton.setText("Cancel");
        complaintCancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                complaintCancelButtonActionPerformed(evt);
            }
        });

        postComplaintButton.setText("Post");
        postComplaintButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                postComplaintButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel39Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(postComplaintButton)
                .addGap(215, 215, 215)
                .addComponent(complaintCancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(complaintCancelButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addGap(0, 17, Short.MAX_VALUE)
                        .addComponent(postComplaintButton, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane12)
                    .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 262, Short.MAX_VALUE)
                .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout complaintCardLayout = new javax.swing.GroupLayout(complaintCard);
        complaintCard.setLayout(complaintCardLayout);
        complaintCardLayout.setHorizontalGroup(
            complaintCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, complaintCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(complaintCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel37, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        complaintCardLayout.setVerticalGroup(
            complaintCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(complaintCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        mainPanel.add(complaintCard, "card3");

        jSplitPane1.setRightComponent(mainPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 944, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1)
        );

        setSize(new java.awt.Dimension(990, 700));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void creditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_creditButtonActionPerformed
        cardLayout.show(mainPanel, "walletCard");
        String targetCard = "walletCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayWalletMenu();
        }
        //test button
//        cleaner.cleanAllBoard();
//        System.out.println(inCartCount);
//
//        if (status < 7) {
//            updateOrderStatus(status);
//            status++;
//        } else {
//            status = 0;
//            updateOrderStatus(status);
//        }
    }//GEN-LAST:event_creditButtonActionPerformed

    private void usernameButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameButtonActionPerformed
        String targetCard = "profileCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayProfileMenu();
        }

    }//GEN-LAST:event_usernameButtonActionPerformed

    private void orderStatusButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderStatusButtonActionPerformed
        String targetCard = "orderStatusCard";

        if (!targetCard.equals(currentCard)) {
//            System.out.println("orderStatus Button pressed");
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            if (!inCartCount.isEmpty()) {
                placeOrderButton.setEnabled(true);
                orderPlacementCB.setEnabled(true);
                orderStatusText.setText("Such Delicious Choices!");
            } else {
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
                updateOrderStatus(0);
            }
            displayOrderMenu();
        }

    }//GEN-LAST:event_orderStatusButtonActionPerformed

    private void menuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuButtonActionPerformed
        String targetCard = "menuCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayVendor();
        }
    }//GEN-LAST:event_menuButtonActionPerformed

    private void historyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_historyButtonActionPerformed

        String targetCard = "historyCard";

        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayHistoryMenu();
        }
    }//GEN-LAST:event_historyButtonActionPerformed

    private void menuBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuBackButtonActionPerformed
        cleaner.cleanAllBoard();
        cardLayout.show(mainPanel, "menuCard");
        displayVendor();
    }//GEN-LAST:event_menuBackButtonActionPerformed

    private void placeOrderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_placeOrderButtonActionPerformed
        if (!placeOrderButton.getText().equalsIgnoreCase("Start New Order")) {
            if (!orderPlacementCB.getSelectedItem().toString().equalsIgnoreCase("Placement?")) {
                if (totalAmount < this.creditAmount) {
                    if (!inCartCount.isEmpty()) {
                        placeOrder();
                        placeOrderButton.setEnabled(false);
                        placeOrderButton.setText("Order Placed");
                        orderPlacementCB.setEnabled(false);
                        updateStatus();
                    }

//                if (this.orderID != null) {
//                    updateStatus();
//                }
                } else {
                    JOptionPane.showMessageDialog(null, "Insufficient credit amount!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please choose a placement type!", "Notification", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            placeOrderButton.setText("Place Order");
            PlacementTypeStatusCB(true);
            inCartCount.clear();
            cleaner.cleanAllBoard();
            displayOrderMenu();
            orderID = "null";
        }
    }//GEN-LAST:event_placeOrderButtonActionPerformed

    private void orderPlacementCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderPlacementCBActionPerformed
        PlacementTypeStatusCB(false);
    }//GEN-LAST:event_orderPlacementCBActionPerformed

    private void clearAllLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearAllLabelMouseClicked
        System.out.println("clicked");
        clearAllNotification();
    }//GEN-LAST:event_clearAllLabelMouseClicked

    private void clearAllLabelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearAllLabelMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_clearAllLabelMousePressed

    private void foodMenuBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_foodMenuBackButtonActionPerformed
        System.out.println(this.vendorIDTemp);
        String targetCard = "foodCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayVendorItemMenu(this.vendorIDTemp);
        }
    }//GEN-LAST:event_foodMenuBackButtonActionPerformed

    private void reviewLabelPressedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reviewLabelPressedMouseClicked

    }//GEN-LAST:event_reviewLabelPressedMouseClicked

    private void reviewLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reviewLabelMouseClicked
        System.out.println(this.vendorIDTemp);
        String targetCard = "reviewCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayReviewMenu();
        }
    }//GEN-LAST:event_reviewLabelMouseClicked

    private void historyDetailbackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_historyDetailbackButtonActionPerformed
        String targetCard = "historyCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            displayHistoryMenu();
        }
    }//GEN-LAST:event_historyDetailbackButtonActionPerformed

    private void reviewPostButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewPostButton1ActionPerformed
        postReview();
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
            checkReviewComplaint();
        }
    }//GEN-LAST:event_reviewPostButton1ActionPerformed

    private void reviewPostButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewPostButton2ActionPerformed
        postReview();
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
            checkReviewComplaint();
        }
    }//GEN-LAST:event_reviewPostButton2ActionPerformed

    private void historyDetailbackButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_historyDetailbackButtonMouseClicked

    }//GEN-LAST:event_historyDetailbackButtonMouseClicked

    private void leaveReviewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leaveReviewButtonActionPerformed

        if (orderTypeLabel.getText().toLowerCase().contains("delivery")) {
//            cleaner.cleanAllBoard();
            String targetCard = "leaveReviewCard1";
            if (!targetCard.equals(currentCard)) {
                currentCard = targetCard;
                cardLayout.show(mainPanel, targetCard);
                displayLeaveReviewTemp();
            }
        } else {
//            cleaner.cleanAllBoard();
            String targetCard = "leaveReviewCard2";
            if (!targetCard.equals(currentCard)) {
                currentCard = targetCard;
                cardLayout.show(mainPanel, targetCard);
                displayLeaveReviewTemp();
            }
        }

        setStarIcon1();
//        System.out.println("star icon set");
    }//GEN-LAST:event_leaveReviewButtonActionPerformed

    private void reviewCancelButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewCancelButton1ActionPerformed
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
        }
    }//GEN-LAST:event_reviewCancelButton1ActionPerformed

    private void reviewCancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewCancelButton2ActionPerformed
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
        }
    }//GEN-LAST:event_reviewCancelButton2ActionPerformed

    private void complaintButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_complaintButtonActionPerformed
        String targetCard = "complaintCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
            displayLeaveReviewTemp();
        }
    }//GEN-LAST:event_complaintButtonActionPerformed

    private void complaintCancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_complaintCancelButtonActionPerformed
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
        }
    }//GEN-LAST:event_complaintCancelButtonActionPerformed

    private void postComplaintButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_postComplaintButtonActionPerformed
        postComplaint();
        String targetCard = "historyDetailCard";
        if (!targetCard.equals(currentCard)) {
            currentCard = targetCard;
            cardLayout.show(mainPanel, targetCard);
            checkReviewComplaint();
        }
    }//GEN-LAST:event_postComplaintButtonActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        reorderItem();
        String targetCard = "orderStatusCard";

        if (!targetCard.equals(currentCard)) {
//            System.out.println("orderStatus Button pressed");
            currentCard = targetCard;
            cleaner.cleanAllBoard();
            cardLayout.show(mainPanel, targetCard);
            if (!inCartCount.isEmpty()) {
                placeOrderButton.setEnabled(true);
                orderPlacementCB.setEnabled(true);
                orderStatusText.setText("Such Delicious Choices!");
            } else {
                placeOrderButton.setEnabled(false);
                orderPlacementCB.setEnabled(false);
                updateOrderStatus(0);
            }
            displayOrderMenu();
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void reviewLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reviewLabelMouseEntered
        reviewLabel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
    }//GEN-LAST:event_reviewLabelMouseEntered

    private void reviewLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reviewLabelMouseExited
        reviewLabel.setBorder(null);
    }//GEN-LAST:event_reviewLabelMouseExited

    private void clearAllLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearAllLabelMouseEntered
        clearAllLabel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
    }//GEN-LAST:event_clearAllLabelMouseEntered

    private void clearAllLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearAllLabelMouseExited
        clearAllLabel.setBorder(null);
    }//GEN-LAST:event_clearAllLabelMouseExited

    private void jLabel14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseEntered
        clearAllLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_jLabel14MouseEntered

    private void jLabel14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseExited
        clearAllLabel.setBorder(null);
    }//GEN-LAST:event_jLabel14MouseExited

    private void jPanel21MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel21MouseEntered
        clearAllLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_jPanel21MouseEntered

    private void jPanel21MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel21MouseExited
        clearAllLabel.setBorder(null);
    }//GEN-LAST:event_jPanel21MouseExited

    private void vendorNameLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vendorNameLabelMouseEntered
        reviewLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_vendorNameLabelMouseEntered

    private void vendorNameLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vendorNameLabelMouseExited
        reviewLabel.setBorder(null);
    }//GEN-LAST:event_vendorNameLabelMouseExited

    private void starPanelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_starPanelMouseEntered
        starPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_starPanelMouseEntered

    private void starPanelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_starPanelMouseExited
        starPanel.setBorder(null);
    }//GEN-LAST:event_starPanelMouseExited

    private void starPanel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_starPanel1MouseEntered
        starPanel1.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_starPanel1MouseEntered

    private void starPanel1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_starPanel1MouseExited
        starPanel1.setBorder(null);
    }//GEN-LAST:event_starPanel1MouseExited

    private void jLabel26MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseEntered
        starPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_jLabel26MouseEntered

    private void jLabel26MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseExited
        starPanel.setBorder(null);
    }//GEN-LAST:event_jLabel26MouseExited

    private void jLabel25MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseEntered
        starPanel1.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_jLabel25MouseEntered

    private void jLabel25MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseExited
        starPanel1.setBorder(null);
    }//GEN-LAST:event_jLabel25MouseExited

    private void starPanel2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_starPanel2MouseEntered
        starPanel2.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_starPanel2MouseEntered

    private void starPanel2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_starPanel2MouseExited
        starPanel2.setBorder(null);
    }//GEN-LAST:event_starPanel2MouseExited

    private void jLabel29MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel29MouseEntered
        starPanel2.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }//GEN-LAST:event_jLabel29MouseEntered

    private void jLabel29MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel29MouseExited
        starPanel2.setBorder(null);
    }//GEN-LAST:event_jLabel29MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerMainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerMainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel HDDateLabel;
    private javax.swing.JLabel HDTimeLabel;
    private javax.swing.JLabel HDVendorNameLabel;
    private javax.swing.JPanel SidePanel;
    private javax.swing.JLabel clearAllLabel;
    private javax.swing.JButton complaintButton;
    private javax.swing.JButton complaintCancelButton;
    private javax.swing.JPanel complaintCard;
    private javax.swing.JTextArea complaintVendorTextArea;
    private javax.swing.JButton creditButton;
    private javax.swing.JLabel creditLabel;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JPanel foodCard;
    private javax.swing.JButton foodMenuBackButton;
    private javax.swing.JButton historyButton;
    private javax.swing.JPanel historyCard;
    private javax.swing.JPanel historyDetailCard;
    private javax.swing.JButton historyDetailbackButton;
    private javax.swing.JLabel inCartTotal;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lastStatusLabel;
    private javax.swing.JButton leaveReviewButton;
    private javax.swing.JPanel leaveReviewCard1;
    private javax.swing.JPanel leaveReviewCard2;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JButton menuBackButton;
    private javax.swing.JButton menuButton;
    private javax.swing.JPanel menuCard;
    private javax.swing.JComboBox<String> orderPlacementCB;
    private javax.swing.JButton orderStatusButton;
    private javax.swing.JPanel orderStatusCard;
    private javax.swing.JLabel orderStatusLabel;
    private javax.swing.JLabel orderStatusText;
    private javax.swing.JLabel orderTypeLabel;
    private javax.swing.JPanel panelBoard;
    private javax.swing.JPanel panelBoardFood;
    private javax.swing.JPanel panelBoardHistory;
    private javax.swing.JPanel panelBoardHistoryDetail;
    private javax.swing.JPanel panelBoardNotification;
    private javax.swing.JPanel panelBoardOrder;
    private javax.swing.JPanel panelBoardReview;
    private javax.swing.JPanel panelBoardTransaction;
    private javax.swing.JButton placeOrderButton;
    private javax.swing.JButton postComplaintButton;
    private javax.swing.JPanel profileCard;
    private javax.swing.JLabel profileLabel;
    private javax.swing.JButton reviewCancelButton1;
    private javax.swing.JButton reviewCancelButton2;
    private javax.swing.JPanel reviewCard;
    private javax.swing.JLabel reviewLabel;
    private javax.swing.JLabel reviewLabelPressed;
    private javax.swing.JButton reviewPostButton1;
    private javax.swing.JButton reviewPostButton2;
    private javax.swing.JTextArea reviewRiderTextArea;
    private javax.swing.JLabel reviewVendorNameLabel1;
    private javax.swing.JLabel reviewVendorNameLabel2;
    private javax.swing.JTextArea reviewVendorTextArea1;
    private javax.swing.JTextArea reviewVendorTextArea2;
    private javax.swing.JPanel starPanel;
    private javax.swing.JPanel starPanel1;
    private javax.swing.JPanel starPanel2;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JLabel totalCostLabel;
    private javax.swing.JLabel totalItemAmountLabel;
    private javax.swing.JLabel totalLabel;
    private javax.swing.JButton usernameButton;
    private javax.swing.JLabel usernameLabel;
    private javax.swing.JLabel vendorNameLabel;
    private javax.swing.JLabel vendorNameLabel1;
    private javax.swing.JPanel walletCard;
    // End of variables declaration//GEN-END:variables
}

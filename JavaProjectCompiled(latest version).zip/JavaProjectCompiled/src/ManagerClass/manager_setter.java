/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment.classes;

/**
 *
 * @author Chan Zean Yeet
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

public class manager_setter {
    private static manager_setter instance;
    private String name;
    private String password;
    private String managerId;
    private String managerIc;
    private int code = 0;
    private Boolean codeVisible = false;
    // Private constructor to prevent direct instantiation
    private manager_setter() {}
 
    // Public method to get the singleton instance
    public static manager_setter getInstance() {
        if (instance == null) {
            instance = new manager_setter();
        }
        return instance;
    }
    public void setCodeVisible(Boolean codeVisible){
        this.codeVisible = codeVisible;
    }
    public void setManagerName(String name){
        this.name = name;
    }
    public void setManagerPassword(String password){
        this.password = password;
    }
    public void setManagerId(String id){
        this.managerId = id;
    }
    public void setManagerIc(String Ic){
        this.managerIc = Ic;
    }
    public void setCode(int code){
        this.code = code;
    }
    public Boolean getCodeVisible(){
        return this.codeVisible;
    }
    public String getName(){
        return this.name;
    }
    public String getPass(){
        return this.password;
    }
    public String getManagerId(){
        return this.managerId;
    }
    public String getManagerIc(){
        return this.managerIc;
    }
    public int getCode(){
        return this.code;
    }
    public void codeGenerator(){
        Random rd = new Random();    
        int randomNumber = 100000 + rd.nextInt(900000);
        this.code = randomNumber;
    }
    public boolean CheckUserAuthentication(String username,String userpassword,String usercode,String IC,String filepath){
        System.out.println(getCode());
        String filename = filepath;
        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {
 
            String read;
            while ((read = br.readLine()) != null) {
                String[] data = read.split("\\|");
                if(data[1].equals(username)&&
                    data[2].equals(userpassword)&&
                    String.valueOf(this.code).equals(usercode)&&
                    data[3].equals(IC)){ 
                    System.out.println("Corrrrrectttt");
                    return true;
                }
 
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
        System.out.println("Wronnnnggg");
        return false;
    }
}



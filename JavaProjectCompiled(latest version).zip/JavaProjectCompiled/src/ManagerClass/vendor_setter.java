/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment.classes;

/**
 *
 * @author Chan Zean Yeet
 */
public class vendor_setter {
    private static vendor_setter instance;
    private String VendorId;
    
    public vendor_setter() {}

    // Public method to get the singleton instance
    public static vendor_setter getInstance() {
        if (instance == null) {
            instance = new vendor_setter();
        }
        return instance;
    }
    
    public void setVendorID(String value){
        this.VendorId = value;
    }
    
    public String getVendorID(){
        return this.VendorId;
    }
}

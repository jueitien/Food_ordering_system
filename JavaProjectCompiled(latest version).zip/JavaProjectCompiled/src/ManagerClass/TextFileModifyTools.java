
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment.classes;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class TextFileModifyTools {
    data_getter rg = new data_getter();
    
    public void UpdateTxtFile(String filepath, int ColumnIndex, String Id, String value){
        String filename = filepath;

        ArrayList<String[]> datalist = new ArrayList<>();

        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {

            String read;
            while ((read = br.readLine()) != null) {
                // Split each line into fields and add to the list
                String[] data = read.split("\\|");
                if(data[0].equals(Id)){
                    data[ColumnIndex] = value;
                    datalist.add(data);
                }else{
                    datalist.add(data);
                }
            }

            // Convert the List into a 2D array
            String[][] finaldatalist = new String[datalist.size()][];
            finaldatalist = datalist.toArray(finaldatalist);

            FileWritter(filepath,finaldatalist);

        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }

    }
    
    public void FileWritter(String filepath,String [][] datalist){
        
        try (FileWriter fw = new FileWriter(filepath);
         BufferedWriter bw = new BufferedWriter(fw)) {

        for (String[] data : datalist) {
            for (int i = 0; i < data.length; i++) {
                // Write data and add delimiter unless it's the last element
                bw.write(data[i]);
                if (i < data.length - 1) {
                    bw.write("|");
                }
            }
            // Add a newline after each row
            bw.write(System.lineSeparator());
        }
        
        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }
    
    public String IdIncrement(String Filepath) {
    // Retrieve the existing data from the file
    String[][] datalist = rg.getRunnerData(Filepath);

    // Initialize the largest numeric part
    int maxNumeric = 0;

    // Iterate through the IDs (assume they are in the first column)
    for (String[] data : datalist) {
        String id = data[0]; // Get the ID from the first column
        String numericPart = "";

        // Extract the numeric part from the ID
        for (char c : id.toCharArray()) {
            if (Character.isDigit(c)) {
                numericPart += c;
            }
        }

        if (!numericPart.isEmpty()) {
            int currentNumber = Integer.parseInt(numericPart);
            maxNumeric = Math.max(maxNumeric, currentNumber);
        }
    }

    // Increment the largest numeric part
    int nextNumber = maxNumeric + 1;

    // Format the new ID (assuming prefix "RF" and 3-digit numbers)
    return "RF" + String.format("%03d", nextNumber);
}

    
    public void AddDataRow(String Filepath, ArrayList<String> list) {
        try (FileWriter fw = new FileWriter(Filepath, true);  // Open in append mode
             BufferedWriter bw = new BufferedWriter(fw)) {

            // Convert the ArrayList into a pipe-separated string
            StringBuilder rowBuilder = new StringBuilder();
            for (int i = 0; i < list.size(); i++) {
                rowBuilder.append(list.get(i));
                if (i < list.size() - 1) {
                    rowBuilder.append("|");  // Add delimiter between elements
                }
            }

            // Write the constructed string as a new row into the file
            bw.write(rowBuilder.toString());
            bw.newLine();  // Add a new line after the row

        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    } 
    
    public void RemoveRow(String Filepath, String RemoveValue, int ColumnIndex){
        String[][] datalist = rg.getRunnerData(Filepath);
        ArrayList<String[]> tempdatalist = new ArrayList<>();
        for(String data[]:datalist){
            if(!data[ColumnIndex].equals(RemoveValue)){
                tempdatalist.add(data);
            }
        }
        String[][] newdatalist = new String[tempdatalist.size()][];
        for (int i = 0; i < tempdatalist.size(); i++) {
            newdatalist[i] = tempdatalist.get(i);
        }
        
        FileWritter(Filepath,newdatalist);
    }
}

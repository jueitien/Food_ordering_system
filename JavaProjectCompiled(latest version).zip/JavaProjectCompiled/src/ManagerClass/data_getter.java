/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment.classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;



public class data_getter {

    public String[][] getRunnerData(String filepath) {
        String filename = filepath;

        ArrayList<String[]> runnerList = new ArrayList<>();

        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {

            String read;
            while ((read = br.readLine()) != null) {
                // Split each line into fields and add to the list
                String[] data = read.split("\\|");
                runnerList.add(data);
            }

            // Convert the List into a 2D array
            String[][] runnerData = new String[runnerList.size()][];
            runnerData = runnerList.toArray(runnerData);

            return runnerData;

        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }

        return null;
    }
    
    public String[][] getRunnerDataWithCondition(String filepath, int ColumnIndexToRead, String value) {
        String filename = filepath;

        ArrayList<String[]> runnerList = new ArrayList<>();

        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {

            String read;
            while ((read = br.readLine()) != null) {
                // Split each line into fields and add to the list
                String[] data = read.split("\\|");
                if(data[ColumnIndexToRead].equals(value)){
                    runnerList.add(data);
                }  
            }

            // Convert the List into a 2D array
            String[][] runnerData = new String[runnerList.size()][];
            runnerData = runnerList.toArray(runnerData);

            return runnerData;

        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }

        return null;
    }
   
    
    public String[][] revenueComboBoxSort(String sortby) {
        int num = 0;
        ArrayList<String[]> tempSortedList = new ArrayList<>();
        data_getter rg = new data_getter();
        String[][] runnerdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunnerRevenue.txt");
        ArrayList<String> templist = new ArrayList<>();

        if (sortby.equals("RevenueID")) {
            // Sort by RevenueID (default order, simply copying data)
            for (String[] row : runnerdata) {
                tempSortedList.add(row); // Add rows to temporary list
            }
        }else if (sortby.equals("RunnerID")) {
            num = 1;
            // Sort by RunnerID
            for (String[] row : runnerdata) {
                templist.add(row[num]); // Add RunnerIDs to temporary list
            }

            // Sort RunnerIDs alphabetically
            Collections.sort(templist);

            // Match sorted RunnerIDs to rows in the original data

        }else if (sortby.equals("OrderID")) {
            num = 2;
            // Sort by RunnerID
            for (String[] row : runnerdata) {
                templist.add(row[num]); // Add RunnerIDs to temporary list
            }

            // Sort RunnerIDs alphabetically
            Collections.sort(templist);

            // Match sorted RunnerIDs to rows in the original data

        }else if (sortby.equals("HighRevenue")) {
            num = 4;
            for(String [] row : runnerdata){
                templist.add(row[num]);
            }  
            Collections.sort(templist);
            Collections.reverse(templist);

        }else if (sortby.equals("LowRevenue")){
            num = 4;
            for(String [] row : runnerdata){
                templist.add(row[num]);
            }
            Collections.sort(templist);

        }

        for (String Earning : templist) {
                for (String[] row : runnerdata) {
                    if (row[num].equals(Earning)) {
                        tempSortedList.add(row); // Add matching rows to sorted list
                    }
                }
            }

        // Convert ArrayList to String[][] for return
        String[][] SortedList = new String[tempSortedList.size()][];
        for (int i = 0; i < tempSortedList.size(); i++) {
            SortedList[i] = tempSortedList.get(i);
        }

        return SortedList;
    }
    
    public boolean CharacterChecker(String userinput, String actualValue) {
        for (char a : userinput.toCharArray()) {
            if (actualValue.indexOf(a) == -1) { 
                return false;
            }
        }
        return true; 
    }
    
    public String[][] SearchTool(String filepath, int ColumnIndex, String value){
        ArrayList<String[]> TempList = new ArrayList<>();
        data_getter rg = new data_getter();
        String[][] runnerdata = rg.getRunnerData(filepath);
        
        for(String[] list: runnerdata){
            if(rg.CharacterChecker(value,list[ColumnIndex] )){
                TempList.add(list);
            }
        }
        
        //Change it back to [][]
        String[][] FinalList = new String[TempList.size()][];
        for (int i = 0; i < TempList.size(); i++) {
            FinalList[i] = TempList.get(i);
        }

        return FinalList;
        
    }
    
    public String getValueById(String filepath, String ID, int ColumnIndex){
        String value = null;
        String [][] datalist = getRunnerData(filepath);
        for(String data[]: datalist){
            if(data[0].equals(ID)){
                value = data[ColumnIndex];
                break;
            }
        }
        return value;
    }
    
    public ArrayList<String> getList(String filepath, String value, int ColumnIndexToRead, int ColumnIndexToGet){
         ArrayList<String> List = new ArrayList<>();
         String [][] datalist = getRunnerData(filepath);
         for(String data[]: datalist) {
             if(data[ColumnIndexToRead].equals(value)){
                 String Value = data[ColumnIndexToGet];
                 List.add(Value);
             }
         }
         return List;
    };
    
    public ArrayList<String> getListWithCondition(String filepath, String VendorId, String date, int ColumnIndexValue1, int ColumnIndexValue2, int ColumnIndexToGet) {
        ArrayList<String> List = new ArrayList<>();
        String[][] datalist = getRunnerData(filepath);

        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd"); 
        DateTimeFormatter fileFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy"); 

        // Convert input date from yyyy-MM-dd to dd-MM-yyyy
        LocalDate inputDate = LocalDate.parse(date, inputFormatter);
        String formattedInputDate = inputDate.format(fileFormatter); 

        for (String[] data : datalist) {
            // Convert the file date from dd-MM-yyyy to LocalDate
            LocalDate fileDate = LocalDate.parse(data[ColumnIndexValue2], fileFormatter);

            if (data[ColumnIndexValue1].equals(VendorId) && 
                (fileDate.isAfter(inputDate) || fileDate.isEqual(inputDate))) {
                List.add(data[ColumnIndexToGet]);
            }
        }
        return List;
    }
    
    public String getValue(String filepath, String value, int ColumnIndexToRead, int ColumnIndexToGet){
         String Value = null;
         String [][] datalist = getRunnerData(filepath);
         for(String data[]: datalist) {
             if(data[ColumnIndexToRead].equals(value)){
                 Value = data[ColumnIndexToGet];
                 break;
             }
         }
         return Value;
    }
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment.classes;

/**
 *
 * @author Chan Zean Yeet
 */
public class runner_setter {
    private static runner_setter instance;
    private String runnerID;
    private String runnername;
    
    // Private constructor to prevent direct instantiation
    private runner_setter() {}

    // Public method to get the singleton instance
    public static runner_setter getInstance() {
        if (instance == null) {
            instance = new runner_setter();
        }
        return instance;
    }
    
    public void setRunnerID(String value){
        this.runnerID = value;
    }
    public void setRunnerName(String value){
        this.runnername = value;
    }
    
    public String getRunnerID(){
        return this.runnerID;
    }
}

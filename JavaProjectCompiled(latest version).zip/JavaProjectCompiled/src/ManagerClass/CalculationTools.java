/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment.classes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author Chan Zean Yeet
 */
public class CalculationTools {
    data_getter rg = new data_getter();
    public float TotalCal(String type, String runnerID){
        String filename = "C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunnerRevenue.txt";
        
        ArrayList<Float> Earninglist = new ArrayList<>();
        int OrderCounter = 0;
        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {

            String read;
            while ((read = br.readLine()) != null) {
                // Split each line into fields and add to the list
                String[] data = read.split("\\|");
                if(data[1].equals(runnerID)||runnerID.equals("All")){
                    Earninglist.add(Float.valueOf(data[4]));
                    OrderCounter +=1;
                }
            }
            float TotalEarning = 0;
            for (float Earning : Earninglist) {
                TotalEarning += Earning;
            }
            if(type.equals("Earning")){
                return TotalEarning;
            }else if(type.equals("Order")){
                return OrderCounter;
            }
            
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
        return 0;
    }
    
    public int StarCounter(String UserId,String StarType){
        int counter = 0;
        int Star = Integer.parseInt(StarType);
        String [][] runnerdata = rg.getRunnerData("C:\\Users\\Chan Zean Yeet\\OneDrive - Asia Pacific University\\Documents\\NetBeansProjects\\Assignment\\src\\main\\java\\com\\mycompany\\assignment\\data\\DeliveryRunnerReview.txt");
        for(String[]list:runnerdata){
            if(list[1].equals(UserId)){
                if(Integer.parseInt(list[3])==Star){
                    counter+=1;
                }
            }
        }
        return counter;
    }
    
    
    public float PSPercentageCount(float total, int highStars){
        Float percentage = (highStars/total)*100;
        return percentage;
    }
    
    public float MROCount(String CTP,String RR){
        Float NewCTP = Float.valueOf(CTP);
        Float NewRR = Float.valueOf(RR);
        Float VR = NewCTP - NewRR;
        Float MRO = VR *20/100;
        return MRO;
    }
    
    public int RowCount(String filepath, String value, int ColumnIndex){
        int count = 0;
        int count2 = 0;
        String [][] datalist = rg.getRunnerData(filepath);
        for(String data[]: datalist){
            count2 +=1;
            if(data[ColumnIndex].equals(value)){
                count+=1;
            }
        }
        if(value == null){
            return count2;
        }
        return count;
    }
    
    public String DateCalculation(String date, int number, String operation) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate datee = LocalDate.parse(date, formatter);
        LocalDate newDate;

        if (operation.equalsIgnoreCase("plus")) {
            newDate = datee.plusDays(number);
        } else if (operation.equalsIgnoreCase("minus")) {
            newDate = datee.minusDays(number);
        } else {
            throw new IllegalArgumentException("Invalid operation. Use 'plus' or 'minus'.");
        }

        return newDate.format(formatter); // Return in yyyy-MM-dd
    }
    
}

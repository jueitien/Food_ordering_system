/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
/**
 *
 * @author GF63
 */
public class Register_Data {
    
//    public int Biggest_ID(String File_Path) throws IOException{
//        Admin_DAO role_DAO = new Admin_DAO();
//        ArrayList<String[]> All_List = role_DAO.Read_Information(File_Path);
//        Integer biggest_num = 0;
//        for (String[] i : All_List) {
//            if(biggest_num == 0){
//                biggest_num = Integer.parseInt(i[0].substring(1));
//            }else{
//                if(Integer.parseInt(i[0].substring(1))>biggest_num){
//                    biggest_num = Integer.parseInt(i[0].substring(1));
//                }
//            }
//           
//        }
//        return biggest_num;
//    
//    }
//    
//    public String format_id(String Path) throws IOException{
//        Register_Data register_Data = new Register_Data();      
//        String id;
//        String data;
//        int existed_id = register_Data.Biggest_ID(Path);
//        
//        int new_id = existed_id + 1;
//        DecimalFormat formatter = new DecimalFormat("000");
//        String formatted = formatter.format(new_id);
//        return formatted;
//    
//    }
    
    public void save_role_data(String role,String Username, String Password, String Location) throws IOException{
        All_user_data all_user_data = new All_user_data();
        File_Path_Key file_Path_Key = new File_Path_Key();
        Admin_DAO data_Setter = new Admin_DAO();
        String data = null;
        String id;
        if(role.equals("Vendor")){
            String Str_id = all_user_data.format_id(file_Path_Key.Vendor_Path);
            id = "V" + Str_id;
            data = id + "|" + Username + "|" + Password + "|null" + "|" +Session.get_session_by_key("ID") ;
            data_Setter.Add_Information(data, file_Path_Key.Vendor_Path);
        }else if(role.equals("Customer")){
            String Str_id = all_user_data.format_id(file_Path_Key.Customer_Path);
            id = "C" + Str_id;
            data = id + "|" + Username + "|" + Password + "|" + "0" + "|" +Location+ "|" +Session.get_session_by_key("ID") ;
            data_Setter.Add_Information(data, file_Path_Key.Customer_Path);
        }else if(role.equals("Runner")){
            String Str_id = all_user_data.format_id(file_Path_Key.Runner_Path);
            id = "U" + Str_id;
            data = id + "|" + Username + "|" + Password + "|" + "100|" + "0"+ "|" +Session.get_session_by_key("ID") ;
            data_Setter.Add_Information(data, file_Path_Key.Runner_Path);
        }  
    }
    //modified
    private String Check_duplicate_data(String Username, String Password, String File_Path, Boolean Update, String Actual_Username) throws IOException{
        Admin_DAO role_DAO = new Admin_DAO();
        String Alert_text = null;
        ArrayList<String[]> All_List = role_DAO.Read_Information(File_Path);
        for (String[] i : All_List) {
            if(i[1].equals(Username) && Update == false){
                Alert_text = "Warning the Username was existed, Please Try it again";
            }
            else if(i[1].equals(Username) && Update == true && !i[1].equals(Actual_Username)){
                Alert_text = "Warning the Username was existed, Please Try it again";
            }
        }
        return Alert_text;
    }
    //modified
    public String Role_duplicate_Text(String Role, String Username, String Password, Boolean Update, String Actual_Username) throws IOException{
        File_Path_Key file_Path_Key = new File_Path_Key();
        String Alert_text = null;
        if (Role == "Vendor") {
            Alert_text = Check_duplicate_data(Username, Password, file_Path_Key.Vendor_Path, Update, Actual_Username);
//            System.out.println(Alert_text);
        }else if(Role == "Customer"){
            Alert_text = Check_duplicate_data(Username, Password, file_Path_Key.Customer_Path, Update, Actual_Username);
        }else if(Role == "Runner"){
            Alert_text = Check_duplicate_data(Username, Password, file_Path_Key.Runner_Path, Update, Actual_Username);
        }
        
        return Alert_text;
    
    }
    


}



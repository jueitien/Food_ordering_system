/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.util.HashMap;

/**
 *
 * @author GF63
 */
public class Session {
    private static HashMap<String, Object> session = new HashMap<>();
    public static void set_session(String key,String value){
        session.put(key, value);  
    }
    public static String get_session_by_key(String key){
        return  (String) session.get(key);
    
    }
    public static void removeAttribute(String key) {
        session.remove(key);
    }
    public static void clearSession() {
        session.clear();
    }
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;


import java.util.ArrayList;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
/**
 *
 * @author GF63
 */
public class Read_Search_Data {
    private String name_result = null;
    private String Id_result = null;
    
    public Read_Search_Data(String name_result, String Id_result){
        this.Id_result = Id_result;
        this.name_result = name_result;
    }
     
    
    //read && search   
    private ArrayList<String[]> Filter_Data(String item,int index) throws IOException{
        All_user_data all_user_data = new All_user_data();
        String[][] User_List_Container = all_user_data.All_User_List();
        char[] char_search = item.toCharArray();
        ArrayList<String[]> search_result_container = new ArrayList<>();
        
        for(String[] i : User_List_Container){
            Integer possiblity = 0;
            List<Character> char_record = new ArrayList<>();
            for (char c : i[index].toCharArray()) {
                char Upper_c = Character.toUpperCase(c);
                char_record.add(Upper_c);
            }
            
            for(char a : char_search){
                Iterator<Character> iterator = char_record.iterator();
                while(iterator.hasNext()){
                    char b = iterator.next();
                    if(Character.toUpperCase(a)==b){
                        possiblity++;
                        iterator.remove();
                        break;
                    }
                }  
            }
            if(possiblity>=char_search.length){
                search_result_container.add(i);
            }
        }

        
        return arrange_sequence(search_result_container);
    }
     
    
    public ArrayList<String[]> Filter_name_id() throws IOException{
        ArrayList<String[]> search_result_container = new ArrayList<>();
        ArrayList<String[]> name =Filter_Data(this.name_result,1);
        
        char[] char_Id_search = this.Id_result.toUpperCase().toCharArray();
        for(String[] i : name){
            Integer possiblity = 0;
            List<Character> char_Id_record= new ArrayList<>();
            for(char b : i[0].toCharArray()){
                char_Id_record.add(Character.toUpperCase(b));
            }   
            for(char a : char_Id_search){
                Iterator<Character> iterator =  char_Id_record.iterator();
                while (iterator.hasNext()) {
                    char b = iterator.next();
                    if(a==b){
                        possiblity++;
                        iterator.remove();
                        break;
                    }     
                }   
            }  
            if(possiblity>=char_Id_search.length){
                search_result_container.add(i);
            }
            
            
        }
   
        return arrange_sequence(search_result_container);
    }
    
    public ArrayList<String[]> arrange_sequence(ArrayList<String[]> Array_containner){
        ArrayList<String[]> arranged_containner = new ArrayList<>();
        Iterator<String[]> iterator = Array_containner.iterator();

        
        while(iterator.hasNext()){
            String[] i = iterator.next();
            if (i[0].contains(this.Id_result) && i[1].contains(this.name_result)) {
                arranged_containner.add(i);
                iterator.remove();
            }
        }

        iterator = Array_containner.iterator();
        while (iterator.hasNext()) {
            String[] i = iterator.next();
            if (i[0].contains(this.Id_result) || i[1].contains(this.name_result)) {
                arranged_containner.add(i);
                iterator.remove(); 
            }
        }
        arranged_containner.addAll(Array_containner);
        return arranged_containner;
    }
    
    
    public String[][] Filter() throws IOException{
        ArrayList<String[]> sorted_Array =  null;
        if(this.name_result.isEmpty()){
            sorted_Array=Filter_Data(this.Id_result,0);
        }else if(this.Id_result.isEmpty()){
            sorted_Array=Filter_Data(this.name_result,1);
        }else if(!this.name_result.isEmpty() && !this.Id_result.isEmpty()){
            sorted_Array=Filter_name_id();
        }
        
        String[][] array = new String[sorted_Array.size()][];
        array = sorted_Array.toArray(array);
        return array;
        
    }
    
    
    
    
    
    
}

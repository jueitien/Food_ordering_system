/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
//import javax.transaction.Transaction;

/**
 *
 * @author GF63
 */
public class Generate_Receipt {
    Admin_DAO adao = new Admin_DAO();
    File_Path_Key file_Path_Key = new File_Path_Key();
    public String[][] Check_isSend() throws IOException{
        ArrayList<String[]> Receipt_list = adao.Read_Information(file_Path_Key.Top_Up_Path);
        ArrayList<String[]> Data_table = new ArrayList<>();
        Iterator<String[]> Iterator = Receipt_list.iterator();
        while(Iterator.hasNext()){
            String[] a = Iterator.next();
            if (!a[8].equals("False")) {
                Iterator.remove();
            }else{
                Data_table.add(new String[] {a[0], a[7], a[3], a[5], a[6]});
            }
        }
        String[][] Arrayslist;
        String[][] Arr_Receiptlist = new String[Data_table.size()][];
        Data_table.toArray(Arr_Receiptlist); 
        return Arr_Receiptlist;
    }
    
    public void Send_Notification(String ID, String CustomerID, String Amount, String date) throws IOException{
        ArrayList<String[]> Receipt_list = adao.Read_Information(file_Path_Key.Top_Up_Path);
        for(String[] i : Receipt_list){
            if(i[0].equals(ID)){
                i[8]= "True";
            }
        }
        adao.Update_Information(Receipt_list, file_Path_Key.Top_Up_Path);
        All_user_data all_user_data = new All_user_data();
        String N_ID = all_user_data.format_id_0000(file_Path_Key.Notification_Path);
        String Data = "N"+N_ID+"|"+Session.get_session_by_key("ID")+"|Individual|"+CustomerID+"|Top-up_Successful!_Your_account_has_been_credited_with_RM_"+ Amount+"._Thank_you_for_your_payment!"+"|"+date;
        adao.Add_Information(Data, file_Path_Key.Notification_Path);
    }
    

}

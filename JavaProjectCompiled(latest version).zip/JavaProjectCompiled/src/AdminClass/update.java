/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.util.ArrayList;
import java.util.HashMap;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author GF63
 */
public class update {
    public String User_ID;
    public String Actual_Username;
    public HashMap<String,String> User_Data_modified;
    
    public update(String User_ID, String Actual_Username, HashMap<String,String> User_Data_modified) throws IOException{
        this.User_ID = User_ID;
        this.Actual_Username = Actual_Username;
        this.User_Data_modified = User_Data_modified;

    }
    public String Username_duplicate() throws IOException{
        File_Path_Key file_Path_Key = new File_Path_Key();
        Register_Data rd =new Register_Data();
        String check = this.User_ID.substring(0, 1);
        String Alert_text = null;
        if(check.equals("V")){
            Alert_text = rd.Role_duplicate_Text("Vendor", User_Data_modified.get("Username"), "", true, Actual_Username);
       }else if(check.equals("U")){
            Alert_text = rd.Role_duplicate_Text("Runner", User_Data_modified.get("Username"), "", true, Actual_Username);
       }else if(check.equals("C")){
            Alert_text = rd.Role_duplicate_Text("Customer", User_Data_modified.get("Username"), "", true, Actual_Username);
       }
        return Alert_text;

    
    }
    
    public void Assign_Index() throws IOException{
        All_user_data all_user_data = new All_user_data();
        ArrayList<String []> All_Role_data = all_user_data.identify_File(User_ID);
        ArrayList<String []> After_upload = new ArrayList<>();
        File_Path_Key file_Path_Key = new File_Path_Key();
        String check = All_Role_data.get(0)[0].substring(0, 1);
        String Path = null;
        for(String[] i : All_Role_data ){
           if (i[0].equals(User_ID)) {
               if(check.equals("V")){
                    i[1]=User_Data_modified.get("Username");
                    i[2]=User_Data_modified.get("Password");
                    Path = file_Path_Key.Vendor_Path;
               }else if(check.equals("U")){
                    i[1]=User_Data_modified.get("Username");
                    i[2]=User_Data_modified.get("Password");
                    i[3]=User_Data_modified.get("Merit");
                    if (User_Data_modified.get("Runnerstatus").equals("Offline")) {
                       i[4]="0";
                   }else if(User_Data_modified.get("Runnerstatus").equals("Online")){
                       i[4]="1";
                   }else if(User_Data_modified.get("Runnerstatus").equals("Busy")){
                       i[4]="2";
                   }
;
                    Path = file_Path_Key.Runner_Path;

               }else if(check.equals("C")){
                    i[1]=User_Data_modified.get("Username");
                    i[2]=User_Data_modified.get("Password");
                    i[4]=User_Data_modified.get("Location");
                    Path = file_Path_Key.Customer_Path;
               }
               After_upload.add(i);
            }else{
               After_upload.add(i);
           }
        
        }
        Admin_DAO rdao = new Admin_DAO();
        rdao.Update_Information(After_upload, Path);
    }
    
 
}

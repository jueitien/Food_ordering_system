/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

/**
 *
 * @author GF63
 */
public class File_Path_Key {
    public final String Vendor_Path = "src\\Data\\Vendor.txt";
    public final String Customer_Path = "src\\Data\\Customer.txt";
    public final String Runner_Path = "src\\Data\\DeliveryRunner.txt";
    public final String Notification_Path = "src\\Data\\Notification.txt";
    public final String TransactionLog_Path = "src\\Data\\TransactionLog.txt";
    public final String Admin_Path = "src\\Data\\Admin.txt";
    public final String Top_Up_Path = "src\\Data\\Top_Up_User.txt";
    public final String Refund = "src\\Data\\Refund.txt";
}


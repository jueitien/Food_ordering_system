/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author GF63
 */
public class refund {
    Admin_DAO adao =new Admin_DAO();
    File_Path_Key file_Path_Key = new File_Path_Key();
    String[] data;
    public ArrayList<String[]>fetch_refund_data() throws IOException{
        
        ArrayList<String[]> refund_user = adao.Read_Information(file_Path_Key.Refund);
        
        return refund_user; 
    }
    public String[] set_data(String[] data){
        this.data=data;
        return this.data;
    }
    
    public void drop_isRefund() throws IOException{
        ArrayList<String[]> refund_user = adao.Read_Information(file_Path_Key.Refund);
        refund_user.removeIf(refund -> Arrays.equals(refund, this.data));
        adao.Update_Information(refund_user,file_Path_Key.Refund);
    }
    
    
    public String get_Customer_credit() throws IOException{
        ArrayList<String[]> Customer_user = adao.Read_Information(file_Path_Key.Customer_Path);
        String credit = null;
        for(String[] i : Customer_user){
            if (i[0].equals(data[1])) {
                credit = i[3];
            }
        }


        return credit;
    }
    
    public void update_Customer_credit() throws IOException{
        ArrayList<String[]> Customer_user = adao.Read_Information(file_Path_Key.Customer_Path);
        for(String[] i : Customer_user){
            if (i[0].equals(data[1])) {
                i[3]=get_total(i[3], data[2]);
            }
        }
        adao.Update_Information(Customer_user, file_Path_Key.Customer_Path);
    }
    
    public String get_total(String credit_before,String value){
        float credit_bf = Float.parseFloat(credit_before);
        float amount = Float.parseFloat(value);
        float total = credit_bf + amount;
        String str_total = Float.toString(total);
        return str_total;
    }
    
    public void add_trancastion() throws IOException{
        All_user_data all_user_data = new All_user_data();
        String Biggest_Transaction_ID = all_user_data.format_id(file_Path_Key.TransactionLog_Path);
        String text = "T"+Biggest_Transaction_ID + "|" + get_Customer_credit() + "|" + get_total(get_Customer_credit(),data[2]) + "|" + "True" + "|" + all_user_data.get_date() + "|" + all_user_data.get_time() + "|" + data[1]; 
        adao.Add_Information(text, file_Path_Key.TransactionLog_Path);
    }
    
    public void add_notification() throws IOException{
        All_user_data all_user_data = new All_user_data();
        String Biggest_notification = all_user_data.format_id_0000(file_Path_Key.Notification_Path);
        String text = "N"+Biggest_notification + "|" + Session.get_session_by_key("ID") + "|Individual|" + data[1] + "|The_amount_has_been_successfully_returned_to_your_account._We_sincerely_apologize_for_the_inconvenience_and_regret_any_negative_experience_this_may_have_caused.|" + all_user_data.get_date(); 
        adao.Add_Information(text, file_Path_Key.Notification_Path);
    }   
    
    

    
}

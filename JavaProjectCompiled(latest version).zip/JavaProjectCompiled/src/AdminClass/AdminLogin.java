/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author GF63
 */
public class AdminLogin {
    String Username;
    String Password;
    String ID;
    public AdminLogin(String Username,String Password){
        this.Username=Username;
        this.Password=Password;
    
    }
    public String get_admin_username(){
        return this.Username;
    }
    
    public String get_admin_Id(){
        return this.ID;
    }
    
    public String get_admin_password(){
        return this.Password;
    }
    
    public boolean check_login_credential() throws IOException{
        boolean check_Flag = false;
        Admin_DAO adao = new Admin_DAO();
        File_Path_Key file_Path_Key = new File_Path_Key();
        ArrayList<String []> Admin_list = adao.Read_Information(file_Path_Key.Admin_Path);
        
        
        for (String[] i: Admin_list) {
            if (i[1].equals(this.Username)&&i[2].equals(this.Password)) {
                check_Flag = true;
                ID = i[0];
                Session.set_session("ID", ID);
            }
            
        }
        return check_Flag;
    
    }
    
    
}

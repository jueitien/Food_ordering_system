package AdminClass;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import AdminClass.File_Path_Key;
import java.util.Arrays;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author GF63
 */
public class Admin_DAO {

    public void Add_Information(String User_Info_Data, String File_Path) throws IOException{
        FileWriter fw = new FileWriter(File_Path,true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(User_Info_Data + "\n");
        bw.close();
        fw.close();
    }   
    
    public String Array_to_Text(ArrayList<String[]> Data){
        String text = "";
        for(String[] i : Data){
            String value = String.join("|", i);
            text+= value+"\n";
        }
        
        
        return text;
    
    }
    public void Update_Information(ArrayList<String[]> Arraged_Data, String File_Path) throws IOException{
        String Convert_String = Array_to_Text(Arraged_Data);
        FileWriter fw = new FileWriter(File_Path,false);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(Convert_String);
        bw.close();
        fw.close();
        
        
    }
    
        
    
    public ArrayList<String []> Read_Information(String File_Path) throws IOException{
        ArrayList<String []> All_Record = new ArrayList<>();
        
       try (BufferedReader br = new BufferedReader(new FileReader(File_Path))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {//
                    continue;//
                }//
                String [] each_record = line.split("\\|");
                All_Record.add(each_record);
            }
       }
        return All_Record;
    }
   
}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.io.IOException;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 *
 * @author GF63
 */
public class Delete_Data {
    private String Id;
    public Delete_Data(String Id){
        this.Id=Id;
    }
    
    
    public String[][] Data_format() throws IOException{
        All_user_data all_user_data = new All_user_data();
        String[][] All_data = all_user_data.All_User_List();
        String[][] ID_Name = new String[All_data.length][2];
        int count = 0;
        for(String[] i : All_data){
            ID_Name[count][0] = i[0];
            ID_Name[count][1] = i[1];
            count++;
        }
        System.out.println(Arrays.deepToString(All_data));
        return ID_Name;
    }
    
    
    public String[] Display_data() throws IOException{
        All_user_data all_user_data = new All_user_data();
        ArrayList<String []> By_ID_data = all_user_data.identify_File(this.Id);
        String[] Selected_data = new String[1];
        for(String[] i : By_ID_data){
            if(i[0].equals(this.Id)){
                if (i[4].equals("0")) {
                    i[4]="Offline";
                }else if(i[4].equals("1")){
                    i[4]="Online";
                }else if(i[4].equals("2")){
                    i[4]="Busy";
                }
                Selected_data = i;
            }
        }
        return Selected_data;
    
    }
    
    //modified
    public void delete_data(String path) throws IOException{
        String[] Selected_Data = Display_data();
//        System.out.println("selected data: "+Arrays.deepToString(Selected_Data));
        All_user_data all_user_data = new All_user_data();
        ArrayList<String []> By_ID_data = all_user_data.identify_File(this.Id);
//        for (String[] i : By_ID_data) {
//            System.out.println(Arrays.deepToString(i));
//        }
        Iterator<String[]> Iterator = By_ID_data.iterator();
        while (Iterator.hasNext()) {
            String[] b = Iterator.next();
            if (b[4].equals("0")) {
                b[4]="Offline";
            }else if(b[4].equals("1")){
                b[4]="Online";
            }else if(b[4].equals("2")){
                b[4]="Busy";
            }
            System.out.println("selected data: "+Arrays.deepToString(Selected_Data));
            System.out.println("delete data: "+Arrays.deepToString(b));
            if(Arrays.equals(b, Selected_Data)){
                Iterator.remove();
            } 
        }
        Admin_DAO rdao = new Admin_DAO();
        rdao.Update_Information(By_ID_data, path);
        
    
    }
    
    
}

    
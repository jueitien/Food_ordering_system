/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;

import java.util.ArrayList;

/**
 *
 * @author GF63
 */
abstract class CustomerAccount {
    protected String Customer_Id;
    protected String Credit_Before;
    protected String Top_Up_Value;

    public CustomerAccount(String Customer_Id,String Credit_Before,String Top_Up_Value) {
        this.Customer_Id = Customer_Id;
        this.Credit_Before = Credit_Before;
        this.Top_Up_Value = Top_Up_Value;
    }
    
    public abstract ArrayList<String[]> Top_Up_Credit();
    
    public String Get_Id(){
        return this.Customer_Id;
    }
    
    public String Get_Credit_Before(){
        return this.Credit_Before;
    }
    
    public String Get_Top_Up_Value(){
        return this.Top_Up_Value;
    }
    
}





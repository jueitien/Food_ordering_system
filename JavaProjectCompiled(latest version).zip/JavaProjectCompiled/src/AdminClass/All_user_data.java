/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author GF63
 */
public class All_user_data{
    
    public String[][] All_User_List() throws IOException{
        Admin_DAO role_DAO = new Admin_DAO();
        File_Path_Key file_Path_Key = new File_Path_Key();
        ArrayList<String []> vendor = role_DAO.Read_Information(file_Path_Key.Vendor_Path);
        ArrayList<String []> Customer = role_DAO.Read_Information(file_Path_Key.Customer_Path);
        ArrayList<String []> Runner = role_DAO.Read_Information(file_Path_Key.Runner_Path);
        int length = vendor.size() + Customer.size() + Runner.size();
        int count = 0;
        
        String [][] User_container = new String [length][7];
        for(String[] i : vendor){
            System.arraycopy(i, 0, User_container[count], 0, 3);
            count++;
        }
        for(String[] i : Customer){
            i[4]=i[4].replace("_", " ");
            System.arraycopy(i, 0, User_container[count], 0, 3);
            System.arraycopy(i, 4, User_container[count], 5, 1);
            count++;
        }
        for(String[] i : Runner){
            if (i[4].equals("0")) {
                i[4]="Offline";
            }
            else if (i[4].equals("1")) {
                i[4]="Online";
            }
            else if(i[4].equals("2")) {
                i[4]="Busy";
            }
            System.arraycopy(i, 0, User_container[count], 0, 3);
            System.arraycopy(i, 3, User_container[count], 3, 2);
            count++;
        }
        
        return User_container;

    }
    
    public ArrayList<String []> identify_File(String ID) throws IOException{
        Admin_DAO rdao = new Admin_DAO();
        File_Path_Key file_Path_Key = new File_Path_Key();
        String FirstChar_Id = ID.substring(0, 1);
        ArrayList<String []> Role_Containner = new ArrayList<>();
        
        if(FirstChar_Id.equals("V")){
            Role_Containner = rdao.Read_Information(file_Path_Key.Vendor_Path);
        }else if(FirstChar_Id.equals("U")){
            Role_Containner = rdao.Read_Information(file_Path_Key.Runner_Path);
        }
        else if(FirstChar_Id.equals("C")){
            Role_Containner = rdao.Read_Information(file_Path_Key.Customer_Path);
        }
        return Role_Containner;
        
    }
    
    public int Biggest_ID(String File_Path) throws IOException{
        Admin_DAO role_DAO = new Admin_DAO();
        ArrayList<String[]> All_List = role_DAO.Read_Information(File_Path);
        Integer biggest_num = 0;
        for (String[] i : All_List) {
            if(biggest_num == 0){
                biggest_num = Integer.parseInt(i[0].substring(1));
            }else{
                if(Integer.parseInt(i[0].substring(1))>biggest_num){
                    biggest_num = Integer.parseInt(i[0].substring(1));
                }
            }
           
        }
        return biggest_num;
    
    }
    
    public String format_id(String Path) throws IOException{    
        String id;
        String data;
        int existed_id = Biggest_ID(Path);
        
        int new_id = existed_id + 1;
        DecimalFormat formatter = new DecimalFormat("000");
        String formatted = formatter.format(new_id);
        return formatted;
    
    }
    public String format_id_0000(String Path) throws IOException{    
        String id;
        String data;
        int existed_id = Biggest_ID(Path);
        
        int new_id = existed_id + 1;
        DecimalFormat formatter = new DecimalFormat("0000");
        String formatted = formatter.format(new_id);
        return formatted;
    
    }
    public String get_time(){
        LocalTime time = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
        String timeString = time.format(formatter);
        return timeString;
    }
    
    public String get_date(){
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String dateString = date.format(formatter);
        return dateString;

    }
}

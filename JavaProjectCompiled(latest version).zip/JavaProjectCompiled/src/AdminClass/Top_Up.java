/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AdminClass;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author GF63
 */
public  class Top_Up extends CustomerAccount{
    File_Path_Key file_Path_Key = new File_Path_Key();
    public Top_Up(String Customer_Id, String Credit_Before, String Top_Up_Value) {
        super(Customer_Id, Credit_Before, Top_Up_Value);
    }
    
    
    
    public String[][] Customer_table_data() throws IOException{
        Admin_DAO rdao = new Admin_DAO();
        ArrayList<String[]> C_list = rdao.Read_Information(file_Path_Key.Customer_Path); 
        
        String[][] Tbl_Format = new String[C_list.size()][3];
        int count = 0;
        for(String[] i : rdao.Read_Information(file_Path_Key.Customer_Path)){
            Tbl_Format[count]= new String[]{i[0],i[1],i[3]};
            count++;
        }
       
        return Tbl_Format;
        
        
    }

    
    public String[][] Filtered_data(String id) throws IOException{
        String[][] Data = Customer_table_data();
        String[][] User = new String[1][];
        for(String[] i : Data){
            if(i[0].equals(id.toUpperCase())){
                User[0]= i;
            }     
        }
        return User;
    }
    
    
    public String Total_value(){
        float actual_credit = Float.parseFloat(Get_Credit_Before());
        int top_up_value = Integer.parseInt(Get_Top_Up_Value());
        float Total = actual_credit + top_up_value;
        String Str_total = Float.toString(Total); 
        return Str_total;
    
    
    }
    
    
    //abstract &poly

    /**
     *
     * @return
     */
    @Override
    public ArrayList<String[]> Top_Up_Credit(){
        Admin_DAO rdao = new Admin_DAO();
        ArrayList<String[]> C_list = null; 
        try {
            C_list = rdao.Read_Information(file_Path_Key.Customer_Path);
            String Id = Get_Id();
            for(String[] i : C_list){
                if (i[0].equals(Id.toUpperCase())) {
//                    float actual_credit = Float.parseFloat(Get_Credit_Before());
//                    int top_up_value = Integer.parseInt(Get_Top_Up_Value());
//                    float Total = actual_credit + top_up_value;
                    i[3] = Total_value();//Float.toString(Total); 
                }
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Top_Up.class.getName()).log(Level.SEVERE, null, ex);
        }
        return C_list;
        
    }
    
    
    
    
    public void Update_data() throws IOException{
        Admin_DAO admin_DAO = new Admin_DAO();
        All_user_data all_user_data = new All_user_data();
        admin_DAO.Update_Information(Top_Up_Credit(), file_Path_Key.Customer_Path);
        String Biggest_Top_Up_ID = all_user_data.format_id(file_Path_Key.Top_Up_Path);
        String Biggest_Transaction_ID = all_user_data.format_id(file_Path_Key.TransactionLog_Path);
        String T_Data = "T"+Biggest_Transaction_ID + "|" + Get_Credit_Before() + "|" + Total_value() + "|" + "False" + "|" + all_user_data.get_date() + "|" + all_user_data.get_time() + "|" + Get_Id();
        String TU_Data = "Z"+Biggest_Top_Up_ID + "|" + Get_Credit_Before() + "|" + Total_value() + "|" + Get_Top_Up_Value() + "|False" + "|" + all_user_data.get_date() + "|" + all_user_data.get_time() + "|" + Get_Id() + "|False";
       
        System.out.println(T_Data);
        admin_DAO.Add_Information(T_Data, file_Path_Key.TransactionLog_Path);
        admin_DAO.Add_Information(TU_Data, file_Path_Key.Top_Up_Path);
    }
    
   
    
}


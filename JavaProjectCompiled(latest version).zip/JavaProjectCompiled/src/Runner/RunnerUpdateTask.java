/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Runner;

import RunnerClass.Runner;
import RunnerClass.Task;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author JYQ00
 */
public class RunnerUpdateTask extends javax.swing.JFrame {
    private Task task;
    private Runner runner;
    /**
     * Creates new form RunnerUpdateTask
     */
    public RunnerUpdateTask(Runner runner,Task task) {
        initComponents();
        setLocationRelativeTo(null);
        this.task = task;
        this.runner = runner;
        String runnerId = runner.getId();
        loadAcceptedTaskData(runnerId);
        loadCustomerLocation();
        loadVendorName();
        Date date = new Date();

        // Set Date and Time
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = dateFormat.format(date); // Date part
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        String formattedTime = timeFormat.format(date); // Time part
        systemdate.setText(formattedDate);
        systemtime.setText(formattedTime);
        
        
    }

    private void loadAcceptedTaskData(String runnerId){
            String taskId = task.getTaskId(); 
            List<String[]> taskData = task.getUpdatedTask(runnerId,taskId);
            String[] columnNames = {"Order ID","Status", "Created Date" , "Created Time", "Updated Time"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);

            for (String[] row : taskData) {
                model.addRow(row);
            }
            updateTable.setModel(model);
    }
    
    public void pickupTask(String status){
        task.setStatus("pickedup");
        
        Date date = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedTime = timeFormat.format(date);
        String formattedDate = dateFormat.format(date);
        
        List<String> updatedLines = new ArrayList<>();
        List<String> orderupdatedLines = new ArrayList<>();
        String taskfile = "src/data/deliveryrunnertask.txt";
        String orderfile = "src/data/order.txt";
        String notificationfile = "src/data/notification.txt";
        String newNotificationId = null;
        String receiver = null;
        String sender = null;
        String order = null;

        // task read
        try (BufferedReader reader = new BufferedReader(new FileReader(taskfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String id = taskDetails[0].trim();
                
                if (id.equals(task.getTaskId())) {
                    String updatedLine = taskDetails[0] + "|" +
                                         taskDetails[1] + "|" +  
                                         taskDetails[2] + "|" +  
                                         taskDetails[3] + "|" +  
                                         status + "|" +  
                                         taskDetails[5] + "|" +  
                                         taskDetails[6] + "|" + 
                                         formattedTime;  
                    receiver = taskDetails[1];
                    sender = taskDetails[3];
                    order = taskDetails[2];
                    updatedLines.add(updatedLine);
                    

                } else {
                    updatedLines.add(line); 
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // order read
        try (BufferedReader reader = new BufferedReader(new FileReader(orderfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String orderid = taskDetails[0];
                String customerid = taskDetails[1];
                if (orderid.equals(order) && customerid.equals(receiver)) {
                    System.out.println("task complete");
                        String updatedLine =    taskDetails[0] + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                taskDetails[3] + "|" +  
                                                taskDetails[4] + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                taskDetails[7] + "|" + 
                                                taskDetails[8] + "|" + 
                                                taskDetails[9] + "|" + 
                                                "Delivering"; 
                                                orderupdatedLines.add(updatedLine);
                } else {
                    orderupdatedLines.add(line); 
                }           
            }
        } catch (IOException e) {
            System.err.println("Error reading order data: " + e.getMessage());
        }
        
        // notification read
        try (BufferedReader reader = new BufferedReader(new FileReader(notificationfile))) {
            String line;
            String lastLine = null;

            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            if (lastLine != null) {
                String[] lastNotificationDetails = lastLine.split("\\|");
                String lastNotificationId = lastNotificationDetails[0];

                int numericPart = Integer.parseInt(lastNotificationId.substring(1));
                newNotificationId = "N" + String.format("%04d", numericPart + 1);
            } else {
                newNotificationId = "N0000";
            }
        } catch (IOException e) {
            System.err.println("Error reading notification file: " + e.getMessage());
        }

        
        // write task
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(taskfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        //write notification
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(notificationfile, true))) {
                String notification = newNotificationId + "|" + sender + "|individual|"+ receiver +"|Order_Picked_up|" + formattedDate;
                writer.write(notification);
                writer.newLine();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing notification file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // write order
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(orderfile))) {
            for (String updatedLine : orderupdatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void completeTask(String taskId, String status, String runnerId){
        runner.setStatus(1);
        task.setStatus("delivered");
        runner.setStatusOnline(runnerId,1);        
        Date date = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String formattedTime = timeFormat.format(date);
        String formattedDate = dateFormat.format(date);
        
        List<String> updatedLines = new ArrayList<>();
        List<String> orderupdatedLines = new ArrayList<>();
        String taskfile = "src/data/deliveryrunnertask.txt";
        String orderfile = "src/data/order.txt";
        String notificationfile = "src/data/notification.txt";
        String revenuefile = "src/data/deliveryrunnerrevenue.txt";
        String newNotificationId = null;
        String newRevenueId = null;
        String receiver = null;
        String sender = null;
        String order = null;
        
        // revenue read
        try (BufferedReader reader = new BufferedReader(new FileReader(notificationfile))) {
            String line;
            String lastLine = null;

            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            if (lastLine != null) {
                String[] lastNotificationDetails = lastLine.split("\\|");
                String lastNotificationId = lastNotificationDetails[0];

                int numericPart = Integer.parseInt(lastNotificationId.substring(1));
                newRevenueId = "RR" + String.format("%03d", numericPart + 1);
            } else {
                newRevenueId = "RR000";
            }
        } catch (IOException e) {
            System.err.println("Error reading notification file: " + e.getMessage());
        }
        
        // notification read
        try (BufferedReader reader = new BufferedReader(new FileReader(notificationfile))) {
            String line;
            String lastLine = null;

            while ((line = reader.readLine()) != null) {
                lastLine = line;
            }

            if (lastLine != null) {
                String[] lastNotificationDetails = lastLine.split("\\|");
                String lastNotificationId = lastNotificationDetails[0];

                int numericPart = Integer.parseInt(lastNotificationId.substring(1));
                newNotificationId = "N" + String.format("%04d", numericPart + 1);
            } else {
                newNotificationId = "N0000";
            }
        } catch (IOException e) {
            System.err.println("Error reading notification file: " + e.getMessage());
        }
        
        // task read
        try (BufferedReader reader = new BufferedReader(new FileReader(taskfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String id = taskDetails[0].trim();
                
                if (id.equals(taskId)) {
                    String updatedLine = taskDetails[0] + "|" +
                                         taskDetails[1] + "|" +  
                                         taskDetails[2] + "|" +  
                                         taskDetails[3] + "|" +  
                                         status + "|" +  
                                         taskDetails[5] + "|" +  
                                         taskDetails[6] + "|" + 
                                         formattedTime;     
                    updatedLines.add(updatedLine);
                    receiver = taskDetails[1];
                    sender = taskDetails[3];
                    order = taskDetails[2];
                    
                } else {
                    updatedLines.add(line); 
                }
            }
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // order read
        try (BufferedReader reader = new BufferedReader(new FileReader(orderfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskDetails = line.split("\\|"); 
                String orderid = taskDetails[0];
                String customerid = taskDetails[1];
                if (orderid.equals(order) && customerid.equals(receiver)) {
                    System.out.println("task complete");
                        String updatedLine =    taskDetails[0] + "|" +
                                                taskDetails[1] + "|" +  
                                                taskDetails[2] + "|" +  
                                                taskDetails[3] + "|" +  
                                                taskDetails[4] + "|" +  
                                                taskDetails[5] + "|" +  
                                                taskDetails[6] + "|" + 
                                                taskDetails[7] + "|" + 
                                                taskDetails[8] + "|" + 
                                                taskDetails[9] + "|" + 
                                                "Delivered"; 
                                                orderupdatedLines.add(updatedLine);
                } else {
                    orderupdatedLines.add(line); 
                }           
            }
        } catch (IOException e) {
            System.err.println("Error reading order data: " + e.getMessage());
        }
        
        // write task
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(taskfile))) {
            for (String updatedLine : updatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        //write notification
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(notificationfile, true))) {
                String notification = newNotificationId + "|" + sender + "|individual|"+ receiver +"|Order_Delivered|" + formattedDate;
                writer.write(notification);
                writer.newLine();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing notification file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        //write revenue
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(revenuefile, true))) {
                String revenue = newRevenueId + "|" + sender + "|" + order + "|" + formattedDate + "|10.00";
                writer.write(revenue);
                writer.newLine();
            
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing notification file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // write order
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(orderfile))) {
            for (String updatedLine : orderupdatedLines) {
                writer.write(updatedLine);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadCustomerLocation(){
        String customerId = task.getCustomerId();
        System.out.println("");
        String customerfile = "src/data/customer.txt";
        
        try (BufferedReader reader = new BufferedReader(new FileReader(customerfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] customerDetails = line.split("\\|"); 
                String id = customerDetails[0].trim();
                String name = customerDetails[1].trim();
                String location = customerDetails[4].trim().replace("_", " ");
                
                if(id.equals(customerId)){
                    jLabel4.setText(name);
                    jLabel3.setText(location);
                }

            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadVendorName(){
        String orderId = task.getOrderId();
        String vendorId = "";
        System.out.println("");
        String vendorfile = "src/data/vendor.txt";
        String orderfile = "src/data/order.txt";
        
        try (BufferedReader reader = new BufferedReader(new FileReader(orderfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] orderDetails = line.split("\\|"); 
                String id = orderDetails[0].trim();
                String vendorid = orderDetails[2].trim();
                
                if(id.equals(orderId)){
                    vendorId = vendorid;
                }

            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(vendorfile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] vendorDetails = line.split("\\|"); 
                String id = vendorDetails[0].trim();
                String name = vendorDetails[1].trim();
                
                if(id.equals(vendorId)){
                    jLabel5.setText(name);
                }

            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        back = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        pickedupbutton = new javax.swing.JButton();
        deliveredbutton = new javax.swing.JButton();
        systemdate = new javax.swing.JLabel();
        systemtime = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        updateTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        back.setText("X");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        back.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                backKeyPressed(evt);
            }
        });

        jLabel4.setText("jLabel1");

        pickedupbutton.setText("Picked Up");
        pickedupbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pickedupbuttonActionPerformed(evt);
            }
        });

        deliveredbutton.setText("Delivered");
        deliveredbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deliveredbuttonActionPerformed(evt);
            }
        });

        systemdate.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        systemdate.setText("Date");

        systemtime.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        systemtime.setText("Time");

        updateTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(updateTable);

        jLabel1.setText("Location:");

        jLabel3.setText("jLabel2");

        jLabel6.setText("Customer:");

        jLabel2.setText("Vendor:");

        jLabel5.setText("jLabel5");

        jLabel7.setText("|");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(pickedupbutton)
                        .addGap(52, 52, 52)
                        .addComponent(deliveredbutton)
                        .addGap(98, 98, 98))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 403, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(back)
                                    .addComponent(jLabel2))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(systemdate, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(systemtime, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(123, 123, 123))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addGap(17, 17, 17))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(back)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(systemdate)
                        .addComponent(systemtime)
                        .addComponent(jLabel7)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deliveredbutton)
                    .addComponent(pickedupbutton))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new RunnerPage(runner).setVisible(true);
    }//GEN-LAST:event_backActionPerformed

    private void deliveredbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deliveredbuttonActionPerformed
        // TODO add your handling code here:
        if("accepted".equals(task.getStatus())){
            JOptionPane.showMessageDialog(null, "Please pick up the order first");
        } else if ("pickedup".equals(task.getStatus())){
            completeTask(task.getTaskId(),"delivered", runner.getId());
            JOptionPane.showMessageDialog(null, "Order has been successfully delivered");
            this.dispose();
            new RunnerPage(runner).setVisible(true);
        } else{
            System.out.println("error in deliver button");
        }
        loadAcceptedTaskData(runner.getId());
    }//GEN-LAST:event_deliveredbuttonActionPerformed

    private void pickedupbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pickedupbuttonActionPerformed
        // TODO add your handling code here:
        if("pickedup".equals(task.getStatus())){
            JOptionPane.showMessageDialog(null, "Order has been picked up");
        } else if("accepted".equals(task.getStatus())){
            pickupTask("pickedup");
            JOptionPane.showMessageDialog(null, "Order has been successfully picked up");
        } else{
            System.out.println("error in pick up button");            
        }
        loadAcceptedTaskData(runner.getId());
    }//GEN-LAST:event_pickedupbuttonActionPerformed

    private void backKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_backKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            back.doClick();
        }
    }//GEN-LAST:event_backKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RunnerUpdateTask.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RunnerUpdateTask.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RunnerUpdateTask.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RunnerUpdateTask.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        Task task = new Task();
        Runner runner = new Runner();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RunnerUpdateTask(runner,task).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton deliveredbutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton pickedupbutton;
    private javax.swing.JLabel systemdate;
    private javax.swing.JLabel systemtime;
    private javax.swing.JTable updateTable;
    // End of variables declaration//GEN-END:variables
}

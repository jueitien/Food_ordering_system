package VendorClass;

/**
 * Interface for managing session state for the vendor.
 * Provides methods for login, logout, and managing vendor details.
 * Also includes methods for handling food orders and notifications.
 * 
 * @author party
 */
public interface SessionManagerInt {
    
    // Method to verify if the user is logged in
    boolean verifyLoggedIn();

    // Method to set the login status
    void setLogIn(boolean isLoggedIn);

    // Method for login, returns vendor's ID and name if credentials are correct
    String[] LogIn(String username, String password);

    // Method to get the vendor's name
    String getVendorName();

    // Method to set the vendor's name
    void setVendorName(String vendorName);

    // Method to get the vendor's ID
    String getVendorId();

    // Method to set the vendor's ID
    void setVendorId(String vendorId);

    // Method to log the vendor out
    void LogOut();
    
    // New method to get the food order status
    boolean getFoodOrder();

    // New method to set the food order status
    void setFoodOrder(boolean foodOrder);

    // New method to get the notification status
    boolean getNotification();

    // New method to set the notification status
    void setNotification(boolean notification);
}

package VendorClass;

import java.util.ArrayList;

/**
 * This class implements the SessionManager interface to manage session state for the vendor.
 * It provides concrete implementations of the session management methods.
 * 
 * @author party
 */
public class SessionManagerVendor implements SessionManagerInt {
    private static SessionManagerVendor instance;

    // Instance variables to store session information
    protected boolean isLoggedIn;
    protected String vendorName;
    protected String vendorId;
    protected boolean FoodOrder;   // New boolean to track food order status
    protected boolean Notification; // New boolean to track notification status

    // Constructor to initialize the session manager with default values
    public SessionManagerVendor() {
        this.isLoggedIn = false;  // Vendor is not logged in by default
        this.vendorName = "";     // Vendor name is empty by default
        this.vendorId = "";       // Vendor ID is empty by default
        this.FoodOrder = false;   // Default value for food order is false
        this.Notification = false; // Default value for notification is false
    }

    public static SessionManagerVendor getInstance() {
        if (instance == null) {
            instance = new SessionManagerVendor();
        }
        return instance;
    }

    @Override
    public boolean verifyLoggedIn() {
        return isLoggedIn;
    }

    @Override
    public void setLogIn(boolean isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
    }

    @Override
    public String getVendorName() {
        return vendorName;
    }

    @Override
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    @Override
    public String getVendorId() {
        return vendorId;
    }

    @Override
    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }

    // Getter and setter for FoodOrder
    @Override
    public boolean getFoodOrder() {
        return FoodOrder;
    }

    @Override
    public void setFoodOrder(boolean foodOrder) {
        this.FoodOrder = foodOrder;
    }

    // Getter and setter for Notification
    @Override
    public boolean getNotification() {
        return Notification;
    }

    /**
     *
     * @param notification
     */
    @Override
    public void setNotification(boolean notification) {
        this.Notification = notification;
    }

    @Override
    public String[] LogIn(String username, String password) {
        FileReaderVendor filereader = new FileReaderVendor();
        ArrayList<String[]> vendorData = filereader.readFileContent(PathManagerVendor.getVendorPath());

        for (String[] row : vendorData) {
            // Check if the username matches row[1] and password matches row[2]
            if (username.equals(row[1]) && password.equals(row[2])) {
                return new String[]{row[0], row[1]};
            }
        }
        return null;
    }

    @Override
    public void LogOut() {
        isLoggedIn = false;
        this.vendorId = "";
        this.vendorName = "";
        this.FoodOrder = false;  // Reset FoodOrder on logout
        this.Notification = false; // Reset Notification on logout
    }
}

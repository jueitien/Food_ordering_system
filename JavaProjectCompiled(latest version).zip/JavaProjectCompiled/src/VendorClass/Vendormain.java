package VendorClass;
import Vendor.VendorLoginPage;

public class Vendormain extends PathManagerVendor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create an instance of FileReaderVendor
        // Launch the VendorLoginPage
        new VendorLoginPage().setVisible(true);
    }
}

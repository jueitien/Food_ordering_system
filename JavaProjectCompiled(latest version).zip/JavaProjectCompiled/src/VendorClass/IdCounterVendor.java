/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VendorClass;

/**
 *
 * @author party
 */
import java.util.ArrayList;

public class IdCounterVendor {

public String IdCounter(ArrayList<String[]> array) {
    if (array == null || array.isEmpty()) {
        throw new IllegalArgumentException("Array is null or empty.");
    }

    // Extract the first value (assuming the format like "N0008")
    String rawId = array.get(array.size() - 1)[0];
    
    // Extract the letter (e.g., "N")
    String letter = rawId.replaceAll("[^A-Za-z]", ""); // Remove non-letter characters
    
    // Extract the numeric part
    String numericPart = rawId.replaceAll("[^0-9]", ""); // Remove non-numeric characters
    
    // Check if the numeric part is valid
    if (numericPart.isEmpty()) {
        throw new IllegalArgumentException("Invalid ID format: No numeric value found.");
    }
    
    int id = 0;
    try {
        // Parse the numeric part to an integer
        id = Integer.parseInt(numericPart);
    } catch (NumberFormatException e) {
        throw new IllegalArgumentException("Invalid ID format: Cannot convert to integer.");
    }

    // Increment the ID by 1
    id += 1;

    // Calculate the length of the numeric part
    int numericLength = numericPart.length();

    // Format the new ID based on the length of the numeric part
    String formattedId = String.format("%0" + numericLength + "d", id); // Dynamically format with leading zeros

    // Return the final formatted ID with the letter and number
    return letter + formattedId;
}
}
package VendorClass;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class WriteDataVendor {
    
    // Method to write ArrayList of String[] to a text file
public boolean writedata(ArrayList<String[]> arrayList, URL filepath) {

    try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath.getPath()))) {
        for (int i = 0; i < arrayList.size(); i++) {
            String[] row = arrayList.get(i);
            // Write the values in the row, separated by "|"
            for (int j = 0; j < row.length; j++) {
                writer.write(row[j]); // Write the value of the array element
                if (j < row.length - 1) {
                    writer.write("|"); // Add "|" separator between values
                }
            }
            
            writer.newLine(); // Add newline at the end of the row
        }
    } catch (IOException e) {
        System.out.println(e);
        return false;
    }
    return true;
}

    
    // Method to write a single String[] to a text file
    public boolean writedata(String[] array, URL filepath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filepath.getPath(), true))) { // 'true' to append to the file

            // Write all values separated by "|"
            for (int i = 0; i < array.length; i++) {
                writer.write(array[i]); // Write the value of the array element
                if (i < array.length - 1) {
                    writer.write("|"); // Add "|" separator between values
                }
             
            }
                        writer.newLine(); // Add newline at the end of the row
        } catch (IOException e) {
            System.out.println(e);
            return false;
        }
    return true;
    }
}

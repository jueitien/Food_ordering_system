package VendorClass;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

public class FileReaderVendor extends PathManagerVendor {  // Inheriting PathManagerVendor

    // Method to read file content and store it in an ArrayList, then return the ArrayList
    public ArrayList<String[]> readFileContent(URL filePath) {
        ArrayList<String[]> fileContent = new ArrayList<>();
        
        // Fetch the content and store it in the ArrayList
        fetchFileContent(filePath, fileContent);

        // Return the ArrayList containing the file content
        return fileContent;
    }

    // Helper method to fetch the content of the file and store it in the ArrayList
    private void fetchFileContent(URL filePath, ArrayList<String[]> fileContent) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(filePath.openStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line by "|" and store it in the ArrayList as an array
                String[] parts = line.split("\\|");
                fileContent.add(parts);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + filePath);
            e.printStackTrace();
        }
        if (filePath == getOrderPath()) {
            for(String[] row : fileContent){
                if (row[7].toLowerCase().equals("delivery")) {
                    double newAmount = Double.parseDouble(row[6]) - 10;
                    row[6] = String.valueOf(newAmount);
                } else {
                    double newAmount = Double.parseDouble(row[6]);
                    row[6] = String.valueOf(newAmount);
                }
            }
        }
    }
}

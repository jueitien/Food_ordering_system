/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VendorClass;

import java.net.URL;

/**
 *
 * @author party
 */
public class PathManagerVendor {
    private static URL vendorPath = PathManagerVendor.class.getClassLoader().getResource("data/vendor.txt");
    private static URL itemOrderPath = PathManagerVendor.class.getClassLoader().getResource("data/itemOrder.txt");
    private static URL OrderPath = PathManagerVendor.class.getClassLoader().getResource("data/order.txt");
    private static URL TransactionLogPath = PathManagerVendor.class.getClassLoader().getResource("data/transactionLog.txt");
    private static URL vendorItemMenuPath = PathManagerVendor.class.getClassLoader().getResource("data/vendorItemMenu.txt");
    private static URL CustomerReviewPath = PathManagerVendor.class.getClassLoader().getResource("data/customerReview.txt");
    private static URL NotificationPath = PathManagerVendor.class.getClassLoader().getResource("data/Notification.txt");

    // Getters for the file paths
    public static URL getVendorPath() {
        return vendorPath;
    }

    public static URL getItemOrderPath() {
        return itemOrderPath;
    }

    public static URL getOrderPath() {
        return OrderPath;
    }

    public static URL getTransactionLogPath() {
        return TransactionLogPath;
    }

    public static URL getVendorItemMenuPath() {
        return vendorItemMenuPath;
    }

    public static URL getCustomerReviewPath() {
        return CustomerReviewPath;
    }
    
        public static URL getNotificationPath() {
        return NotificationPath;
    }
}

package VendorClass;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * A utility class for retrieving the current date and time in specific formats.
 *
 * @author party
 */
public class DateTimeVendor {


    public String getCurrentDate() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        return dateFormat.format(new Date());
    }

    public String getCurrentTime() {
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        return timeFormat.format(new Date());
    }
    
    public String getCurrentDateTime() {
        String Datetime = this.getCurrentDate() + " " + this.getCurrentTime();
        return Datetime;
    }
}

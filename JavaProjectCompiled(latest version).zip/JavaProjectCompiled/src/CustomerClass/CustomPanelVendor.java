/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import Customer.CustomerMainMenu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

/**
 *
 * @author user
 */
public class CustomPanelVendor extends JPanel {

    //decalre constant value for the icons
    private static final String RESTAURANTICON = "src/iconJava/restaurantIcon (1).png";
//    private static final String FOODICON = "src/iconJava/foodIcon (1).png";

    //declare the name at the bottom of the JPanel
    protected String labelName, vendorID;
    protected JLabel iconLabel, nameLabel;

    public CustomPanelVendor(String labelName, String vendorID, CustomerMainMenu customerMainMenu) {
        this.labelName = labelName;
        //set the dimension of the custom panel
        setPreferredSize(new Dimension(300, 300));
        //set the panel background color to white
        setBackground(Color.WHITE);
        //set the border to BevelBorder type raised
        setBorder(BorderFactory.createSoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.BLACK));
        //set Panel type to BorderLayout
        setLayout(new BorderLayout());

        //create the top part (icon label) of the panel
        iconLabel = new JLabel();
        //center the icon label
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        //set the icon to be at the top of the label created
        iconLabel.setVerticalAlignment(SwingConstants.TOP);
        //call setIcon function to fill the label with icon
        setIcon();
        //place it in the center of the layout
        add(iconLabel, BorderLayout.CENTER);

        //create the bottom part (name label) of the panel
        nameLabel = new JLabel(labelName, SwingConstants.CENTER);
        //set the font of the label anme
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        //set the visibility of the label
//        nameLabel.setOpaque(true);
        nameLabel.setBackground(Color.WHITE);
        //set the size of the label so it doesnt get squish to the bottom
        nameLabel.setPreferredSize(new Dimension(100, 80));
        //place it at the bottom of the layout
//        nameLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        add(nameLabel, BorderLayout.SOUTH);

//        addMouseListener(new PanelEventListener(customerMainMenu, labelName));
//        //add event listener to the custom panel
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                //call display vendor item menu function from customer main menu
                customerMainMenu.displayVendorItemMenu(vendorID);
                System.out.println(labelName + " button clicked!");
            }

            //mouse in border highlight
            @Override
            public void mouseEntered(MouseEvent e) {
                setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3)); 
            }

            //mouse out border restore to default
            @Override
            public void mouseExited(MouseEvent e) {
                setBorder(BorderFactory.createSoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.BLACK));
            }

        });
    }

//    protected class PanelEventListener extends MouseAdapter {
//        private final CustomerMainMenu customerMainMenu;
//        private final String vendorName;
//        
//        public PanelEventListener(CustomerMainMenu customerMainMenu, String vendorName) {
//            this.customerMainMenu = customerMainMenu;
//            this.vendorName = vendorName;
//        }
//        
//        @Override
//        public void mouseClicked(MouseEvent e) {
//            customerMainMenu.displayVendorItemMenu();
//            System.out.println(vendorName + " button clicked!");
//        }
//    }
    //function to place icon into label depending on the icon type requested to be place in it
    protected void setIcon() {
        //checks for the parameter of 1 or 2 to place either restaurant or food context icon
        String iconPath = RESTAURANTICON;
        //catch error for icon placement
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(285, 225, Image.SCALE_SMOOTH);
            iconLabel.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            iconLabel.setText("Icon Missing");
        }
    }

    public String getLabelName() {
        return labelName;
    }

    //setter also sets the label name for the bottom part of the label
    public void setLabelName(String vendorName) {
        this.labelName = vendorName;
        nameLabel.setText(vendorName);
    }
}

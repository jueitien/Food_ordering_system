/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Vendor {

    private String vendorID, username, password, managerID, adminID;
    private static final String VENDORFILE = "src/data/Vendor.txt"; //declare default vendor item menu txt file path
    private static ArrayList<Vendor> allVendor = new ArrayList<>();

    public Vendor(String vendorID, String username, String password, String managerID, String adminID) {
        this.vendorID = vendorID;
        this.username = username;
        this.password = password;
        this.managerID = managerID;
        this.adminID = adminID;
    }

    public Vendor() {
        this.vendorID = "";
        this.username = "";
        this.password = "";
        this.managerID = "";
        this.adminID = "";
    }

    //reads all vendor data from file
    public static void readVendorData() {
        try {

            File mFile = new File(VENDORFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] mData = data.split("\\|");

                    //checks data length first
                    if (mData.length == 5) {

                        Vendor vendor = new Vendor();
                        vendor.setVendorID(mData[0]);
                        vendor.setUsername(mData[1]);
                        vendor.setPassword(mData[2]);
                        vendor.setManagerID(mData[3]);
                        vendor.setAdminID(mData[4]);

                        allVendor.add(vendor);

                    } else {

                        System.out.println("Data Length Error" + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    //getter for  all vendor data
    public static ArrayList<Vendor> getAllVendor() {
        return allVendor;
    }

    public static Vendor getVendorByVendorID(String vendorID) {
        for (Vendor vendor : allVendor) {
            if (vendor.getVendorID().equals(vendorID)) {
                return vendor;
            }
        }
        return null;
    }

    public static String getManagerIDByVendorID(String vendorID) {
        for (Vendor vendor : allVendor) {
            if (vendor.getVendorID().equals(vendorID)) {
                return vendor.getManagerID();
            }
        }
        return null;
    }

//    public static Vendor getManagerIDByVendorID(String vendorID) {
//        for (Vendor vendor : allVendor) {
//            if (vendor.getVendorID().equals(vendorID)) {
//                return vendor;
//            }
//        }
//        return null;
//    }
    public static String getVendorUsernameByVendorID(String vendorID) {
        for (Vendor vendor : allVendor) {
            if (vendor.getVendorID().equals(vendorID)) {
                return vendor.getUsername();
            }
        }
        return null;
    }

    public String getManagerID() {
        return managerID;
    }

    public String getAdminID() {
        return adminID;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setManagerID(String managerID) {
        this.managerID = managerID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Vendor{" + "vendorID=" + vendorID + ", username=" + username + ", password=" + password + '}';
    }

}

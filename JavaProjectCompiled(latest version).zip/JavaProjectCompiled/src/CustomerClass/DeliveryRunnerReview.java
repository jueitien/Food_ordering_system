/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class DeliveryRunnerReview {

    private String riderReviewID, riderID, customerID, riderReview, reviewDate;
    private int riderRating;
    private static final String RIDERREVIEWFILE = "src/data/DeliveryRunnerReview.txt";
    private static ArrayList<DeliveryRunnerReview> allRiderReview = new ArrayList<>(); //declare rider review list

    public DeliveryRunnerReview(String riderReviewID, String riderID, String customerID, String riderReview, String reviewDate, int riderRating) {
        this.riderReviewID = riderReviewID;
        this.riderID = riderID;
        this.customerID = customerID;
        this.riderReview = riderReview;
        this.reviewDate = reviewDate;
        this.riderRating = riderRating;
    }

    public DeliveryRunnerReview() {
        this.riderReviewID = "";
        this.riderID = "";
        this.customerID = "";
        this.riderReview = "";
        this.reviewDate = "";
        this.riderRating = 0;
    }

    //reads all rider review data from file
    public static void readRiderReviewData() {
        allRiderReview.clear();
        try {

            File tFile = new File(RIDERREVIEWFILE);
            try (Scanner scanner = new Scanner(tFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] tData = data.split("\\|");

                    //checks data length first
                    if (tData.length == 6) {

                        DeliveryRunnerReview deliveryRunnerReview = new DeliveryRunnerReview();
                        deliveryRunnerReview.setRiderReviewID(tData[0]);
                        deliveryRunnerReview.setRiderID(tData[1]);
                        deliveryRunnerReview.setCustomerID(tData[2]);
                        deliveryRunnerReview.setRiderRating(Integer.parseInt(tData[3]));
                        deliveryRunnerReview.setRiderReview(tData[4]);
                        deliveryRunnerReview.setReviewDate(tData[5]);

                        allRiderReview.add(deliveryRunnerReview);

                    } else {

                        System.out.println("Rider Review class " + "Data Length Error" + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    public static ArrayList<DeliveryRunnerReview> getAllRiderReview() {
        return allRiderReview;
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(RIDERREVIEWFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("RV")) {
                    String numberPart = currentID.substring(2);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("RV%03d", newID + 1);
    }

    public void writeNewRiderReview(DeliveryRunnerReview deliveryRunnerReview) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RIDERREVIEWFILE, true))) {
            String riderReviewData = deliveryRunnerReview.getRiderReviewID() + "|"
                    + deliveryRunnerReview.getRiderID() + "|"
                    + deliveryRunnerReview.getCustomerID() + "|"
                    + deliveryRunnerReview.getRiderRating() + "|"
                    + deliveryRunnerReview.getRiderReview() + "|"
                    + deliveryRunnerReview.getReviewDate();

            writer.write(riderReviewData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public String getRiderReviewID() {
        return riderReviewID;
    }

    public void setRiderReviewID(String riderReviewID) {
        this.riderReviewID = riderReviewID;
    }

    public String getRiderID() {
        return riderID;
    }

    public void setRiderID(String riderID) {
        this.riderID = riderID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getRiderReview() {
        return riderReview;
    }

    public void setRiderReview(String riderReview) {
        this.riderReview = riderReview;
    }

    public String getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(String reviewDate) {
        this.reviewDate = reviewDate;
    }

    public int getRiderRating() {
        return riderRating;
    }

    public void setRiderRating(int riderRating) {
        this.riderRating = riderRating;
    }

    @Override
    public String toString() {
        return "DeliveryRunnerReview{" + "riderReviewID=" + riderReviewID + ", riderID=" + riderID + ", customerID=" + customerID + ", riderReview=" + riderReview + ", reviewDate=" + reviewDate + ", riderRating=" + riderRating + '}';
    }

}

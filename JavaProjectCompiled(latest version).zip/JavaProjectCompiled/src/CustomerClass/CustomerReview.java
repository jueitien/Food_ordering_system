/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class CustomerReview {

    private String reviewID, vendorID, orderID, customerID, customerReview, reviewDate;
    private int starRating;
    private static final String CUSTOMERREVIEWFILE = "src/data/CustomerReview.txt";
    private static ArrayList<CustomerReview> allCustomerReview = new ArrayList<>(); //declare review list

    public CustomerReview(String reviewID, String vendorID, String orderID, String customerID, String customerReview, String reviewDate, int starRating) {
        this.reviewID = reviewID;
        this.vendorID = vendorID;
        this.orderID = orderID;
        this.customerID = customerID;
        this.customerReview = customerReview;
        this.reviewDate = reviewDate;
        this.starRating = starRating;
    }

    public CustomerReview() {
        this.reviewID = "";
        this.vendorID = "";
        this.orderID = "";
        this.customerID = "";
        this.customerReview = "";
        this.reviewDate = "";
        this.starRating = 0;
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(CUSTOMERREVIEWFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("R")) {
                    String numberPart = currentID.substring(1);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("R%03d", newID + 1);
    }

    //reads all customer review data from file
    public static void readCustomerReviewData() {
        allCustomerReview.clear();
        try {

            File mFile = new File(CUSTOMERREVIEWFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] crData = data.split("\\|");

                    //checks data length first
                    if (crData.length == 7) {

                        CustomerReview customerReview = new CustomerReview();
                        customerReview.setReviewID(crData[0]);
                        customerReview.setVendorID(crData[1]);
                        customerReview.setOrderID(crData[2]);
                        customerReview.setCustomerID(crData[3]);
                        customerReview.setStarRating(Integer.parseInt(crData[4]));
                        customerReview.setCustomerReview((crData[5]));
                        customerReview.setReviewDate(crData[6]);

                        allCustomerReview.add(customerReview);

                    } else {

                        System.out.println("Customer Review class- " + "Data Length Error " + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    public static ArrayList<CustomerReview> getAllCustomerReview() {
        return allCustomerReview;
    }

    public static ArrayList<CustomerReview> getReviewByVendorID(String vendorID) {
        ArrayList<CustomerReview> vendorReviews = new ArrayList<>();
        for (CustomerReview customerReview : allCustomerReview) {
            if (customerReview.getVendorID().equals(vendorID)) {
                vendorReviews.add(customerReview);
                System.out.println(customerReview);
            }
        }
        return vendorReviews;
    }

    public static boolean checkReviewByCustomerID(String orderID, String customerID) {
        for (CustomerReview customerReview : allCustomerReview) {
            if (customerReview.getOrderID().equals(orderID)) {
                if (customerReview.getCustomerID().equals(customerID)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void writeNewCustomerReview(CustomerReview customerReview) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CUSTOMERREVIEWFILE, true))) {
            String customerReviewData = customerReview.getReviewID() + "|"
                    + customerReview.getVendorID() + "|"
                    + customerReview.getOrderID() + "|"
                    + customerReview.getCustomerID() + "|"
                    + customerReview.getStarRating() + "|"
                    + customerReview.getCustomerReview() + "|"
                    + customerReview.getReviewDate();

            writer.write(customerReviewData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public String getReviewID() {
        return reviewID;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getCustomerReview() {
        return customerReview;
    }

    public String getReviewDate() {
        return reviewDate;
    }

    public int getStarRating() {
        return starRating;
    }

    public void setReviewID(String reviewID) {
        this.reviewID = reviewID;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setCustomerReview(String customerReview) {
        this.customerReview = customerReview;
    }

    public void setReviewDate(String reviewDate) {
        this.reviewDate = reviewDate;
    }

    public void setStarRating(int starRating) {
        this.starRating = starRating;
    }

    @Override
    public String toString() {
        return "CustomerReview{" + "reviewID=" + reviewID + ", vendorID=" + vendorID + ", orderID=" + orderID + ", customerID=" + customerID + ", customerReview=" + customerReview + ", reviewDate=" + reviewDate + ", starRating=" + starRating + '}';
    }

}

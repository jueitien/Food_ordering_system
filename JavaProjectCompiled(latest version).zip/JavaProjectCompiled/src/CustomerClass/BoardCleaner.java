/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.util.HashMap;
import java.util.Map;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
public class BoardCleaner {

    private Map<String, JPanel> panelBoards = new HashMap<>();

    public void addPanelBoard(String cardName, JPanel panelBoard) {
        panelBoards.put(cardName, panelBoard);
    }

    public void cleanAllBoard() {
        for (JPanel panelBoard : panelBoards.values()) {
//            for (Map.Entry<String, JPanel> entry : panelBoards.entrySet()) {
//                String cardName = entry.getKey();
//                JPanel panelBoard = entry.getValue();

//                System.out.println("Cleaning: " + cardName);
//                System.out.println("Before Cleaning [" + cardName + "]: " + panelBoard.getComponentCount());

                panelBoard.removeAll();
                panelBoard.revalidate();
                panelBoard.repaint();
                
//                System.out.println("After Cleaning [" + cardName + "]: " + panelBoard.getComponentCount());
            }
        }
    }

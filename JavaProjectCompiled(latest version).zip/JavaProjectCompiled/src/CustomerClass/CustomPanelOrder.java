/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import Customer.CustomerMainMenu;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

/**
 *
 * @author user
 */
public class CustomPanelOrder extends JPanel {

    //decalre constant value for the icons
    private static final String FOODICON = "src/iconJava/foodIcon (3).png";
    private static final String CARTICON = "src/iconJava/cartIcon.png";

    //declare the name at the bottom left of the JPanel
    private String itemDesc;
    private double itemPrice;
    protected JLabel iconLabel, nameLabel, priceLabel, plusLabel, minusLabel, countLabel;
    protected JTextField descTextField;
    //count to track the amount in cart
    private int inCartCount = 0;

    public CustomPanelOrder(VendorItemMenu vendorItemMenu, CustomerMainMenu customerMainMenu, int itemCount, boolean historyDetail) {

        setPreferredSize(new Dimension(250, 250));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createSoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.BLACK));
        setLayout(new GridBagLayout());
//        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);

        iconLabel = new JLabel();
        setIcon();
        gbc.weightx = 0.5;
        gbc.gridx = 0;
        gbc.gridy = 0;
        iconLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        add(iconLabel, gbc);

        nameLabel = new JLabel(vendorItemMenu.getItemName().replace("_", " "), SwingConstants.CENTER);
        nameLabel.setFont(new Font("Segoe UI", Font.CENTER_BASELINE, 14));
        nameLabel.setPreferredSize(new Dimension(120, 50));
        nameLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(nameLabel, gbc);

//        descTextField = new JTextField();
        descTextField = new JTextField(vendorItemMenu.getItemDesc().replace("_", " "));
        descTextField.setHorizontalAlignment(SwingConstants.CENTER);
        descTextField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descTextField.setEditable(false);
        descTextField.setFocusable(false);
        descTextField.setBackground(Color.WHITE);
        descTextField.setPreferredSize(new Dimension(380, 100));
        descTextField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(descTextField, gbc);

        priceLabel = new JLabel("Price: $" + vendorItemMenu.getItemPrice(), SwingConstants.CENTER);
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        priceLabel.setBackground(Color.WHITE);
        priceLabel.setPreferredSize(new Dimension(150, 50));
        priceLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(priceLabel, gbc);

        minusLabel = new JLabel("-", SwingConstants.CENTER);
        minusLabel.setFont(new Font("Segoe UI", Font.BOLD, 40));
        minusLabel.setBackground(Color.WHITE);
        minusLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
//        minusLabel.setPreferredSize(new Dimension(150, 50));
//        minusLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 2;
        gbc.gridy = 1;
        add(minusLabel, gbc);

        if (historyDetail) {
            countLabel = new JLabel(itemCount + "", SwingConstants.CENTER);
        } else {
            countLabel = new JLabel("0", SwingConstants.CENTER);
        }
        countLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        countLabel.setBackground(Color.WHITE);
//        countLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
//        countLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        gbc.gridx = 3;
        gbc.gridy = 1;
        add(countLabel, gbc);

        plusLabel = new JLabel("+", SwingConstants.CENTER);
        plusLabel.setFont(new Font("Segoe UI", Font.BOLD, 27));
        plusLabel.setBackground(Color.WHITE);
        plusLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
//        minusLabel.setPreferredSize(new Dimension(150, 50));
//        plusLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 4;
        gbc.gridy = 1;
        add(plusLabel, gbc);

        for (MouseListener listener : getMouseListeners()) {
            removeMouseListener(listener);
        }
//        add event listener to the custom panel
        if (!historyDetail) {
            minusLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (customerMainMenu.orderID == null && inCartCount > 1) {
                        inCartCount--;
                        customerMainMenu.updateCartCount(vendorItemMenu.getItemID(), inCartCount);
                        customerMainMenu.updateTotalAmount(vendorItemMenu.getItemPrice(), itemCount, false);
                        updateCountLabel();
//                    System.out.println(inCartCount + " amount in cart");
//                    System.out.println(vendorItemMenu.getItemName().replace("_", " ") + " button clicked!3");
                    } else if (customerMainMenu.orderID == null && inCartCount == 1) {
                        int notify = JOptionPane.showConfirmDialog(null, "Remove Item - " + vendorItemMenu.getItemName().replace("_", " ") + " from cart?", "Question", JOptionPane.YES_NO_OPTION);
                        if (notify == JOptionPane.YES_OPTION) {
                            inCartCount--;
                            customerMainMenu.updateCartCount(vendorItemMenu.getItemID(), inCartCount);
                            customerMainMenu.updateTotalAmount(vendorItemMenu.getItemPrice(), itemCount, false);
                            customerMainMenu.removeCountZeroItem();
                        }
                    }
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    minusLabel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    minusLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                }
            });

            plusLabel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (customerMainMenu.orderID == null) {
                        inCartCount++;
                        customerMainMenu.updateCartCount(vendorItemMenu.getItemID(), inCartCount);
                        customerMainMenu.updateTotalAmount(vendorItemMenu.getItemPrice(), itemCount, true);
                        updateCountLabel();
//                    System.out.println(inCartCount + " amount in cart");
//                    System.out.println(vendorItemMenu.getItemName().replace("_", " ") + " button clicked!3");
                    }
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    plusLabel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    plusLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                }
            });

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    plusLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
                    minusLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    plusLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                    minusLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                }

            });

        }
    }

    protected void setIcon() {
        String iconPath = FOODICON;
        //catch error for icon placement
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            iconLabel.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            iconLabel.setText("Icon Missing");
        }
    }

    public void setCartCount(int pastCartCount) {
        inCartCount = pastCartCount;
        countLabel.setText(String.valueOf(inCartCount));
    }

    public void updateCountLabel() {
        countLabel.setText(String.valueOf(inCartCount));
        countLabel.revalidate();
        countLabel.repaint();
    }
}

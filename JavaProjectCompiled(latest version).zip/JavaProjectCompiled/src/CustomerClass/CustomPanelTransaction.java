/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

/**
 *
 * @author user
 */
public class CustomPanelTransaction extends JPanel {

    protected JLabel timeLabel, dateLabel, creditBeforeLabel, creditAfterLabel, totalAmountLabel, refundLabel;
    private double totalAmount;

    public CustomPanelTransaction(TransactionLog transactionLog) {

        setPreferredSize(new Dimension(120, 120));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createSoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.BLACK));
        setLayout(new GridBagLayout());
//        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 30, 10, 30);

        timeLabel = new JLabel("Time: " + transactionLog.getTransactionTime(), SwingConstants.CENTER);
        timeLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        timeLabel.setHorizontalAlignment(SwingConstants.LEFT);
//        timeLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        timeLabel.setBorder(BorderFactory.createEmptyBorder(0, 90, 0, 0));
//        dateLabel.setPreferredSize(new Dimension(60, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        add(timeLabel, gbc);

        dateLabel = new JLabel("Date: " + transactionLog.getTransactionDate(), SwingConstants.CENTER);
        dateLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        dateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
//        dateLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        dateLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 90));
//        dateLabel.setPreferredSize(new Dimension(60, 20));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
//        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        add(dateLabel, gbc);

        creditBeforeLabel = new JLabel("Credit Before: " + String.format("%.2f", transactionLog.getCreditBefore()), SwingConstants.LEFT);
        creditBeforeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        creditBeforeLabel.setHorizontalAlignment(SwingConstants.LEFT);
//        creditBeforeLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        creditBeforeLabel.setBorder(BorderFactory.createEmptyBorder(0, 90, 0, 0));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
//        gbc.weightx = 0.1;
        gbc.anchor = GridBagConstraints.WEST;
        add(creditBeforeLabel, gbc);

        creditAfterLabel = new JLabel("Credit After: " + String.format("%.2f", transactionLog.getCreditAfter()), SwingConstants.LEFT);
        creditAfterLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        creditAfterLabel.setHorizontalAlignment(SwingConstants.LEFT);
//        creditAfterLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        creditAfterLabel.setBorder(BorderFactory.createEmptyBorder(0, 90, 0, 0));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
//        gbc.weightx = 0.2;
        gbc.anchor = GridBagConstraints.WEST;
        add(creditAfterLabel, gbc);

        totalAmount = transactionLog.getCreditBefore() - transactionLog.getCreditAfter();
        totalAmountLabel = new JLabel("Total Amount: " + String.format("%.2f", totalAmount), SwingConstants.RIGHT);
        totalAmountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        totalAmountLabel.setHorizontalAlignment(SwingConstants.RIGHT);
//        totalAmountLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        totalAmountLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 90));
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
//        gbc.weightx = 0.5;
        gbc.anchor = GridBagConstraints.EAST;
        add(totalAmountLabel, gbc);

        refundLabel = new JLabel(TransactionLog.checkRefund(transactionLog.getIsRefund()), SwingConstants.RIGHT);
//        refundLabel = new JLabel("Refund", SwingConstants.RIGHT);
        refundLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        refundLabel.setHorizontalAlignment(SwingConstants.RIGHT);
//        refundLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        refundLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 90));
        refundLabel.setPreferredSize(new Dimension(50, 20));
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.weightx = 0.1;
        gbc.anchor = GridBagConstraints.EAST;
        add(refundLabel, gbc);

        // Prevent clearing refundLabel if instance is CustomPanelHistory
//        if (!(this instanceof CustomPanelHistory)) {
//            checkRefund(transactionLog);
//        }
//        checkRefund(transactionLog);
    }

//    protected void checkRefund(TransactionLog transactionLog) {
//        if (transactionLog.getIsRefund().equalsIgnoreCase("false")) {
//            refundLabel.setText("");
//        }
//    }
}

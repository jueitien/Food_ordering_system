/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class ItemOrder {

    private String orderItemID, orderID, itemID;
    private int itemQuantity;
    private double itemTotal;
    private static final String ORDERITEMFILE = "src/data/ItemOrder.txt";
    private static ArrayList<ItemOrder> allOrderItem = new ArrayList<>();

    public ItemOrder(String orderItemID, String orderID, String itemID, int itemQuantity, double itemTotal) {
        this.orderItemID = orderItemID;
        this.orderID = orderID;
        this.itemID = itemID;
        this.itemQuantity = itemQuantity;
        this.itemTotal = itemTotal;
    }

    public ItemOrder() {
        this.orderItemID = "";
        this.orderID = "";
        this.itemID = "";
        this.itemQuantity = 0;
        this.itemTotal = 0;
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERITEMFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("OI")) {
                    String numberPart = currentID.substring(2);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("OI%03d", newID + 1);
    }

    public static void readOrderItemData() {
        allOrderItem.clear();
        try {

            File mFile = new File(ORDERITEMFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] mData = data.split("\\|");

                    //checks data length first
                    if (mData.length == 5) {

                        ItemOrder orderItem = new ItemOrder();
                        orderItem.setOrderItemID(mData[0]);
                        orderItem.setOrderID(mData[1]);
                        orderItem.setItemID(mData[2]);
                        orderItem.setItemQuantity(Integer.parseInt(mData[3]));
                        orderItem.setItemTotal(Double.parseDouble(mData[4]));
                        allOrderItem.add(orderItem);

                    } else {

                        System.out.println("Order Item class " + "Data Length Error" + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    public static ArrayList<ItemOrder> getAllOrderItem() {
        return allOrderItem;
    }

    public static ArrayList<ItemOrder> getOrderItemByOrderID(String OrderID) {
        ArrayList<ItemOrder> orderItems = new ArrayList<>();
        for (ItemOrder orderItem : allOrderItem) {
            if (orderItem.getOrderID().equals(OrderID)) {
                orderItems.add(orderItem);
//                System.out.println(orderItem);
            }
        }
        return orderItems;
    }

    public static int totalCustomerOrderItem(String orderID) {
        int totalItemOrder = 0;
        for (ItemOrder orderItem : allOrderItem) {
            if (orderItem.getOrderID().equals(orderID)) {
                totalItemOrder += orderItem.getItemQuantity();
            }
        }
        return totalItemOrder;
    }

    public void writeNewOrderItem(ItemOrder orderItem) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ORDERITEMFILE, true))) {
            String notificationData = orderItem.getOrderItemID() + "|"
                    + orderItem.getOrderID() + "|"
                    + orderItem.getItemID() + "|"
                    + orderItem.getItemQuantity() + "|"
                    + orderItem.getItemTotal();

            writer.write(notificationData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public String getOrderItemID() {
        return orderItemID;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getItemID() {
        return itemID;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public double getItemTotal() {
        return itemTotal;
    }

    public void setOrderItemID(String orderItemID) {
        this.orderItemID = orderItemID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public void setItemTotal(double itemTotal) {
        this.itemTotal = itemTotal;
    }

    @Override
    public String toString() {
        return "OrderItem{" + "orderItemID=" + orderItemID + ", orderID=" + orderID + ", itemID=" + itemID + ", itemQuantity=" + itemQuantity + ", itemTotal=" + itemTotal + '}';
    }

}

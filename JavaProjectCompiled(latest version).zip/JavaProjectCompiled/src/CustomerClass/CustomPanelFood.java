/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import Customer.CustomerMainMenu;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

/**
 *
 * @author user
 */
public class CustomPanelFood extends CustomPanelVendor {

    //decalre constant value for the icons
    private static final String FOODICON = "src/iconJava/foodIcon (3).png";
    private static final String CARTICON = "src/iconJava/cartIcon.png";

    //declare the name at the bottom left of the JPanel
    private String itemDesc;
    private double itemPrice;
    protected JLabel priceLabel, cartLabel, countLabel;
    protected JTextField descTextField;
    //count to track the amount in cart
    private int cartCount;

    public CustomPanelFood(String labelName, String vendorID, CustomerMainMenu customerMainMenu, String itemDesc, Double itemPrice, String itemID) {
        super(labelName, vendorID, customerMainMenu);

        this.itemDesc = itemDesc;
        this.itemPrice = itemPrice;

        setPreferredSize(new Dimension(250, 250));
        setLayout(new GridBagLayout());

        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);

        remove(iconLabel);
        iconLabel = new JLabel();
        setIcon();
//        iconLabel.setPreferredSize(new Dimension(50, 50));
//        iconLabel.setPreferredSize(new Dimension(130, 120));
//        iconLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        gbc.weightx = 0.5;
//        gbc.fill = GridBagConstraints.HORIZONTAL;  
        gbc.gridx = 0;
        gbc.gridy = 0;
        iconLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
//        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(iconLabel, gbc);

        nameLabel.setFont(new Font("Segoe UI", Font.CENTER_BASELINE, 14));
//        nameLabel.setPreferredSize(new Dimension(50, 50));
        nameLabel.setPreferredSize(new Dimension(120, 50));
//        nameLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        nameLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 0;
        gbc.gridy = 1;
//        gbc.anchor = GridBagConstraints.SOUTHWEST;
        add(nameLabel, gbc);

        descTextField = new JTextField(itemDesc);
        descTextField.setHorizontalAlignment(SwingConstants.CENTER);
        descTextField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descTextField.setEditable(false);
        descTextField.setFocusable(false);
//        descTextField.setBorder(null);
        descTextField.setBackground(Color.WHITE);
//        descTextField.setPreferredSize(new Dimension(50, 50));
        descTextField.setPreferredSize(new Dimension(380, 100));
        descTextField.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
//        gbc.gridwidth = 3;
        gbc.gridx = 1;
        gbc.gridy = 0;
//        gbc.anchor = GridBagConstraints.NORTHWEST;
        add(descTextField, gbc);

        priceLabel = new JLabel("Price: $" + itemPrice, SwingConstants.CENTER);
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        priceLabel.setBackground(Color.WHITE);
//        priceLabel.setPreferredSize(new Dimension(50, 50));
        priceLabel.setPreferredSize(new Dimension(150, 50));
        priceLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        gbc.gridy = 1;
//        gbc.gridwidth = 1;
//        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(priceLabel, gbc);

        cartLabel = new JLabel();
        setCartIcon();
//        cartLabel.setPreferredSize(new Dimension(20, 20));
//        cartLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        cartLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
        gbc.gridx = 2;
        gbc.gridy = 1;
//        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(cartLabel, gbc);

        countLabel = new JLabel("0", SwingConstants.CENTER);
        countLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        countLabel.setBackground(Color.WHITE);
//        priceLabel.setPreferredSize(new Dimension(50, 50));
//        priceLabel.setPreferredSize(new Dimension(400, 50));
        countLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        countLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));
        gbc.gridx = 3;
        gbc.gridy = 1;
//        gbc.gridwidth = 1;
//        gbc.anchor = GridBagConstraints.SOUTHEAST;
        add(countLabel, gbc);
//        addMouseListener(new CustomPanelVendor.PanelEventListener(customerMainMenu, labelName));

        for (MouseListener listener : getMouseListeners()) {
            removeMouseListener(listener);
        }
//        add event listener to the custom panel
        cartLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (customerMainMenu.orderID == null) {
                    customerMainMenu.setLastVendorID(vendorID);
                    customerMainMenu.checkVendorID(itemID);
                    if (customerMainMenu.getProceedAdding()) {
                        cartCount++;
                        customerMainMenu.updateCartCount(itemID, cartCount);
                        updateCountLabel();
                        System.out.println(labelName + " button clicked!2");
                        System.out.println(cartCount + " amount in cart");
                    }
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                cartLabel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                cartLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                cartLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                cartLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
            }

        });
    }

//    @Override
//    protected class PanelEventListener extends MouseAdapter {
//        private final CustomerMainMenu customerMainMenu;
//        private final String itemName;
//        
//        public PanelEventListener(CustomerMainMenu customerMainMenu, String itemName) {
//            this.customerMainMenu = customerMainMenu;
//            this.itemName = itemName;
//        }
//        
//        @Override
//        public void mouseClicked(MouseEvent e) {
////            customerMainMenu.displayVendorItemMenu();
//            System.out.println(itemName + " button clicked!");
//        }
//    }
    //function to place icon into label depending on the icon type requested to be place in it
    @Override
    protected void setIcon() {
        String iconPath = FOODICON;
        //catch error for icon placement
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            iconLabel.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            iconLabel.setText("Icon Missing");
        }
    }

    protected void setCartIcon() {
        String iconPath = CARTICON;
        //catch error for icon placement
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
            cartLabel.setIcon(new ImageIcon(scaledIcon));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            cartLabel.setText("Icon Missing");
        }
    }

    public void setCartCount(int pastCartCount) {
        cartCount = pastCartCount;
        countLabel.setText(String.valueOf(cartCount));
    }

    public void updateCountLabel() {
        countLabel.setText(String.valueOf(cartCount));
        countLabel.revalidate();
        countLabel.repaint();
    }

//    //resets the count in cart to 0
//    public void resetCount() {
//        cartCount = 0;
//        countLabel.setText("0");
//        System.out.println("cartCount reset to 0");
//    }
    @Override
    public String getLabelName() {
        return super.getLabelName();
    }

    //setter also sets the label name for the bottom part of the label
    @Override
    public void setLabelName(String labelName) {
        super.setLabelName(labelName);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Customer {

    private String customerID, username, password, address, adminID;
    private double credit;
    private static final String CUSTOMERFILE = "src/data/Customer.txt"; //declare default customer txt file path
    private static ArrayList<Customer> allCustomers = new ArrayList<>(); //declare customer list

    public Customer(String customerID, String username, String password, String address, String adminID, double credit) {
        this.customerID = customerID;
        this.username = username;
        this.password = password;
        this.address = address;
        this.adminID = adminID;
        this.credit = credit;
    }

    //default value constructor
    public Customer() {
        this.customerID = "";
        this.username = "";
        this.password = "";
        this.address = "";
        this.adminID = "";
        this.credit = 0.0;
    }

    //customer login
    public static Customer customerLogin(String cUsername, String cPassword) {
        try {

            File cFile = new File(CUSTOMERFILE);
            try (Scanner scanner = new Scanner(cFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] cData = data.split("\\|");

                    //checks data length first
                    if (cData.length == 6) {

                        //verify username and password
                        if (cData[1].equals(cUsername) && cData[2].equals(cPassword)) {

                            //call Customer constructor with Customer data as perimeter
                            return new Customer(cData[0], cData[1], cData[2], cData[5], cData[4], Double.parseDouble(cData[3]));
                        }

                    } else {

                        System.out.println("Customer class- " + "Data Length Error " + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }

        //returns null if nothing is found
        return null;
    }

    //reads customer data from file
    public static void readCustomerData() {
        try {

            File cFile = new File(CUSTOMERFILE);
            try (Scanner scanner = new Scanner(cFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] CData = data.split("\\|");

                    //checks data length first
                    if (CData.length == 6) {

                        Customer customer = new Customer();
                        customer.setCustomerID(CData[0]);
                        customer.setUsername(CData[1]);
                        customer.setPassword(CData[2]);
                        customer.setCredit(Double.parseDouble(CData[3]));
                        customer.setAddress(CData[4]);
                        customer.setAdminID(CData[5]);

                        allCustomers.add(customer);

                    } else {

                        System.out.println("Customer class- " + "Data Length Error " + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    //getter for  all customer data
    public static ArrayList<Customer> getAllCustomers() {
        return allCustomers;
    }

    public static String getCustomerUsernameByCustomerID(String customerID) {
        for (Customer customer : allCustomers) {
                if (customer.getCustomerID().equals(customerID)) {
                    return customer.getUsername();
                }
        }
        return null;
    }

    public void creditUpdateFile(String currentCustomerID, String formattedCreditAfter) {
        File inputFile = new File(CUSTOMERFILE);
        File tempFile = new File("Customer_temp.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile)); BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                String[] parts = currentLine.split("\\|");

                if (parts[0].equals(currentCustomerID)) {
                    parts[3] = formattedCreditAfter;
                }

                writer.write(String.join("|", parts));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        if (!inputFile.delete()) {
            System.out.println("customer old file not deleted");
        }
        if (!tempFile.renameTo(inputFile)) {
            System.out.println("customer temporary file not renamed");
        }
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getAddress() {
        return address;
    }

    public double getCredit() {
        return credit;
    }

    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    //format Customer to string when printed
    @Override
    public String toString() {
        return "Customer{" + "customerID=" + customerID + ", username=" + username + ", password=" + password + ", address=" + address + ", credit=" + credit + '}';
    }

}

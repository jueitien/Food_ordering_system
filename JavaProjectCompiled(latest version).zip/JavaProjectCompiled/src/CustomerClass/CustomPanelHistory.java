/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import Customer.CustomerMainMenu;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class CustomPanelHistory extends CustomPanelTransaction {

    public CustomPanelHistory(Order order, CustomerMainMenu customerMainMenu) {
        //declare dummy object to avoid parsing transaction parameter into child constructor
        super(new TransactionLog(
                "dummyID", // transactionID
                "null", // isRefund
                "null", // transactionDate
                "null",//transactionTime
                "null",// notificationType
                0.0, // creditBefore
                0.0 // creditAfter
        ));

        timeLabel.setText("Time: " + order.getOrderTime());

        dateLabel.setText("Date: " + order.getOrderDate());

        //repurpose credit before label into vendor username label
        creditBeforeLabel.setText("Vendor Name: " + Vendor.getVendorUsernameByVendorID(order.getVendorID()));

        //repurpose credit after label into total item label
        creditAfterLabel.setText("Item Amount: " + ItemOrder.totalCustomerOrderItem(order.getOrderID()));

        //repurpose totalAmountLabel to show total amount bought for the items in the order
        totalAmountLabel.setText("Total Amount: " + String.format("%.2f", order.getOrderTotal()));

        //repurpose refundLabel to show status for the order (usually completed or cancelled)
//        System.out.println(order.getOrderStatus());
//        refundLabel.setText("Status: ");
        refundLabel.setText("Status: " + order.getOrderStatus());
        refundLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
//        refundLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        refundLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 90));
        refundLabel.setPreferredSize(new Dimension(300, 30));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
//                JOptionPane.showMessageDialog(null, "Panel Clicked! Order ID: " + order.getOrderID());
                customerMainMenu.displayHistoryDetailMenu(order);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
            }

        });
    }

}

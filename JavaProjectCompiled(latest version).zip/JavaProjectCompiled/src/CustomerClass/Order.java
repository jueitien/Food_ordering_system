/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Order {

    private String orderID, customerID, vendorID, TransactionID, orderDate, orderTime, orderPlacement, vendorAccepted, runnerAccepted, orderStatus;
    private double orderTotal;
    private static final String ORDERFILE = "src/data/Order.txt"; //declare default order txt file path
    private static ArrayList<Order> allOrder = new ArrayList<>(); //declare order list

    public Order(String orderID, String customerID, String vendorID, String TransactionID, String orderDate, String orderTime, String orderPlacement, String vendorAccepted, String runnerAccepted, String orderStatus, double orderTotal) {
        this.orderID = orderID;
        this.customerID = customerID;
        this.vendorID = vendorID;
        this.TransactionID = TransactionID;
        this.orderDate = orderDate;
        this.orderTime = orderTime;
        this.orderPlacement = orderPlacement;
        this.vendorAccepted = vendorAccepted;
        this.runnerAccepted = runnerAccepted;
        this.orderStatus = orderStatus;
        this.orderTotal = orderTotal;
    }

    public Order() {
        this.orderID = "";
        this.customerID = "";
        this.vendorID = "";
        this.TransactionID = "";
        this.orderDate = "";
        this.orderTime = "";
        this.orderPlacement = "";
        this.vendorAccepted = "";
        this.runnerAccepted = "";
        this.orderStatus = "";
        this.orderTotal = 0.0;
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("O")) {
                    String numberPart = currentID.substring(1);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("O%03d", newID + 1);
    }

    //reads all order data from file
    public static void readOrderData() {
        allOrder.clear();
        try {

            File mFile = new File(ORDERFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] mData = data.split("\\|");

                    //checks data length first
                    if (mData.length == 11) {

                        Order order = new Order();
                        order.setOrderID(mData[0]);
                        order.setCustomerID(mData[1]);
                        order.setVendorID(mData[2]);
                        order.setTransactionID(mData[3]);
                        order.setOrderDate(mData[4]);
                        order.setOrderTime(mData[5]);
                        order.setOrderTotal(Double.parseDouble(mData[6]));
                        order.setOrderPlacement(mData[7]);
                        order.setVendorAccepted(mData[8]);
                        order.setRunnerAccepted(mData[9]);
                        order.setOrderStatus(mData[10]);

                        allOrder.add(order);

                    } else {

                        System.out.println("Order class " + "Data Length Error" + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    public void writeNewOrder(Order order) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ORDERFILE, true))) {
            String orderData = order.getOrderID() + "|"
                    + order.getCustomerID() + "|"
                    + order.getVendorID() + "|"
                    + order.getTransactionID() + "|"
                    + order.getOrderDate() + "|"
                    + order.getOrderTime() + "|"
                    + order.getOrderTotal() + "|"
                    + order.getOrderPlacement() + "|"
                    + order.getVendorAccepted() + "|"
                    + order.getRunnerAccepted() + "|"
                    + order.getOrderStatus();

            writer.write(orderData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    //main function check in order file for item order placement (part[7])
    //null if all riders rejects
    //return false if not null, return true if null
//    public boolean updateRiderDecline() {
//        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERFILE))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] parts = line.split("\\|");
//                String orderStatusCurrent = parts[7];
//                if (orderStatusCurrent.equalsIgnoreCase("null")) {
//                    return true;
//                }
//            }
//        } catch (IOException e) {
//            System.out.println(e.getMessage());
//        }
//        return false;
//    }
//
//    public int updateStatusNumber() {
//        int statusNumber = 0;
//        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERFILE))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                String[] parts = line.split("\\|");
//                String orderStatusCurrent = parts[10];
//                statusNumber = getStatusNumber(orderStatusCurrent);
//            }
//        } catch (IOException e) {
//            System.out.println(e.getMessage());
//        }
//        return statusNumber;
//    }
    //merged 2 function into one object function ^^^^^ refer above ^^^^^
    //main function gives update based on the current status of the order
    //checks order status (part 10) and gives a number for each status
    //checks order placement is null or not, if null gives a boolean value true
    public Object[] updateOrderCurrent() {
        int statusNumber = 0;
        boolean riderDecline = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(ORDERFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");

                //checks order status
                String orderStatusCurrent = parts[10];
                statusNumber = getStatusNumber(orderStatusCurrent);

                //checks order placement is null or not
                String orderPlacementCurrent = parts[7];
                if (orderPlacementCurrent.equalsIgnoreCase("null")) {
                    riderDecline = true;
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return new Object[]{statusNumber, riderDecline};
    }

    public static ArrayList<Order> getAllOrder() {
        return allOrder;
    }

    public void orderPlacementUpdateFile(String currentOrderID, String choosenOption) {
        File inputFile = new File(ORDERFILE);
        File tempFile = new File("Order_temp.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile)); BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                String[] parts = currentLine.split("\\|");

                if (parts[0].equals(currentOrderID)) {
                    parts[7] = choosenOption;
                }

                writer.write(String.join("|", parts));
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        if (!inputFile.delete()) {
            System.out.println("order old file not deleted");
        }
        if (!tempFile.renameTo(inputFile)) {
            System.out.println("order temporary file not renamed");
        }
    }

    private int getStatusNumber(String orderStatus) {
        return switch (orderStatus.toLowerCase()) {
            case "pending" ->
                1;
            case "preparing" ->
                2;
            case "prepared" ->
                3;
            case "delivering" ->
                4;
            case "completed" ->
                5;
            case "cancelled" ->
                6;
            default ->
                0;
        };
    }

    public static Order getOrderByOrderID(String orderID) {
        for (Order order : allOrder) {
            if (order.getOrderID().equals(orderID)) {
                return order;
            }
        }
        return null;
    }

    public static String getVendorIDByOrderID(String orderID) {
        for (Order order : allOrder) {
            if (order.getOrderID().equals(orderID)) {
                return order.vendorID;
            }
        }
        return null;
    }

    public static ArrayList<Order> getOrderByCustomerID(String customerID) {
        ArrayList<Order> customerOrders = new ArrayList<>();
        for (Order order : allOrder) {
            if (order.getCustomerID().equals(customerID)) {
                customerOrders.add(order);
            }
        }
        return customerOrders;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getTransactionID() {
        return TransactionID;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public String getOrderPlacement() {
        return orderPlacement;
    }

    public String getVendorAccepted() {
        return vendorAccepted;
    }

    public String getRunnerAccepted() {
        return runnerAccepted;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public void setTransactionID(String TransactionID) {
        this.TransactionID = TransactionID;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public void setOrderPlacement(String orderPlacement) {
        this.orderPlacement = orderPlacement;
    }

    public void setVendorAccepted(String vendorAccepted) {
        this.vendorAccepted = vendorAccepted;
    }

    public void setRunnerAccepted(String runnerAccepted) {
        this.runnerAccepted = runnerAccepted;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }

    @Override
    public String toString() {
        return "Order{" + "orderID=" + orderID + ", customerID=" + customerID + ", vendorID=" + vendorID + ", TransactionID=" + TransactionID + ", orderDate=" + orderDate + ", orderTime=" + orderTime + ", orderPlacement=" + orderPlacement + ", vendorAccepted=" + vendorAccepted + ", runnerAccepted=" + runnerAccepted + ", orderStatus=" + orderStatus + ", orderTotal=" + orderTotal + '}';
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
//extends custom panel notification class because of similar layouts
public class CustomPanelReview extends CustomPanelNotification {

    private static final String FILLEDSTARICON = "src/iconJava/filledStarIcon.png";
    private JPanel starPanel;

    public CustomPanelReview(CustomerReview customerReview) {
        super(new Notification(
                "dummyID", // notificationID
                customerReview.getCustomerReview(), // notificationText
                customerReview.getReviewDate(), // notificationDate
                "review", // notificationType
                customerReview.getCustomerID(), // senderID
                "vendor" // recipientID
        ));
        
        setPreferredSize(new Dimension(150, 150));

        //repurpose notification type label to customer username
        notificationTypeLabel.setText(Customer.getCustomerUsernameByCustomerID(customerReview.getCustomerID()));
//        notificationTypeLabel = new JLabel(Customer.getCustomerUsernameByCustomerID(customerReview.getCustomerID()), SwingConstants.CENTER);
//        System.out.println(Customer.getCustomerUsernameByCustomerID(customerReview.getCustomerID()));
//        add(notificationTypeLabel, gbc);

        //adjust date label to fit customer review date
        dateLabel.setText(customerReview.getReviewDate());
//        dateLabel = new JLabel(customerReview.getReviewDate(), SwingConstants.CENTER);

        // Repurpose clear label to customer star rating
        clearLabel.setText(""); // Clear any existing text
        starPanel = new JPanel(); // Initialize star panel
        starPanel.setBackground(Color.WHITE);
//        starPanel.setOpaque(false); // Make it transparent
//        clearLabel.setLayout(new java.awt.FlowLayout(FlowLayout.LEFT)); // Set layout for clearLabel
        countingStar(customerReview.getStarRating());
        remove(clearLabel); // Remove clearLabel since it's not used
        GridBagConstraints gbc = new GridBagConstraints();
        starPanel.setPreferredSize(new Dimension(200, 30));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        add(starPanel, gbc);

        //repurpose message text field to customer review text field
        messageTextArea.setText(customerReview.getCustomerReview().replace("_", " "));
        messageTextArea.setPreferredSize(new Dimension(600, 65));
//        scrollPane.setPreferredSize(new Dimension(600, 30));
//        messageTextField = new JTextField(customerReview.getCustomerReview().replace("_", " "));

    }

    private void countingStar(int starCount) {
        for (int i = 1; i <= starCount; i++) {
            setStarIcon();
        }
        starPanel.revalidate();
        starPanel.repaint();
    }

    protected void setStarIcon() {
        String iconPath = FILLEDSTARICON;
        //catch error for icon placement
        try {
            ImageIcon icon = new ImageIcon(iconPath);
            //scale the icon size
            Image scaledIcon = icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            JLabel starLabel = new JLabel(new ImageIcon(scaledIcon));
            starPanel.add(starLabel);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            //replace label with Icon Missing msg when there is an error
            starPanel.add(new JLabel("Icon Missing"));;
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import Customer.CustomerMainMenu;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class CustomPanelStarRating extends JPanel {

    private final List<JLabel> starLabels = new ArrayList<>();
    private final Icon filledStar;
    private final Icon emptyStar;
    private int rating = 0;
    private CustomerMainMenu customerMainMenu;
    private boolean isDelivery;

    public CustomPanelStarRating(CustomerMainMenu customerMainMenu, boolean isDelivery) {
        // Load icons
        filledStar = loadIcon("src/iconJava/filledStarIcon.png");
        emptyStar = loadIcon("src/iconJava/starIcon.png");
        
        this.customerMainMenu = customerMainMenu;
        this.isDelivery = isDelivery;

        // Set layout
//        setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        // Initialize star labels
        for (int i = 0; i < 5; i++) {
            JLabel starLabel = new JLabel(emptyStar);
//            starLabel.setPreferredSize(new Dimension(filledStar.getIconWidth(), filledStar.getIconHeight()));
            starLabel.addMouseListener(new StarMouseListener(i + 1));
            starLabels.add(starLabel);
            add(starLabel);
        }
    }

    private Icon loadIcon(String path) {
        ImageIcon icon = new ImageIcon(path);
        Image scaledImage = icon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }

    public int getRating() {
        return rating;
    }

    private void setRating(int rating) {
        this.rating = rating;
        for (int i = 0; i < starLabels.size(); i++) {
            if (i < rating) {
                starLabels.get(i).setIcon(filledStar);
            } else {
                starLabels.get(i).setIcon(emptyStar);
            }
        }
    }

    private class StarMouseListener extends MouseAdapter {

        private final int starValue;

        public StarMouseListener(int starValue) {
            this.starValue = starValue;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            setRating(starValue);
            if (isDelivery) {
                customerMainMenu.setRiderStarRating(starValue);
            } else {
                customerMainMenu.setCustomerStarRating(starValue);
            }
            System.out.println(starValue);
        }

//        @Override
//        public void mouseEntered(MouseEvent e) {
//            setRating(starValue);
//        }
//        @Override
//        public void mouseExited(MouseEvent e) {
//            setRating(rating);
//        }
    }
}

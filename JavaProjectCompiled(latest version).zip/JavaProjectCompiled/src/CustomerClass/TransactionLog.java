/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class TransactionLog {

    private String transactionID, customerID, isRefund, transactionDate, transactionTime;
    private double creditBefore, creditAfter;
    private static final String TRANSACTIONFILE = "src/data/TransactionLog.txt"; //declare default transaction txt file path
    private static ArrayList<TransactionLog> allTransactionLog = new ArrayList<>(); //declare transaction list

    public TransactionLog(String transactionID, String customerID, String isRefund, String transactionDate, String transactionTime, double creditBefore, double creditAfter) {
        this.transactionID = transactionID;
        this.isRefund = isRefund;
        this.transactionDate = transactionDate;
        this.transactionTime = transactionTime;
        this.creditBefore = creditBefore;
        this.creditAfter = creditAfter;
    }

    public TransactionLog() {
        this.transactionID = "";
        this.isRefund = "";
        this.transactionDate = "";
        this.transactionTime = "";
        this.creditBefore = 0.0;
        this.creditAfter = 0.0;
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(TRANSACTIONFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("T")) {
                    String numberPart = currentID.substring(1);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("T%03d", newID + 1);
    }

    //reads all vendor item menu data from file
    public static void readTransactionLogData() {
        allTransactionLog.clear();
        try {

            File mFile = new File(TRANSACTIONFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] tData = data.split("\\|");

                    //checks data length first
                    if (tData.length == 7) {

                        TransactionLog transactionLog = new TransactionLog();
                        transactionLog.setTransactionID(tData[0]);
                        transactionLog.setCustomerID(tData[1]);
                        transactionLog.setCreditBefore(Double.parseDouble(tData[2]));
                        transactionLog.setCreditAfter(Double.parseDouble(tData[3]));
                        transactionLog.setIsRefund(tData[4]);
                        transactionLog.setTransactionDate(tData[5]);
                        transactionLog.setTransactionTime(tData[6]);

                        allTransactionLog.add(transactionLog);

                    } else {

                        System.out.println("Transaction class- " + "Data Length Error " + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    //getter for  all vendor item menu data
    public static ArrayList<TransactionLog> getAllTransactionLog() {
        return allTransactionLog;
    }

    public static ArrayList<TransactionLog> getTransactionLogByCustomerID(String customerID) {
        ArrayList<TransactionLog> customerTransactionLogs = new ArrayList<>();
        for (TransactionLog transactionLog : allTransactionLog) {
            if (transactionLog.getCustomerID().equals(customerID)) {
                customerTransactionLogs.add(transactionLog);
            }
        }
        return customerTransactionLogs;
    }

    public void writeNewLog(TransactionLog transaction) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TRANSACTIONFILE, true))) {
            String logData = transaction.getTransactionID() + "|"
                    + transaction.getCustomerID() + "|"
                    + transaction.getCreditBefore() + "|"
                    + transaction.getCreditAfter() + "|"
                    + transaction.getIsRefund() + "|"
                    + transaction.getTransactionDate() + "|"
                    + transaction.getTransactionTime();

            writer.write(logData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

    public static String checkRefund(String refundStatus) {
        if (refundStatus.equalsIgnoreCase("false")) {
            return "Refund";
        }
        return "";
    }

    public String getTransactionID() {
        return transactionID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getIsRefund() {
        return isRefund;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public String getTransactionTime() {
        return transactionTime;
    }

    public double getCreditBefore() {
        return creditBefore;
    }

    public double getCreditAfter() {
        return creditAfter;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setIsRefund(String isRefund) {
        this.isRefund = isRefund;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public void setTransactionTime(String transactionTime) {
        this.transactionTime = transactionTime;
    }

    public void setCreditBefore(double creditBefore) {
        this.creditBefore = creditBefore;
    }

    public void setCreditAfter(double creditAfter) {
        this.creditAfter = creditAfter;
    }

    @Override
    public String toString() {
        return "TransactionLog{" + "transactionID=" + transactionID + ", isRefund=" + isRefund + ", transactionDate=" + transactionDate + ", transactionTime=" + transactionTime + ", creditBefore=" + creditBefore + ", creditAfter=" + creditAfter + '}';
    }

}

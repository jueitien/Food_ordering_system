/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class DeliveryRunnerTask {

    private String taskID, customerID, orderID, riderID, taskStatus, taskDate, taskStartTime, taskEndTime;
    private static final String RIDERTASKFILE = "src/data/DeliveryRunnerTask.txt"; //declare default rider task txt file path
    private static ArrayList<DeliveryRunnerTask> allRiderTask = new ArrayList<>(); //declare rider list

    public DeliveryRunnerTask(String taskID, String customerID, String orderID, String riderID, String taskStatus, String taskDate, String taskStartTime, String taskEndTime) {
        this.taskID = taskID;
        this.customerID = customerID;
        this.orderID = orderID;
        this.riderID = riderID;
        this.taskStatus = taskStatus;
        this.taskDate = taskDate;
        this.taskStartTime = taskStartTime;
        this.taskEndTime = taskEndTime;
    }

    public DeliveryRunnerTask() {
        this.taskID = "";
        this.customerID = "";
        this.orderID = "";
        this.riderID = "";
        this.taskStatus = "";
        this.taskDate = "";
        this.taskStartTime = "";
        this.taskEndTime = "";
    }

    //reads all vendor item menu data from file
    public static void readRiderTaskData() {
        allRiderTask.clear();
        try {

            File tFile = new File(RIDERTASKFILE);
            try (Scanner scanner = new Scanner(tFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] tData = data.split("\\|");

                    //checks data length first
                    if (tData.length == 8) {

                        DeliveryRunnerTask deliveryRunnerTask = new DeliveryRunnerTask();
                        deliveryRunnerTask.setTaskID(tData[0]);
                        deliveryRunnerTask.setCustomerID(tData[1]);
                        deliveryRunnerTask.setOrderID(tData[2]);
                        deliveryRunnerTask.setRiderID(tData[3]);
                        deliveryRunnerTask.setTaskStatus(tData[4]);
                        deliveryRunnerTask.setTaskDate(tData[5]);
                        deliveryRunnerTask.setTaskStartTime(tData[6]);
                        deliveryRunnerTask.setTaskEndTime(tData[7]);

                        allRiderTask.add(deliveryRunnerTask);

                    } else {

                        System.out.println("Rider Task class " + "Data Length Error" + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    public static ArrayList<DeliveryRunnerTask> getAllRiderTask() {
        return allRiderTask;
    }

    public static DeliveryRunnerTask getRiderTaskByOrderID(String orderID) {
//        ArrayList<DeliveryRunnerTask> riderTasks = new ArrayList<>();
        for (DeliveryRunnerTask deliveryRunnerTask : allRiderTask) {
            if (deliveryRunnerTask.getOrderID().equals(orderID)) {
//                riderTasks.add(deliveryRunnerTask);
                return deliveryRunnerTask;
            }
        }
        return null;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getRiderID() {
        return riderID;
    }

    public void setRiderID(String riderID) {
        this.riderID = riderID;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate;
    }

    public String getTaskStartTime() {
        return taskStartTime;
    }

    public void setTaskStartTime(String taskStartTime) {
        this.taskStartTime = taskStartTime;
    }

    public String getTaskEndTime() {
        return taskEndTime;
    }

    public void setTaskEndTime(String taskEndTime) {
        this.taskEndTime = taskEndTime;
    }

    @Override
    public String toString() {
        return "DeliveryRunnerTask{" + "taskID=" + taskID + ", customerID=" + customerID + ", orderID=" + orderID + ", riderID=" + riderID + ", taskStatus=" + taskStatus + ", taskDate=" + taskDate + ", taskStartTime=" + taskStartTime + ", taskEndTime=" + taskEndTime + '}';
    }

}

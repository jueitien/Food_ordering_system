/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class VendorItemMenu {
    private String itemID, vendorID, itemName, itemDesc, itemStatus;
    private double itemPrice;
    private static final String MENUFILE = "src/data/VendorItemMenu.txt"; //declare default vendor item menu txt file path
    private static ArrayList<VendorItemMenu> allVendorItemMenu = new ArrayList<>(); //declare vendor item menu list

    public VendorItemMenu(String itemID, String vendorID, String itemName, String itemDesc, String itemStatus, double itemPrice) {
        this.itemID = itemID;
        this.vendorID = vendorID;
        this.itemName = itemName;
        this.itemDesc = itemDesc;
        this.itemStatus = itemStatus;
        this.itemPrice = itemPrice;
    }
    
    public VendorItemMenu() {
        this.itemID = "";
        this.vendorID = "";
        this.itemName = "";
        this.itemDesc = "";
        this.itemStatus = "";
        this.itemPrice = 0.0;
    }
    
        //reads all vendor item menu data from file
    public static void readVendorItemMenuData() {
        try {
            
            File mFile = new File(MENUFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {
                    
                    String data = scanner.nextLine();
                    String[] mData = data.split("\\|");
                    
                    //checks data length first
                    if(mData.length == 6){
                        
                        VendorItemMenu menu = new VendorItemMenu();
                        menu.setItemID(mData[0]);
                        menu.setVendorID(mData[1]);
                        menu.setItemName(mData[2]);
                        menu.setItemDesc(mData[3]);
                        menu.setItemPrice(Double.parseDouble(mData[4]));
                        menu.setItemStatus(mData[5]);

                        allVendorItemMenu.add(menu);
                        
                    } else {
                        
                        System.out.println("VendorItemMenu class" + "Data Length Error" + data);
                        
                    }
                    
                }
            }
            
        } catch (FileNotFoundException | NumberFormatException e) {
            
             System.out.println("File Read Error: " + e.getMessage());
             
        }
    }
    
    //getter for  all vendor item menu data
    public static ArrayList<VendorItemMenu> getAllVendorItemMenu() {
        return allVendorItemMenu;
    }
    
    public static VendorItemMenu getVendorItemMenuByID(String itemID) {
        for (VendorItemMenu vendorItemMenu : allVendorItemMenu) {
            if (vendorItemMenu.getItemID().equals(itemID)) {
                return vendorItemMenu;
            }
        }
        return null;
    }

    public String getItemID() {
        return itemID;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemDesc() {
        return itemDesc;
    }

    public String getItemStatus() {
        return itemStatus;
    }
    
    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemDesc(String itemDesc) {
        this.itemDesc = itemDesc;
    }

    public void setItemStatus(String itemStatus) {
        this.itemStatus = itemStatus;
    }
    
    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    @Override
    public String toString() {
        return "VendorItemMenu{" + "itemID=" + itemID + ", vendorID=" + vendorID + ", itemName=" + itemName + ", itemDesc=" + itemDesc + ", itemStatus=" + itemStatus + ", itemPrice=" + itemPrice + '}';
    }

}

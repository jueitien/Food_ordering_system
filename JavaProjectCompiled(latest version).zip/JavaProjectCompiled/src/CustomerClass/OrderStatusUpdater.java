/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import Customer.CustomerMainMenu;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author user
 */
public class OrderStatusUpdater {
    
    private final ScheduledExecutorService scheduler;
    
    public OrderStatusUpdater() {
        scheduler = Executors.newSingleThreadScheduledExecutor();
    }
    
    public void startSUTask(CustomerMainMenu customerMainMenu) {
        scheduler.scheduleAtFixedRate(() -> {
            customerMainMenu.updateStatus();
            System.out.println("SUTask updated!");
        }
        , 0, 5, TimeUnit.MINUTES); //initial delay = 0, each period = 5 min
//        , 0, 5, TimeUnit.SECONDS); //initial delay = 0, each period = 5 sec
        System.out.println("SUTask Started");
    }
    
    public void stopSUTask() {
        if (scheduler != null) {
            scheduler.shutdown();
            System.out.println("SUTask Ended");
        }
    }
    
}

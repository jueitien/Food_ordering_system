/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Notification {

    private String notificationID, senderID, notificationType, recipientID, notificationText, notificationDate;
    private static final String NOTIFICATIONFILE = "src/data/Notification.txt";
    private static ArrayList<Notification> allNotification = new ArrayList<>(); //declare notification list

    public Notification(String notificationID, String senderID, String notificationType, String recipientID, String notificationText, String notificationDate) {
        this.notificationID = notificationID;
        this.senderID = senderID;
        this.notificationType = notificationType;
        this.recipientID = recipientID;
        this.notificationText = notificationText;
        this.notificationDate = notificationDate;
    }

    public Notification() {
        this.notificationID = "";
        this.senderID = "";
        this.notificationType = "";
        this.recipientID = "";
        this.notificationText = "";
        this.notificationDate = "";
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(NOTIFICATIONFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("N")) {
                    String numberPart = currentID.substring(1);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("N%04d", newID + 1);
    }

    //reads all notification data from file
    public static void readNotificationData() {
        try {

            File mFile = new File(NOTIFICATIONFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] nData = data.split("\\|");

                    //checks data length first
                    if (nData.length == 6) {

                        Notification notification = new Notification();
                        notification.setNotificationID(nData[0]);
                        notification.setSenderID(nData[1]);
                        notification.setNotificationType(nData[2]);
                        notification.setRecipientID(nData[3]);
                        notification.setNotificationText((nData[4]));
                        notification.setNotificationDate(nData[5]);

                        allNotification.add(notification);

                    } else {

                        System.out.println("Notification class- " + "Data Length Error " + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

//    public void resetAllNotification() {
//        allNotification.clear();
//    }
    //getter for  all vendor item menu data
    public static ArrayList<Notification> getAllNotification() {
        return allNotification;
    }

    public static ArrayList<Notification> getNotificationByCustomerID(String customerID, boolean customerIDOnly) {
        ArrayList<Notification> customerNotifications = new ArrayList<>();
        for (Notification notification : allNotification) {
            if (customerIDOnly) {
                if (notification.getRecipientID().equals(customerID)) {
                    customerNotifications.add(notification);
                    System.out.println(notification);
                }
            } else {
                if (notification.getRecipientID().equals(customerID) || notification.getRecipientID().equalsIgnoreCase("customer") || notification.getNotificationType().equalsIgnoreCase("global")) {
                    customerNotifications.add(notification);
                    System.out.println(notification);
                }
            }
        }
        return customerNotifications;
    }

    public void writeNewNotification(Notification notification) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(NOTIFICATIONFILE, true))) {
            String notificationData = notification.getNotificationID() + "|"
                    + notification.getSenderID() + "|"
                    + notification.getNotificationType() + "|"
                    + notification.getRecipientID() + "|"
                    + notification.getNotificationText() + "|"
                    + notification.getNotificationDate();

            writer.write(notificationData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteNotification(Notification notification) {
        try {
            File file = new File(NOTIFICATIONFILE);
            List<String> lines = Files.readAllLines(file.toPath());
            List<String> updatedLines = new ArrayList<>();

            String notificationData = notification.getNotificationID() + "|"
                    + notification.getSenderID() + "|"
                    + notification.getNotificationType() + "|"
                    + notification.getRecipientID() + "|"
                    + notification.getNotificationText() + "|"
                    + notification.getNotificationDate();

            for (String line : lines) {
                if (!line.equals(notificationData)) {
                    updatedLines.add(line);
                }
            }
            Files.write(file.toPath(), updatedLines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public String getNotificationID() {
        return notificationID;
    }

    public String getSenderID() {
        return senderID;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public String getRecipientID() {
        return recipientID;
    }

    public String getNotificationText() {
        return notificationText;
    }

    public String getNotificationDate() {
        return notificationDate;
    }

    public void setNotificationID(String notificationID) {
        this.notificationID = notificationID;
    }

    public void setSenderID(String senderID) {
        this.senderID = senderID;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public void setRecipientID(String recipientID) {
        this.recipientID = recipientID;
    }

    public void setNotificationText(String notificationText) {
        this.notificationText = notificationText;
    }

    public void setNotificationDate(String notificationDate) {
        this.notificationDate = notificationDate;
    }

    @Override
    public String toString() {
        return "Notification{" + "notificationID=" + notificationID + ", senderID=" + senderID + ", notificationType=" + notificationType + ", recipientID=" + recipientID + ", notificationText=" + notificationText + ", notificationDate=" + notificationDate + '}';
    }
}

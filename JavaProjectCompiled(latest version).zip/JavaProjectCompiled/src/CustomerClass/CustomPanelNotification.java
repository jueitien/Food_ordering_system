/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

/**
 *
 * @author user
 */
public class CustomPanelNotification extends JPanel {

    private String notificationID;
    protected JLabel notificationTypeLabel, dateLabel, clearLabel;
    protected JTextArea messageTextArea;
    protected JScrollPane scrollPane;

    public CustomPanelNotification(Notification notification) {
        this.notificationID = notification.getNotificationID();

        setPreferredSize(new Dimension(100, 100));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createSoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.BLACK));
        setLayout(new GridBagLayout());
//        setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);

        notificationTypeLabel = new JLabel(checkNotificationType(notification), SwingConstants.CENTER);
        notificationTypeLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        notificationTypeLabel.setHorizontalAlignment(SwingConstants.LEFT);
//        notificationTypeLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        notificationTypeLabel.setPreferredSize(new Dimension(60, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.WEST;
        add(notificationTypeLabel, gbc);

        dateLabel = new JLabel(notification.getNotificationDate(), SwingConstants.CENTER);
        notificationTypeLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        dateLabel.setHorizontalAlignment(SwingConstants.CENTER);
//        dateLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.4;
        gbc.anchor = GridBagConstraints.CENTER;
        add(dateLabel, gbc);

        clearLabel = new JLabel("clear", SwingConstants.CENTER);
        clearLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        clearLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        clearLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
        clearLabel.setPreferredSize(new Dimension(50, 20));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        add(clearLabel, gbc);
        if (checkNotificationType(notification).equalsIgnoreCase("global")) {
            clearLabel.setText("");
        }

        messageTextArea = new JTextArea(notification.getNotificationText().replace("_", " "));
        messageTextArea.setWrapStyleWord(true);
        messageTextArea.setLineWrap(true);
//        messageTextArea.setHorizontalAlignment(SwingConstants.CENTER);
        messageTextArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageTextArea.setEditable(false);
        messageTextArea.setFocusable(false);
        messageTextArea.setBackground(Color.WHITE);
        messageTextArea.setPreferredSize(new Dimension(700, 30));
        messageTextArea.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        add(messageTextArea, gbc);

//        scrollPane = new JScrollPane(messageTextArea);
//        scrollPane.setPreferredSize(new Dimension(700, 30));
//        scrollPane.setBorder(null);
//        add(scrollPane, gbc);
        clearLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!checkNotificationType(notification).equalsIgnoreCase("global")) {
                    Notification.getAllNotification().remove(notification);
                    Notification notification1 = new Notification();
                    notification1.deleteNotification(notification);
                    Container parent = getParent();
                    if (parent != null) {
                        parent.remove(CustomPanelNotification.this);
                        parent.revalidate();
                        parent.repaint();
                    }

                    System.out.println("notification cleared");
                }
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                if (!checkNotificationType(notification).equalsIgnoreCase("global")) {
                    clearLabel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
                }

            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (!checkNotificationType(notification).equalsIgnoreCase("global")) {
                    clearLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!checkNotificationType(notification).equalsIgnoreCase("global")) {
                    clearLabel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (!checkNotificationType(notification).equalsIgnoreCase("global")) {
                    clearLabel.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                }
            }

        });
    }

    private String checkNotificationType(Notification notification) {
        String notificationType = notification.getNotificationType();
        String notificationSender = notification.getSenderID();
        if (notificationType.equalsIgnoreCase("individual")) {
            if (notificationSender.equalsIgnoreCase("null")) {
                return "System";
            }
            return "For you";
        }
        return "Global";
    }

    public boolean matchesNotification(Notification notification) {
        System.out.println(notificationID);
        return this.notificationID.equals(notification.getNotificationID());
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CustomerClass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class ComplaintBox {

    private String complaintID, customerID, orderID, managerID, complaint, status;
    private static final String COMPLAINTBOXFILE = "src/data/ComplaintBox.txt";
    private static ArrayList<ComplaintBox> allComplaintBox = new ArrayList<>(); //declare complain list

    public ComplaintBox(String complaintID, String customerID, String orderID, String managerID, String complaint, String status) {
        this.complaintID = complaintID;
        this.customerID = customerID;
        this.orderID = orderID;
        this.managerID = managerID;
        this.complaint = complaint;
        this.status = status;
    }

    public ComplaintBox() {
        this.complaintID = "";
        this.customerID = "";
        this.orderID = "";
        this.managerID = "";
        this.complaint = "";
        this.status = "";
    }

    public String newID() {
        int newID = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(COMPLAINTBOXFILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                String currentID = parts[0];
                if (currentID.startsWith("CB")) {
                    String numberPart = currentID.substring(2);
                    int IDNumber = Integer.parseInt(numberPart);
                    newID = Math.max(newID, IDNumber);
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return String.format("CB%03d", newID + 1);
    }

    //reads all customer review data from file
    public static void readComplaintBoxData() {
        allComplaintBox.clear();
        try {

            File mFile = new File(COMPLAINTBOXFILE);
            try (Scanner scanner = new Scanner(mFile)) {
                while (scanner.hasNextLine()) {

                    String data = scanner.nextLine();
                    String[] crData = data.split("\\|");

                    //checks data length first
                    if (crData.length == 6) {

                        ComplaintBox complaintBox = new ComplaintBox();
                        complaintBox.setComplaintID(crData[0]);
                        complaintBox.setCustomerID(crData[1]);
                        complaintBox.setOrderID(crData[2]);
                        complaintBox.setManagerID(crData[3]);
                        complaintBox.setComplaint(crData[4]);
                        complaintBox.setStatus(crData[5]);

                        allComplaintBox.add(complaintBox);

                    } else {

                        System.out.println("Complaint Box class- " + "Data Length Error " + data);

                    }

                }
            }

        } catch (FileNotFoundException | NumberFormatException e) {

            System.out.println("File Read Error: " + e.getMessage());

        }
    }

    public static ArrayList<ComplaintBox> getAllComplaintBox() {
        return allComplaintBox;
    }

    public void writeNewCustomerReview(ComplaintBox complaintBox) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(COMPLAINTBOXFILE, true))) {
            String complaintBoxData = complaintBox.getComplaintID() + "|"
                    + complaintBox.getCustomerID() + "|"
                    + complaintBox.getOrderID() + "|"
                    + complaintBox.getManagerID() + "|"
                    + complaintBox.getComplaint() + "|"
                    + "unresolved";

            writer.write(complaintBoxData);
            writer.newLine();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static boolean checkComplaintByCustomerID(String orderID, String customerID) {
        for (ComplaintBox complaintBox : allComplaintBox) {
            if (complaintBox.getOrderID().equals(orderID)) {
                if (complaintBox.getCustomerID().equals(customerID)) {
                    return true;
                }
            }
        }
        return false;
    }

    public String getComplaintID() {
        return complaintID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getManagerID() {
        return managerID;
    }

    public String getComplaint() {
        return complaint;
    }

    public String getStatus() {
        return status;
    }

    public void setComplaintID(String complaintID) {
        this.complaintID = complaintID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public void setManagerID(String ManagerID) {
        this.managerID = ManagerID;
    }

    public void setComplaint(String complaint) {
        this.complaint = complaint;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ComplaintBox{" + "complaintID=" + complaintID + ", customerID=" + customerID + ", orderID=" + orderID + ", managerID=" + managerID + ", complaint=" + complaint + '}';
    }

}
